    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Daftar <small>Semua Siswa SMA N 1 Rembang Purbalingga</small></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Cari!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Data Siswa Pelajaran SMA N 1 Rembang</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>

                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  <div class="accordion" id="accordion" role="tablist" aria-multiselectable="true">
                      <div class="panel">
                        <a class="panel-heading collapsed" role="tab" id="headingThree" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                          <h4 class="panel-title">Tampilkan Data Berdasarkan Kelas</h4>
                        </a>
                        <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                          <div class="panel-body">
                          <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/admin/daftar_siswa_kelas'); ?>" method="post" novalidate>
                          <p><strong>Pilih Data Kelas</strong>
                            </p>
                              <?php
                              foreach($kelas as $k){?>
                            <label class="btn btn-primary" data-toggle-class="btn-primary" data-toggle-passive-class="btn-primary">
                              <input type="radio" name="kelas" value="<?php echo "$k->id_kelas" ?>"> &nbsp; <?php echo "$k->nama_kelas"; ?> &nbsp;
                            </label>
                              <?php } ?>
                                  <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                    <button id="send" type="submit" class="btn btn-success">Tampilkan</button>
                                  </div>
                                  </div>
                          </from>
                          </div>
                        </div>
                      </div>
                      </div>
                    <!-- end of accordion -->
                  <div class="" role="tabpanel" data-example-id="togglable-tabs">
                      <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Daftar Siswa Aktif</a>
                        </li>
                        <li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Daftar Siswa Tidak Aktif</a>
                        </li>
                      </ul>
                      <div id="myTabContent" class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
                          <p class="text-muted font-13 m-b-30">
                      Jangan lupa untuk cek data dan jika terdapat kesalahan Segera !!! di perbaiki
                    </p>
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>NIS</th>
                          <th>NISN</th>
                          <th>Nama</th>
                          <th>Jenis Kelamin</th>
                          <th>Tempat Lahir</th>
                          <th>Tanggal Lahir</th>
                          <th>Data Orang Tua</th>
                          <th>Data Alamat</th>
                          <th>Data Akun</th>
                          <th>Kelas</th>
                          <th>Status</th>
                          <th>Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                           
                            $no=0;
                            if(!empty($siswa)){
                                foreach($siswa as $s){
                                $no=$no+1;
                                echo "<tr>";
                                echo "<td>$no</td>"; 
                                echo "<td>{$s->nis}</td>";
                                echo "<td>{$s->nisn}</td>";
                                echo "<td>{$s->nama_siswa}</td>";
                                echo "<td>{$s->jeniskelamin_siswa}</td>";
                                echo "<td>{$s->tempatlahir_siswa}</td>";
                                echo "<td>{$s->tanggallahir_siswa}</td>";?>
                                <td><?php echo anchor('admin/daftar_orangtua_siswa/'.$s->nis,'Lihat Data'); ?></td>
                                <td><?php echo anchor('admin/daftar_alamat_siswa/'.$s->nis,'Lihat Data'); ?></td>
                                <td><?php echo anchor('admin/daftar_akun_siswa/'.$s->nis,'Lihat Data'); ?></td><?php
                                 echo "<td>{$s->nama_kelas}</td>";?>
                                <td><p class="btn btn-success btn-xs"><?php echo "{$s->status}"; ?></p></td>
                                <td><a href="<?php echo base_url("index.php/admin/edit_siswa/".$s->nis); ?>" type="button" class="btn btn-primary btn-xs">EDIT</a>
                                  <a href="<?php echo base_url("index.php/admin/hapus_data_siswa/".$s->nis); ?>" type="button" class="btn btn-danger btn-xs">HAPUS</a>
                  </td>
                  <?php
                              echo "</tr>";}}
                        ?>
                      </tbody>
                    </table>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
                          <p class="text-muted font-13 m-b-30">
                      Jangan lupa untuk cek data dan jika terdapat kesalahan Segera !!! di perbaiki
                    </p>
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>NIS</th>
                          <th>NISN</th>
                          <th>Nama</th>
                          <th>Jenis Kelamin</th>
                          <th>Tempat Lahir</th>
                          <th>Tanggal Lahir</th>
                          <th>Data Orang Tua</th>
                          <th>Data Alamat</th>
                          <th>Kelas</th>
                          <th>Status</th>
                          <th>Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                           
                            $no=0;
                            if(!empty($siswa)){
                                foreach($siswa_tidak_aktif as $s){
                                $no=$no+1;
                                echo "<tr>";
                                echo "<td>$no</td>"; 
                                echo "<td>{$s->nis}</td>";
                                echo "<td>{$s->nisn}</td>";
                                echo "<td>{$s->nama_siswa}</td>";
                                echo "<td>{$s->jeniskelamin_siswa}</td>";
                                echo "<td>{$s->tempatlahir_siswa}</td>";
                                echo "<td>{$s->tanggallahir_siswa}</td>";?>
                                <td><?php echo anchor('admin/daftar_orangtua_siswa/'.$s->nis,'Lihat Data'); ?></td>
                                <td><?php echo anchor('admin/daftar_alamat_siswa/'.$s->nis,'Lihat Data'); ?></td><?php
                                 echo "<td>-</td>";?>
                                <td><p class="btn btn-danger btn-xs"><?php echo "{$s->status}"; ?></p></td>
                                <td><a href="<?php echo base_url("index.php/admin/edit_siswa_tidak_aktif/".$s->nis); ?>" type="button" class="btn btn-primary btn-xs">EDIT</a>
                                  <a href="<?php echo base_url("index.php/admin/hapus_data_siswa/".$s->nis); ?>" type="button" class="btn btn-danger btn-xs">HAPUS</a>
                  </td>
                  <?php
                              echo "</tr>";}}
                        ?>
                      </tbody>
                    </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Kerja Praktek Jurusan Teknik Informatika Universites Islam Indonesia by azizsembada
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/template/build/js/custom.min.js"></script>

    <!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
  </body>
</html>