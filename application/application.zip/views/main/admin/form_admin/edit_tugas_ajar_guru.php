        <!-- page content -->

        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Form Edit Tugas Mengajar Guru</h3>
              </div>

              <div class="title_right">
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
            <?php foreach($ajar as $a)?>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Form Edit Tugas Mengajar</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/admin/proses_edit_tugas_guru'); ?>" method="post" novalidate>

                      <p>Pastikan data yang di isi sudah benar</p>
                      <span class="section">Edit Tugas Mengajar <?php echo "$a->nama_guru"; ?></span>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="mata_pelajaran">Nama Guru<span class="required">*</span>
                        </label>
                        <input type="hidden" name="id_ajar" value="<?php echo $a->id_ajar ?>">
                        <input type="hidden" name="id_guru" value="<?php echo $a->id_guru ?>">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <?php echo "$a->nama_guru"; ?>
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="mata_pelajaran">Mata Pelajaran <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">

                          <select name="id_matapelajaran" >
                              <option value="0">-Pilih Mata Pelajaran-</option>
                              <?php 
                                foreach($matapelajaran as $mp){ 
                                echo "<option value=$mp->id_matapelajaran >{$mp->nama_matapelajaran}</option>";}
                                ?>

                          </select>
                          <p style="color:black">Mata pelajaran sekarang : <strong><?php echo "$a->nama_matapelajaran"; ?></strong></p>
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="tahun_ajaran">Tahun Ajaran <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                      <select name="id_ta" >
                              <option value="0">-Pilih Tahun Ajaran-</option>
                              <?php 
                                foreach($tahun_ajaran as $t){ 
                                echo "<option value=$t->id_ta >{$t->nama_ta}</option>";}
                                ?>
                      </select>
                      <p style="color:black">Tahun Ajaran sekarang : <strong><?php echo "$a->nama_ta"; ?></strong></p>
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="mata_pelajaran">Kelas<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                        <table>
                          <tbody>
                            <tr>
                            <td>
                              <select name="kelas1" >
                              <option value="0">-Kelas ke 1-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                              <p style="color:black"><strong><?php echo "$a->nama_kelas"; ?></strong></p>
                            </td>
                            <td>
                              <select name="kelas2" >
                              <option value="0">-Kelas ke 2-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                                                            <?php
                                if ($a->kelas2!=0) {
                                  if ($a->kelas2==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas2==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas2==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas2==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas2==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas2==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas2==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas2==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas2==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas2==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas2==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas2==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas2==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas2==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas2==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas2==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas2==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas2==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas2==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas2==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas2==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas2==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas2==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas2==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  } 
                              ?>
                            </td>
                            <td>
                              <select name="kelas3" >
                              <option value="0">-Kelas ke 3-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas3!=0) {
                                  if ($a->kelas3==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas3==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas3==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas3==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas3==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas3==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas3==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas3==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas3==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas3==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas3==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas3==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas3==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas3==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas3==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas3==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas3==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas3==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas3==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas3==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas3==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas3==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas3==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas3==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  } 
                              ?>

                            </td>
                            <td>
                              <select name="kelas4" >
                              <option value="0">-Kelas ke 4-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas4!=0) {
                                  if ($a->kelas4==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas4==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas4==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas4==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas4==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas4==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas4==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas4==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas4==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas4==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas4==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas4==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas4==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas4==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas4==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas4==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas4==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas4==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas4==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas4==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas4==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas4==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas4==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas4==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  } 
                              ?>

                            </td>
                            <td>
                              <select name="kelas5" >
                              <option value="0">-Kelas ke 5-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas5!=0) {
                                  if ($a->kelas5==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas5==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas5==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas5==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas5==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas5==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas5==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas5==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas5==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas5==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas5==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas5==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas5==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas5==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas5==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas5==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas5==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas5==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas5==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas5==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas5==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas5==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas5==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas5==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>
                            </td>
                            <td>
                              <select name="kelas6" >
                              <option value="0">-Kelas ke 6-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas6!=0) {
                                  if ($a->kelas6==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas6==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas6==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas6==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas6==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas6==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas6==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas6==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas6==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas6==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas6==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas6==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas6==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas6==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas6==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas6==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas6==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas6==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas6==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas6==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas6==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas6==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas6==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas6==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>

                            </td>
                            </tr>
                            <tr>
                            <td>
                              <select name="kelas7" >
                              <option value="0">-Kelas ke 7-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas7!=0) {
                                  if ($a->kelas7==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas7==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas7==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas7==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas7==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas7==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas7==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas7==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas7==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas7==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas7==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas7==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas7==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas7==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas7==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas7==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas7==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas7==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas7==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas7==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas7==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas7==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas7==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas7==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>

                            </td>
                            <td>
                              <select name="kelas8" >
                              <option value="0">-Kelas ke 8-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas8!=0) {
                                  if ($a->kelas8==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas8==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas8==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas8==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas8==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas8==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas8==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas8==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas8==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas8==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas8==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas8==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas8==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas8==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas8==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas8==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas8==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas8==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas8==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas8==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas8==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas8==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas8==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas8==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>

                            </td>
                            <td>
                              <select name="kelas9" >
                              <option value="0">-Kelas ke 9-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas9!=0) {
                                  if ($a->kelas9==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas9==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas9==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas9==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas9==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas9==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas9==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas9==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas9==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas9==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas9==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas9==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas9==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas9==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas9==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas9==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas9==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas9==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas9==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas9==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas9==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas9==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas9==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas9==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>

                            </td>
                            <td>
                              <select name="kelas10" >
                              <option value="0">-Kelas ke 10-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas10!=0) {
                                  if ($a->kelas10==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas10==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas10==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas10==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas10==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas10==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas10==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas10==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas10==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas10==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas10==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas10==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas10==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas10==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas10==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas10==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas10==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas10==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas10==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas10==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas10==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas10==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas10==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas10==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>

                            </td>
                            <td>
                              <select name="kelas11" >
                              <option value="0">-Kelas ke 11-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas11!=0) {
                                  if ($a->kelas11==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas11==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas11==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas11==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas11==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas11==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas11==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas11==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas11==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas11==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas11==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas11==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas11==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas11==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas11==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas11==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas11==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas11==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas11==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas11==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas11==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas11==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas11==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas11==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>

                            </td>
                            <td>
                              <select name="kelas12" >
                              <option value="0">-Kelas ke 12-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas12!=0) {
                                  if ($a->kelas12==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas12==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas12==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas12==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas12==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas12==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas12==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas12==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas12==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas12==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas12==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas12==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas12==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas12==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas12==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas12==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas12==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas12==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas12==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas12==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas12==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas12==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas12==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas12==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>
                            </td>
                            </tr>
                            <tr>
                            <td>
                              <select name="kelas13" >
                              <option value="0">-Kelas ke 13-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas13!=0) {
                                  if ($a->kelas13==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas13==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas13==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas13==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas13==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas13==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas13==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas13==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas13==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas13==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas13==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas13==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas13==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas13==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas13==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas13==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas13==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas13==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas13==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas13==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas13==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas13==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas13==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas13==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>
                            </td>
                            <td>
                              <select name="kelas14" >
                              <option value="0">-Kelas ke 14-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas14!=0) {
                                  if ($a->kelas14==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas14==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas14==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas14==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas14==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas14==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas14==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas14==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas14==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas14==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas14==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas14==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas14==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas14==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas14==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas14==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas14==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas14==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas14==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas14==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas14==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas14==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas14==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas14==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>
                            </td>
                            <td>
                              <select name="kelas15" >
                              <option value="0">-Kelas ke 15-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas15!=0) {
                                  if ($a->kelas15==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas15==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas15==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas15==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas15==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas15==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas15==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas15==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas15==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas15==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas15==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas15==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas15==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas15==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas15==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas15==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas15==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas15==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas15==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas15==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas15==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas15==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas15==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas15==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>
                            </td>
                            <td>
                              <select name="kelas16" >
                              <option value="0">-Kelas ke 16-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas16!=0) {
                                  if ($a->kelas16==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas16==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas16==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas16==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas16==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas16==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas16==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas16==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas16==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas16==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas16==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas16==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas16==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas16==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas16==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas16==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas16==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas16==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas16==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas16==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas16==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas16==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas16==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas16==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>
                            </td>
                            <td>
                              <select name="kelas17" >
                              <option value="0">-Kelas ke 17-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas17!=0) {
                                  if ($a->kelas17==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas17==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas17==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas17==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas17==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas17==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas17==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas17==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas17==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas17==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas17==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas17==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas17==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas17==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas17==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas17==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas17==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas17==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas17==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas17==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas17==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas17==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas17==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas17==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>

                            </td>
                            <td>
                              <select name="kelas18" >
                              <option value="0">-Kelas ke 18-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas18!=0) {
                                  if ($a->kelas18==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas18==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas18==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas18==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas18==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas18==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas18==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas18==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas18==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas18==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas18==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas18==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas18==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas18==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas18==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas18==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas18==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas18==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas18==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas18==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas18==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas18==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas18==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas18==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>
                            </td>
                            </tr>
                            <tr>
                            <td>
                              <select name="kelas19" >
                              <option value="0">-Kelas ke 19-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas19!=0) {
                                  if ($a->kelas19==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas19==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas19==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas19==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas19==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas19==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas19==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas19==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas19==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas19==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas19==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas19==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas19==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas19==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas19==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas19==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas19==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas19==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas19==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas19==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas19==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas19==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas19==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas19==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>
                            </td>
                            <td>
                              <select name="kelas20" >
                              <option value="0">-Kelas ke 20-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas20!=0) {
                                  if ($a->kelas20==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas20==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas20==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas20==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas20==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas20==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas20==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas20==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas20==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas20==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas20==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas20==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas20==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas20==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas20==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas20==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas20==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas20==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas20==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas20==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas20==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas20==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas20==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas20==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>
                            </td>
                            <td>
                              <select name="kelas21" >
                              <option value="0">-Kelas ke 21-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas21!=0) {
                                  if ($a->kelas21==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas21==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas21==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas21==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas21==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas21==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas21==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas21==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas21==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas21==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas21==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas21==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas21==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas21==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas21==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas21==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas21==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas21==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas21==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas21==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas21==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas21==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas21==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas21==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>
                            </td>
                            <td>
                              <select name="kelas22" >
                              <option value="0">-Kelas ke 22-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas22!=0) {
                                  if ($a->kelas22==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas22==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas22==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas22==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas22==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas22==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas22==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas22==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas22==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas22==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas22==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas22==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas22==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas22==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas22==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas22==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas22==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas22==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas22==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas22==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas22==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas22==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas22==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas22==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>
                            </td>
                            <td>
                              <select name="kelas23" >
                              <option value="0">-Kelas ke 23-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas23!=0) {
                                  if ($a->kelas23==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas23==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas23==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas23==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas23==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas23==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas23==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas23==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas23==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas23==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas23==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas23==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas23==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas23==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas23==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas23==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas23==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas23==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas23==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas23==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas23==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas23==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas23==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas23==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>
                            </td>
                            <td>
                              <select name="kelas24" >
                              <option value="0">-Kelas ke 24-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>
                              </select>
                              <?php
                                if ($a->kelas24!=0) {
                                  if ($a->kelas24==1) {
                                    echo "<p style='color:black'><strong>X IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas24==2) {
                                    echo "<p style='color:black'><strong>X IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas24==3) {
                                    echo "<p style='color:black'><strong>X IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas24==4) {
                                    echo "<p style='color:black'><strong>X IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas24==5) {
                                    echo "<p style='color:black'><strong>X IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas24==6) {
                                    echo "<p style='color:black'><strong>X IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas24==7) {
                                    echo "<p style='color:black'><strong>X IPS 3</strong></p>";
                                  } 
                                  elseif ($a->kelas24==8) {
                                    echo "<p style='color:black'><strong>X IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas24==9) {
                                    echo "<p style='color:black'><strong>XI IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas24==10) {
                                    echo "<p style='color:black'><strong>XI IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas24==11) {
                                    echo "<p style='color:black'><strong>XI IPA 3</strong></p>";
                                  } 
                                  elseif ($a->kelas24==12) {
                                    echo "<p style='color:black'><strong>XI IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas24==13) {
                                    echo "<p style='color:black'><strong>XI IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas24==14) {
                                    echo "<p style='color:black'><strong>XI IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas24==15) {
                                    echo "<p style='color:black'><strong>XI IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas24==16) {
                                    echo "<p style='color:black'><strong>XI IPS 4</strong></p>";
                                  }
                                  elseif ($a->kelas24==17) {
                                    echo "<p style='color:black'><strong>XII IPA 1</strong></p>";
                                  }
                                  elseif ($a->kelas24==18) {
                                    echo "<p style='color:black'><strong>XII IPA 2</strong></p>";
                                  }
                                  elseif ($a->kelas24==19) {
                                    echo "<p style='color:black'><strong>XII IPA 3</strong></p>";
                                  }
                                  elseif ($a->kelas24==20) {
                                    echo "<p style='color:black'><strong>XII IPA 4</strong></p>";
                                  }
                                  elseif ($a->kelas24==21) {
                                    echo "<p style='color:black'><strong>XII IPS 1</strong></p>";
                                  }
                                  elseif ($a->kelas24==22) {
                                    echo "<p style='color:black'><strong>XII IPS 2</strong></p>";
                                  }
                                  elseif ($a->kelas24==23) {
                                    echo "<p style='color:black'><strong>XII IPS 3</strong></p>";
                                  }
                                  elseif ($a->kelas24==24) {
                                    echo "<p style='color:black'><strong>XII IPS 4</strong></p>";
                                  }}
                                else{
                                    echo "<p style='color:black'><strong>-</strong></p>";
                                  }    
                              ?>

                            </td>
                            </tr>
                          </tbody>
                        </table>
                        </div>
                      </div>
                       <center><b><p style="color:red">PASTIKAN DATA YANG DI UBAH SUDAH BENAR !!!</p></b></center>
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">
                          <a href="<?php echo base_url('index.php/admin/daftar_ajar'); ?>" class="btn btn-primary">Cancel</a>
                          <button id="send" type="submit" class="btn btn-success">Update</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
             Kerja Praktek Jurusan Teknik Informatika Universites Islam Indonesia by azizsembada
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.js"></script>
    <!-- validator -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/validator/validator.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/template/build/js/custom.min.js"></script>

    <!-- validator -->
    <script>
      // initialize the validator function
      validator.message.date = 'not a real date';

      // validate a field on "blur" event, a 'select' on 'change' event & a '.reuired' classed multifield on 'keyup':
      $('form')
        .on('blur', 'input[required], input.optional, select.required', validator.checkField)
        .on('change', 'select.required', validator.checkField)
        .on('keypress', 'input[required][pattern]', validator.keypress);

      $('.multi.required').on('keyup blur', 'input', function() {
        validator.checkField.apply($(this).siblings().last()[0]);
      });

      $('form').submit(function(e) {
        e.preventDefault();
        var submit = true;

        // evaluate the form using generic validaing
        if (!validator.checkAll($(this))) {
          submit = false;
        }

        if (submit)
          this.submit();

        return false;
      });
    </script>
    <!-- /validator -->
  </body>
</html>