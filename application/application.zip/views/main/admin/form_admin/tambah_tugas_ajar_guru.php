        <!-- page content -->

        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Form Tambah Tugas Mengajar Guru</h3>
              </div>

              <div class="title_right">
                </div>
              </div>
            </div>
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Form Tambah Tugas Mengajar Guru</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/admin/proses_tambah_tugas_guru'); ?>" method="post" novalidate>

                      <p>Pastikan data yang di isi sudah benar</p>
                      <span class="section">Tambah Tugas Mengajar Guru</span>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="mata_pelajaran">Nama Guru<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">

                          <select name="id_guru" >
                              <option value="0">-Pilih Guru-</option>
                              <?php 
                                foreach($guru as $g){ 
                                echo "<option value=$g->id_guru >{$g->nama_guru}</option>";}
                                ?>

                        </select>
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="mata_pelajaran">Mata Pelajaran <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">

                          <select name="id_matapelajaran" >
                              <option value="0">-Pilih Mata Pelajaran-</option>
                              <?php 
                                foreach($matapelajaran as $mp){ 
                                echo "<option value=$mp->id_matapelajaran >{$mp->nama_matapelajaran}</option>";}
                                ?>

                          </select>
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="tahun_ajaran">Tahun Ajaran <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                      <select name="id_ta" >
                              <option value="0">-Pilih Tahun Ajaran-</option>
                              <?php 
                                foreach($tahun_ajaran as $t){ 
                                echo "<option value=$t->id_ta >{$t->nama_ta}</option>";}
                                ?>

                      </select>
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="mata_pelajaran">Kelas<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                        <table>
                          <tbody>
                            <tr>
                            <td>
                              <select name="kelas1" >
                              <option value="0">-Kelas ke 1-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas2" >
                              <option value="0">-Kelas ke 2-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas3" >
                              <option value="0">-Kelas ke 3-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas4" >
                              <option value="0">-Kelas ke 4-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas5" >
                              <option value="0">-Kelas ke 5-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas6" >
                              <option value="0">-Kelas ke 6-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            </tr>
                            <tr>
                            <td>
                              <select name="kelas7" >
                              <option value="0">-Kelas ke 7-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas8" >
                              <option value="0">-Kelas ke 8-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas9" >
                              <option value="0">-Kelas ke 9-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas10" >
                              <option value="0">-Kelas ke 10-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas11" >
                              <option value="0">-Kelas ke 11-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas12" >
                              <option value="0">-Kelas ke 12-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            </tr>
                            <tr>
                            <td>
                              <select name="kelas13" >
                              <option value="0">-Kelas ke 13-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas14" >
                              <option value="0">-Kelas ke 14-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas15" >
                              <option value="0">-Kelas ke 15-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas16" >
                              <option value="0">-Kelas ke 16-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas17" >
                              <option value="0">-Kelas ke 17-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas18" >
                              <option value="0">-Kelas ke 18-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            </tr>
                            <tr>
                            <td>
                              <select name="kelas19" >
                              <option value="0">-Kelas ke 19-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas20" >
                              <option value="0">-Kelas ke 20-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas21" >
                              <option value="0">-Kelas ke 21-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas22" >
                              <option value="0">-Kelas ke 22-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas23" >
                              <option value="0">-Kelas ke 23-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            <td>
                              <select name="kelas24" >
                              <option value="0">-Kelas ke 24-</option>
                              <?php 
                                foreach($kelas as $k){ 
                                echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                ?>

                              </select>
                            </td>
                            </tr>
                          </tbody>
                        </table>
                        </div>
                      </div>

                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">
                          <a href="<?php echo base_url('index.php/admin/daftar_guru'); ?>" class="btn btn-primary">Cancel</a>
                          <button id="send" type="submit" class="btn btn-success">Submit</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
             Kerja Praktek Jurusan Teknik Informatika Universites Islam Indonesia by azizsembada
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.js"></script>
    <!-- validator -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/validator/validator.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/template/build/js/custom.min.js"></script>

    <!-- validator -->
    <script>
      // initialize the validator function
      validator.message.date = 'not a real date';

      // validate a field on "blur" event, a 'select' on 'change' event & a '.reuired' classed multifield on 'keyup':
      $('form')
        .on('blur', 'input[required], input.optional, select.required', validator.checkField)
        .on('change', 'select.required', validator.checkField)
        .on('keypress', 'input[required][pattern]', validator.keypress);

      $('.multi.required').on('keyup blur', 'input', function() {
        validator.checkField.apply($(this).siblings().last()[0]);
      });

      $('form').submit(function(e) {
        e.preventDefault();
        var submit = true;

        // evaluate the form using generic validaing
        if (!validator.checkAll($(this))) {
          submit = false;
        }

        if (submit)
          this.submit();

        return false;
      });
    </script>
    <!-- /validator -->
  </body>
</html>