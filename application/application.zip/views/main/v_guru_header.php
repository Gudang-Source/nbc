<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>GURU AREA SINI | SYSTEM INFORMASI NILAI </title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url(); ?>assets/template/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="<?php echo base_url(); ?>assets/template/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="<?php echo base_url(); ?>assets/template/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="<?php echo base_url(); ?>assets/template/vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>

    <!-- Custom Theme Style -->
    <link href="<?php echo base_url(); ?>assets/template/build/css/custom.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/template/vendors/dropzone/dist/min/dropzone.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="<?php echo base_url("index.php/guru"); ?>" class="site_title"><i class="fa fa-graduation-cap"></i> <span>GURU Area!</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
               <br><center><img src="<?php echo base_url(); ?>assets/template/production/images/img.png" alt="..." width="50px" height="70px"></center>
              </div>
              <div class="profile_info">
                <span>Selamat datang,</span>
                <?php foreach($guru as $g)?>
                <h2><?php echo $g->nama_guru; ?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
              <h3>General</h3>
                <ul class="nav side-menu">
                  <li><a href="<?php echo base_url("index.php/guru"); ?>"><i class="fa fa-home"></i> Home <span></span></a>
                  </li>
                  <li><a><i class="fa fa-edit"></i> Kelola Nilai <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a>Ulangan Harian<span class="fa fa-chevron-down"></span></a>
                          <ul class="nav child_menu">
                            <li class="sub_menu"><a href="<?php echo base_url('index.php/guru/tambah_nilai_uh1/'.$g->id_guru); ?>">Tambah Nilai Ulangan 1</a></li>
                            <li><a href="<?php echo base_url('index.php/guru/tambah_nilai_uh2/'.$g->id_guru); ?>">Tambah Nilai Ulangan 2</a></li>
                            <li><a href="<?php echo base_url('index.php/guru/tambah_nilai_uh3/'.$g->id_guru); ?>">Tambah Nilai Ulangan 3</a></li>
                          </ul>
                        </li>
                      <li><a>Remidial<span class="fa fa-chevron-down"></span></a>
                          <ul class="nav child_menu">
                            <li class="sub_menu"><a href="<?php echo base_url('index.php/guru/tambah_nilai_remidi1/'.$g->id_guru); ?>">Remidial 1</a></li>
                            <li><a href="<?php echo base_url('index.php/guru/tambah_nilai_remidi2/'.$g->id_guru); ?>">Remidial 2</a></li>
                            <li><a href="<?php echo base_url('index.php/guru/tambah_nilai_remidi3/'.$g->id_guru); ?>">Remidial 3</a></li>
                          </ul>
                        </li>
                      <li><a>Tugas Harian<span class="fa fa-chevron-down"></span></a>
                          <ul class="nav child_menu">
                            <li class="sub_menu"><a href="<?php echo base_url('index.php/guru/tambah_nilai_tugas1/'.$g->id_guru); ?>">Tugas 1</a></li>
                            <li><a href="<?php echo base_url('index.php/guru/tambah_nilai_tugas2/'.$g->id_guru); ?>">Tugas 2</a></li>
                            <li><a href="<?php echo base_url('index.php/guru/tambah_nilai_tugas3/'.$g->id_guru); ?>">Tugas 3</a></li>
                          </ul>
                        </li>
                      <li><a>Ujian<span class="fa fa-chevron-down"></span></a>
                          <ul class="nav child_menu">
                            <li class="sub_menu"><a href="<?php echo base_url('index.php/guru/tambah_nilai_uts/'.$g->id_guru); ?>">UTS</a></li>
                            <li><a href="<?php echo base_url('index.php/guru/tambah_nilai_uas/'.$g->id_guru); ?>">UAS</a></li>
                            <li><a href="<?php echo base_url('index.php/guru/tambah_nilai_praktek/'.$g->id_guru); ?>">Praktek</a></li>
                          </ul>
                        </li>
                        <li><a>Nilai Ketrampilan<span class="fa fa-chevron-down"></span></a>
                          <ul class="nav child_menu">
                            <li class="sub_menu"><a href="<?php echo base_url('index.php/guru/tambah_nilai_ketrampilan1/'.$g->id_guru); ?>">Ketrampilan 1</a></li>
                            <li><a href="<?php echo base_url('index.php/guru/tambah_nilai_ketrampilan2/'.$g->id_guru); ?>">Ketrampilan 2</a></li>
                            <li><a href="<?php echo base_url('index.php/guru/tambah_nilai_ketrampilan3/'.$g->id_guru); ?>">Ketrampilan 3</a></li>
                          </ul>
                        </li>
                        <li><a href="<?php echo base_url("index.php/guru/tambah_komentar/".$g->id_guru); ?>">Tambah Komentar KTSP</a></li>
                         <li><a href="<?php echo base_url("index.php/guru/tambah_komentar_k13/".$g->id_guru); ?>">Tambahan Komentar K 13</a></li>
                    </ul>
                  </li>
                  <?php
                  foreach($bk as $b)
                  if ($b->id_matapelajaran==7) {?>
                      <li><a><i class="fa fa-edit"></i> Nilai BK <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url('index.php/guru/tambah_nilai_akhlaq_kepribadian/'.$g->id_guru); ?>"><i></i> Masukan Nilai Akhlaq</a></li>
                      <li><a href="<?php echo base_url('index.php/guru/tambah_kehadiran_siswa/'.$g->id_guru); ?>"><i></i> Masukan Kehadiran Siswa</a></li>
                      <li><a href="<?php echo base_url('index.php/guru/tambah_nilai_sikap_sosial/'.$g->id_guru); ?>"><i></i> Masukan Sikap Sosial K13</a></li>
                      </ul>
                  </li>

                    <?php
                  }
                  foreach($bk as $b)
                  if ($b->id_matapelajaran==18) {?>
                      <li><a><i class="fa fa-edit"></i> Nilai Agama <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url('index.php/guru/tambah_nilai_sikap_spiritual/'.$g->id_guru); ?>"><i></i> Masukan Nilai Spiritual K13</a></li>
                      </ul>
                  </li>

                    <?php
                  }
                  ?>
                  <li><a><i class="fa fa-table"></i> Data <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url("index.php/guru/daftar_nilai/"); ?>">Daftar Nilai Ulangan Harian</a></li>
                      <li><a href="<?php echo base_url("index.php/guru/daftar_nilai_tugas"); ?>">Daftar Nilai Tugas Harian</a></li>
                      <li><a href="<?php echo base_url("index.php/guru/daftar_nilai_ketrampilan"); ?>">Daftar Nilai Ketrampilan</a></li>
                      <li><a href="<?php echo base_url("index.php/guru/daftar_nilai_ujian"); ?>">Daftar Nilai Ujian</a></li>
                      <li><a href="<?php echo base_url("index.php/guru/daftar_komentar"); ?>">Daftar Sikap & Komentar</a></li>
                      <li><a href="<?php echo base_url("index.php/guru/daftar_komentar_k13"); ?>">Daftar Komentar K13</a></li>
                      <?php
                      foreach($bk as $b)
                      if ($b->id_matapelajaran==7) {?>
                          <li><a href="<?php echo base_url('index.php/guru/daftar_nilai_akhlaq'); ?>"> Daftar Nilai Akhlaq</a></li>
                          <li><a href="<?php echo base_url('index.php/guru/daftar_kehadiran_siswa'); ?>"> Daftar Kehadiran Siswa</a></li>
                          <li><a href="<?php echo base_url('index.php/guru/daftar_nilai_sikap_sosial'); ?>"> Daftar Nilai Sikap Sosial K13</a></li>
                          <?php
                  }
                  ?>
                  <?php
                      foreach($bk as $b)
                      if ($b->id_matapelajaran==18) {?>
                          <li><a href="<?php echo base_url('index.php/guru/daftar_nilai_sikap_spiritual'); ?>"> Daftar Nilai Sikap Spiritual</a></li>
                          <?php
                  }
                  ?>
                    </ul>
                  </li>
                  <?php
                  foreach($guru as $k)
                  if ($k->wali_kelas>0) {?>
                      <li><a href="<?php echo base_url("index.php/guru/catatan_wali_kelas/".$k->id_guru); ?>"><i class="fa fa-book"></i> Catatan Wali Kelas</span></a></li>
                    <?php
                  }
                  ?>
                  <li><a><i class="fa fa-user"></i> Data Guru & Kariawan <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url("index.php/guru/daftar_guru/"); ?>">Daftar Guru & Kariawan</a></li>
                      <li><a href="<?php echo base_url("index.php/guru/wali_kelas"); ?>">Daftar Wali Kelas</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
            <!-- /sidebar menu -->
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-user"></i><?php echo " $g->nama_guru"; ?>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="javascript:;"> Profile</a></li>
                    <li>
                      <a href="<?php echo base_url("index.php/guru/setting/".$g->id_guru); ?>">
                        <span>Settings</span>
                      </a>
                    </li>
                    <li><a href="javascript:;">Help</a></li>
                    <li><a href="<?php echo base_url('index.php/login/logout'); ?>"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->