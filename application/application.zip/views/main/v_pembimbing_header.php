<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Pembimbing Eskul area | SYSTEM INFORMASI NILAI </title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url(); ?>assets/template/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="<?php echo base_url(); ?>assets/template/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="<?php echo base_url(); ?>assets/template/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="<?php echo base_url(); ?>assets/template/vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>

    <!-- Custom Theme Style -->
    <link href="<?php echo base_url(); ?>assets/template/build/css/custom.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/template/vendors/dropzone/dist/min/dropzone.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="<?php echo base_url("index.php/guru"); ?>" class="site_title"><i class="fa fa-graduation-cap"></i> <span>P.Eskul Area!</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
                <br><center><img src="<?php echo base_url(); ?>assets/template/production/images/img.png" alt="..." width="50px" height="70px"></center>
              </div>
              <div class="profile_info">
                <span>Selamat datang,</span>
                <?php foreach($pembimbing_eskul as $p)?>
                <h2><?php echo $p->nama_pembimbing; ?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
              <h3>General</h3>
                <ul class="nav side-menu">
                  <li><a href="<?php echo base_url("index.php/pembimbing"); ?>"><i class="fa fa-home"></i> Home <span></span></a>
                  </li>
                  <li><a><i class="fa fa-edit"></i> Kelola Data <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url('index.php/pembimbing/tambah_peserta/'.$p->id_pembimbing); ?>">Tambah Peserta Extra<span></span></a></li>
                      <li><a href="<?php echo base_url('index.php/pembimbing/tambah_nilai/'.$p->id_pembimbing); ?>">Tambah Nilai Extra<span></span></a></li>
                      <li><a href="<?php echo base_url('index.php/pembimbing/tambah_prestasi_siswa/'.$p->id_pembimbing); ?>">Tambah Prestasi Siswa<span></span></a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-table"></i> Data <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url("index.php/pembimbing/daftar_peserta_eskul/"); ?>">Daftar Peserta Eskul</a></li>
                      <li><a href="<?php echo base_url("index.php/pembimbing/daftar_nilai"); ?>">Daftar Nilai Extra Kurikuler</a></li>
                      <li><a href="<?php echo base_url("index.php/pembimbing/daftar_prestasi_siswa"); ?>">Daftar Prestasi</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
              </div>

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-user"></i><?php echo " $p->nama_pembimbing"; ?>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="javascript:;"> Profile</a></li>
                    <li>
                      <a href="javascript:;">
                        <span class="badge bg-red pull-right">50%</span>
                        <span>Settings</span>
                      </a>
                    </li>
                    <li><a href="javascript:;">Help</a></li>
                    <li><a href="<?php echo base_url('index.php/login/logout'); ?>"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->
