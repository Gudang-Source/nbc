    <!-- page content -->
<?php foreach($rapot as $r){} ?>
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Rapot Siswa</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Cari!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><b>Laporan Hasil Belajar</b> Siswa Siswa SMA N 1 Rembang</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>

                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="" role="tabpanel" data-example-id="togglable-tabs">
                      <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Kurikulum 2013</a>
                        </li>
                        <li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">KTSP</a>
                        </li>
                      </ul>
                      <div id="myTabContent" class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
                          <div class="accordion" id="accordion" role="tablist" aria-multiselectable="true">
                      <div class="panel">
                        <a class="panel-heading collapsed" role="tab" id="headingTwo" data-toggle="collapse" data-parent="#accordion" href="#collapse" aria-expanded="false" aria-controls="collapseTwo">
                          <h4 class="panel-title">Lihat Halaman Rapot Lainnya</h4>
                        </a>
                        <div id="collapse" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                          <div class="panel-body">
                            <table>
                            <tr>
                              <td>
                                <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/rapot_lhb'); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <input type="hidden" name="nis" value="<?php echo $r->nis ?>">
                                <input type="hidden" name="ta" value="<?php echo $r->ta ?>">
                                <button id="send" type="submit" class="btn btn-primary">KTDPD</button></form>
                              </td>
                              <td>
                                <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/rapot_sikap'); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <input type="hidden" name="nis" value="<?php echo $r->nis ?>">
                                <input type="hidden" name="ta" value="<?php echo $r->ta ?>">
                                <button id="send" type="submit" class="btn btn-primary">SIKAP</button></form>
                              </td>
                              <td>
                                <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/rapotpk'); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <input type="hidden" name="nis" value="<?php echo $r->nis ?>">
                                <input type="hidden" name="ta" value="<?php echo $r->ta ?>">
                                <button id="send" type="submit" class="btn btn-primary">P&K</button></form>
                              </td>
                              <td>
                                <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/rapot_extra'); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <input type="hidden" name="nis" value="<?php echo $r->nis ?>">
                                <input type="hidden" name="ta" value="<?php echo $r->ta ?>">
                                <button id="send" type="submit" class="btn btn-primary">Extra</button></form>
                              </td>
                              <td>
                                <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/cetak_rapot_pdf_pk4'); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <input type="hidden" name="nis" value="<?php echo $r->nis ?>">
                                <input type="hidden" name="ta" value="<?php echo $r->ta ?>">
                                <button id="send" type="submit" class="btn btn-primary">Cetak PDF P&K 4</button></form>
                              </td>
                            </tr>
                          </table>
                          </div>
                        </div>
                      </div>
                      </div>
                          <table>
                            <tr>
                              <td width="750px">
                                <table >
                                  <tr>
                                    <td width="140px">Nama Sekolah</td>
                                    <td width="10px">:</td>
                                    <td>SMA N 1 Rembang , Purbalingga</td>
                                  </tr>
                                  <tr>
                                    <td width="140px">Alamat</td>
                                    <td width="10px">:</td>
                                    <td>Jalan Monumen Jendral Soedirman</td>
                                  </tr>
                                  <tr>
                                    <td width="140px"></td>
                                    <td width="10px"></td>
                                    <td>Rembang,Purbalingga 53356</td>
                                  </tr>
                                  <tr>
                                    <td width="140px">Nama Peserta Didik</td>
                                    <td width="10px">:</td>
                                    <td><?php echo "$r->nama_siswa"; ?></td>
                                  </tr>
                                  <tr>
                                    <td width="140px">Nomor Induk / NISN</td>
                                    <td width="10px">:</td>
                                    <td><?php echo "$r->nis / $r->nisn"; ?></td>
                                  </tr>
                                </table>
                              </td>
                              <td align="right" valign=top>
                                <table >
                                  <tr>
                                    <td width="100px">Kelas</td>
                                    <td width="10px">:</td>
                                    <td><?php echo "$r->nama_kelas"; ?></td>
                                  </tr>
                                  <tr>
                                    <td width="100px">semester</td>
                                    <td width="10px">:</td>
                                    <?php 
                                       $semester=substr($r->nama_ta,10);
                                       if ($semester==1) { ?>
                                         <td><?php echo "$semester / Ganjil"; ?></td>
                                         <?php
                                       }
                                       elseif ($semester==2) { ?>
                                         <td><?php echo "$semester / Genap"; ?></td>
                                         <?php
                                       }
                                     ?>
                                  </tr>
                                  <tr></tr>
                                  <tr>
                                    <td width="100px">Tahun Pelajaran</td>
                                    <td width="10px">:</td>
                                    <?php
                                    $ta=substr($r->nama_ta,0,9);
                                    ?>
                                    <td><?php echo "$ta"; ?></td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                          </table>
                          <br><br>
                          <h1>B. PENGETAHUAN DAN KETRAMPILAN</h1>
                          <br><br>
                          <table border="1" width="100%">
                            <tr>
                              <th rowspan="2"><center>No</center></th>
                              <th rowspan="2"><center>Matapelajaran</center></th>
                              <th rowspan="2"><center>KKM</center></th>
                              <th colspan="2"><center>Pengetahuan</center></th>
                              <th colspan="2"><center>Ketrampilan</center></th>
                            </tr>
                            <tr>
                              <th><center>Nilai</center></th>
                              <th><center>Predikat</center></th>
                              <th><center>Nilai</center></th>
                              <th><center>Predikat</center></th>
                            </tr>
                            <tr>
                              <td colspan="7">Kelompok A ( UMUM )</td>
                            </tr>
                            <?php 
                                $no=0;
                              foreach ($rapot_a as $a) { 
                                $no=$no+1;
                                $tampil_na=number_format($a->nilai_akhir,2);
                                $na_pembulatan=ceil($tampil_na);
                                ?>
                            <tr>
                              <td><?php echo "<center>$no</center>"; ?></td>
                              <td><?php echo "$a->nama_matapelajaran"; ?></td>
                              <td><?php echo "<center>$a->kkm</center>"; ?></td>
                              <td><?php echo "<center>$na_pembulatan</center>"; ?></td>
                              <?php
                                if ($na_pembulatan>=$a->batas1) {
                                    echo "<td align='center'>A</td>";
                                  }
                                elseif ($na_pembulatan>=$a->batas2 && $na_pembulatan<=$a->batas3) {
                                    echo "<td align='center'>B</td>";
                                  }
                                elseif ($na_pembulatan>=$a->batas4 && $na_pembulatan<=$a->batas5) {
                                    echo "<td align='center'>C</td>";
                                  }
                                elseif ($na_pembulatan<=$a->batas6) {
                                    echo "<td align='center'>D</td>";
                                  }
                              ?>
                                  <td><?php echo "<center>$a->nilai_ketrampilan</center>"; ?></td>
                              <?php
                                if ($a->nilai_ketrampilan>=$a->batas1) {
                                    echo "<td align='center'>A</td>";
                                  }
                                elseif ($a->nilai_ketrampilan>=$a->batas2 && $a->nilai_ketrampilan<=$a->batas3) {
                                    echo "<td align='center'>B</td>";
                                  }
                                elseif ($a->nilai_ketrampilan>=$a->batas4 && $a->nilai_ketrampilan<=$a->batas5) {
                                    echo "<td align='center'>C</td>";
                                  }
                                elseif ($a->nilai_ketrampilan<=$a->batas6) {
                                    echo "<td align='center'>D</td>";
                                  }
                              ?>
                            </tr>
                            <?php } ?>
                            <tr>
                              <td colspan="7">Kelompok B ( UMUM )</td>
                            </tr>
                            <?php 
                                $no=0;
                              foreach ($rapot_b as $b) { 
                                $no=$no+1;
                                $tampil_na=number_format($b->nilai_akhir,2);
                                $na_pembulatan=ceil($tampil_na);
                                ?>
                            <tr>
                              <td><?php echo "<center>$no</center>"; ?></td>
                              <td><?php echo "$b->nama_matapelajaran"; ?></td>
                              <td><?php echo "<center>$b->kkm</center>"; ?></td>
                              <td><?php echo "<center>$na_pembulatan</center>"; ?></td>
                              <?php
                                if ($na_pembulatan>=$b->batas1) {
                                    echo "<td align='center'>A</td>";
                                  }
                                elseif ($na_pembulatan>=$b->batas2 && $na_pembulatan<=$b->batas3) {
                                    echo "<td align='center'>B</td>";
                                  }
                                elseif ($na_pembulatan>=$b->batas4 && $na_pembulatan<=$b->batas5) {
                                    echo "<td align='center'>C</td>";
                                  }
                                elseif ($na_pembulatan<=$b->batas6) {
                                    echo "<td align='center'>D</td>";
                                  }
                              ?>
                                  <td><?php echo "<center>$b->nilai_ketrampilan</center>"; ?></td>
                                <?php
                                if ($b->nilai_ketrampilan>=$b->batas1) {
                                    echo "<td align='center'>A</td>";
                                  }
                                elseif ($b->nilai_ketrampilan>=$b->batas2 && $b->nilai_ketrampilan<=$b->batas3) {
                                    echo "<td align='center'>B</td>";
                                  }
                                elseif ($b->nilai_ketrampilan>=$b->batas4 && $b->nilai_ketrampilan<=$b->batas5) {
                                    echo "<td align='center'>C</td>";
                                  }
                                elseif ($b->nilai_ketrampilan<=$b->batas6) {
                                    echo "<td align='center'>D</td>";
                                  }
                              ?>
                            </tr>
                            <?php } ?>
                            <tr>
                              <td colspan="7">Peminatan</td>
                            </tr>
                            <?php 
                                $no=0;
                              foreach ($rapotpk3 as $p) { 
                                $no=$no+1;
                                $tampil_na=number_format($p->nilai_akhir,2);
                                $na_pembulatan=ceil($tampil_na);
                                ?>
                            <tr>
                              <td><?php echo "<center>$no</center>"; ?></td>
                              <td><?php echo "$p->nama_matapelajaran"; ?></td>
                              <td><?php echo "<center>$p->kkm</center>"; ?></td>
                              <td><?php echo "<center>$na_pembulatan</center>"; ?></td>
                              <?php
                                if ($na_pembulatan>=$p->batas1) {
                                    echo "<td align='center'>A</td>";
                                  }
                                elseif ($na_pembulatan>=$p->batas2 && $na_pembulatan<=$p->batas3) {
                                    echo "<td align='center'>B</td>";
                                  }
                                elseif ($na_pembulatan>=$p->batas4 && $na_pembulatan<=$p->batas5) {
                                    echo "<td align='center'>C</td>";
                                  }
                                elseif ($na_pembulatan<=$p->batas6) {
                                    echo "<td align='center'>D</td>";
                                  }
                              ?>
                                  <td><?php echo "<center>$p->nilai_ketrampilan</center>"; ?></td>
                                  <?php
                                if ($p->nilai_ketrampilan>=$p->batas1) {
                                    echo "<td align='center'>A</td>";
                                  }
                                elseif ($p->nilai_ketrampilan>=$p->batas2 && $p->nilai_ketrampilan<=$p->batas3) {
                                    echo "<td align='center'>B</td>";
                                  }
                                elseif ($p->nilai_ketrampilan>=$p->batas4 && $p->nilai_ketrampilan<=$p->batas5) {
                                    echo "<td align='center'>C</td>";
                                  }
                                elseif ($p->nilai_ketrampilan<=$p->batas6) {
                                    echo "<td align='center'>D</td>";
                                  }
                              ?>
                            </tr>
                            <?php } ?>
                            <tr>
                              <td colspan="7">Lintas Minat</td>
                            </tr>
                            <?php 
                                $no=0;
                              foreach ($rapotpk2 as $l) { 
                                $no=$no+1;
                                $tampil_na=number_format($l->nilai_akhir,2);
                                $na_pembulatan=ceil($tampil_na);
                                ?>
                            <tr>
                              <td><?php echo "<center>$no</center>"; ?></td>
                              <td><?php echo "$l->nama_matapelajaran"; ?></td>
                              <td><?php echo "<center>$l->kkm</center>"; ?></td>
                              <td><?php echo "<center>$na_pembulatan</center>"; ?></td>
                              <?php
                                if ($na_pembulatan>=$l->batas1) {
                                    echo "<td align='center'>A</td>";
                                  }
                                elseif ($na_pembulatan>=$l->batas2 && $na_pembulatan<=$l->batas3) {
                                    echo "<td align='center'>B</td>";
                                  }
                                elseif ($na_pembulatan>=$l->batas4 && $na_pembulatan<=$l->batas5) {
                                    echo "<td align='center'>C</td>";
                                  }
                                elseif ($na_pembulatan<=$l->batas6) {
                                    echo "<td align='center'>D</td>";
                                  }
                              ?>
                                  <td><?php echo "<center>$l->nilai_ketrampilan</center>"; ?></td>
                                <?php
                                if ($l->nilai_ketrampilan>=$l->batas1) {
                                    echo "<td align='center'>A</td>";
                                  }
                                elseif ($l->nilai_ketrampilan>=$l->batas2 && $l->nilai_ketrampilan<=$l->batas3) {
                                    echo "<td align='center'>B</td>";
                                  }
                                elseif ($l->nilai_ketrampilan>=$l->batas4 && $l->nilai_ketrampilan<=$l->batas5) {
                                    echo "<td align='center'>C</td>";
                                  }
                                elseif ($l->nilai_ketrampilan<=$l->batas6) {
                                    echo "<td align='center'>D</td>";
                                  }
                              ?>
                            </tr>
                            <?php } ?>
                          </table>
                          <br>
            <?php
            $tanggal1 = substr(date('d-m-Y'),0,1);
            $tanggal2 = substr(date('d-m-Y'),1,1);
            $bulan = substr(date('d-m-Y'),3,2);
            $tahun = substr(date('d-m-Y'),6,4);
            if ($bulan==01) {
              $b="Januari";
            }
            elseif ($bulan==02) {
              $b="Februari";
            }
            elseif ($bulan==03) {
              $b="Maret";
            }
            elseif ($bulan==04) {
              $b="April";
            }
            elseif ($bulan==05) {
              $b="Mei";
            }
            elseif ($bulan==06) {
              $b="Juni";
            }
            elseif ($bulan==07) {
              $b="Juli";
            }
            elseif ($bulan==08) {
              $b="Agustus";
            }
            elseif ($bulan==09) {
              $b="Sebtember";
            }
            elseif ($bulan==10) {
              $b="Oktober";
            }
            elseif ($bulan==11) {
              $b="November";
            }
            elseif ($bulan==12) {
              $b="Desember";
            }
            if ($tanggal1==1 || $tanggal1==2 || $tanggal1==3) {?>
              <p align="right"><?php echo "Purbalingga {$tanggal1}{$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            else{?>
              <p align="right"><?php echo "Purbalingga, {$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            ?>
            <table width="100%" >
            <tr></tr>
              <tbody>
                <tr>
                  <td><table width="200">
              <tbody>
                <tr>
                  <td><table width="300">
              <tbody>
                <tr>
                  <td>Orang Tua / Wali Peserta Didik</td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="400">
              <tbody>
                <tr>
                  <td>Wali Kelas</td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="200">
              <tbody>
                <tr>
                  <td>Kepala Sekolah</td>
                </tr>
              </tbody>
            </table>
            </td>
                </tr>
              </tbody>
            </table>
            <br>
            <br>
            <br>
            <br>
            <table width="100%" >
              <tbody>
                <tr>
                  <td><table width="200">
              <tbody>
                <tr>
                  <td><table width="300">
              <tbody>
                <tr>
                  <td>...................................................</td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="400">
                  <?php foreach($wali_kelas as $w)?>
              <tbody>
                <tr>
                <?php echo "<td>{$w->nama_guru}</td>"; ?>
                </tr>
                <tr>
                  <td><?php echo "NIP. {$w->nomor_induk}";?></td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="200">
                  <?php foreach($kepala_sekolah as $k)?>
              <tbody>
                <tr>
                  <?php echo "<td>{$k->nama_guru}</td>"; ?>
                </tr>
                <tr>
                  <td><?php echo "NIP. {$k->nomor_induk}";?></td>
                </tr>
              </tbody>
            </table>
            </td>
                </tr>
              </tbody>
            </table>
            </td>
                </tr>
              </tbody>
            </table>
                          <br><center>
                          <table>
                            <tr>
                              <td>
                                <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/rapotpk'); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <input type="hidden" name="nis" value="<?php echo $r->nis ?>">
                                <input type="hidden" name="ta" value="<?php echo $r->ta ?>">
                                <button id="send" type="submit" class="btn btn-primary btn-xs">Halaman 1</button></form>
                              </td>
                              <td>
                                <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/rapotpk2'); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <input type="hidden" name="nis" value="<?php echo $r->nis ?>">
                                <input type="hidden" name="ta" value="<?php echo $r->ta ?>">
                                <button id="send" type="submit" class="btn btn-primary btn-xs">Halaman 2</button></form>
                              </td>
                              <td>
                                <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/rapotpk3'); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <input type="hidden" name="nis" value="<?php echo $r->nis ?>">
                                <input type="hidden" name="ta" value="<?php echo $r->ta ?>">
                                <button id="send" type="submit" class="btn btn-primary btn-xs">Halaman 3</button></form>
                              </td>
                              <td>
                                <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/rapotpk4'); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <input type="hidden" name="nis" value="<?php echo $r->nis ?>">
                                <input type="hidden" name="ta" value="<?php echo $r->ta ?>">
                                <button id="send" type="submit" class="btn btn-warning btn-xs">Halaman 4</button></form>
                              </td>
                            </tr>
                          </table></center>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
                        <div class="accordion" id="accordion" role="tablist" aria-multiselectable="true">
                      <div class="panel">
                        <a class="panel-heading collapsed" role="tab" id="headingTwo" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                          <h4 class="panel-title">Lihat Halaman Rapot Lainnya</h4>
                        </a>
                        <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                          <div class="panel-body">
                            <a href="<?php echo base_url("index.php/akademik/rapot_lhb/".$r->nis); ?>" type="button" class="btn btn-primary">LHB</a>
                            <a href="<?php echo base_url("index.php/akademik/rapot_kks/".$r->nis); ?>" type="button" class="btn btn-primary">KKS</a>
                            <a href="<?php echo base_url("index.php/akademik/rapot_pd/".$r->nis); ?>" type="button" class="btn btn-primary">PD</a>
                            <a href="<?php echo base_url("index.php/akademik/cetak_rapot_pdf/".$r->nis); ?>" type="button" class="btn btn-primary">Cetak PDF LHB</a>
                          </div>
                        </div>
                      </div>
                      </div>
                          <h1 align="center">LAPORAN HASIL BELAJAR PESERTA DIDIK</h1>
          <h1 align="center">SMA NEGERI 1 REMBANG</h1>
            <table width="100%">
              <tbody>
                <tr>
                  <td><table width="200">
              <tbody>
                <tr>
                  <td>Nama Peserta Didik</td>
                  <td>:</td>
                  <td><b><?php echo "$r->nama_siswa";?></b></td>
                </tr>
                <tr>
                  <td>Nomor Induk</td>
                  <td>:</td>
                  <td><b><?php echo "$r->nis";?></td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="200" align="right">
              <tbody>
                <tr>
                  <td>Kelas / Semester</td>
                  <td>:</td>
                  <?php $semester = substr($r->nama_ta,10); 
                  $ta = substr($r->nama_ta,0,9); ?>
                  <td><b><?php echo "$r->nama_kelas / $semester";?></td>
                </tr>
                <tr>
                  <td>Tahun Pelajaran</td>
                  <td>:</td>
                  <td><b><?php echo "$ta";?></b></td>
                </tr>
              </tbody>
            </table>
            </td>
                </tr>
              </tbody>
            </table>

            <table width="100%" border="1">
              <tbody>
                <tr>
                  <td rowspan="3" width="5%" align="center"><b>No</b></td>
                  <td rowspan="3" align="center"><b>Komponen</b></td>
                  <td rowspan="3" width="5%" align="center"><b>Kriteria Ketuntasan minimum (KKM)</b></td>
                <td colspan="5" align="center"><b>Nilai Hasil Belajar</b></td>
                </tr>
                <tr>
                  <td colspan="2" align="center"><b>Pengetahuan</b></td>
                  <td colspan="2" align="center"><b>Praktik</b></td>
                <td align="center"><b>Sikap</b></td>
                </tr>
                <tr>
                  <td align="center"><b>Angka</b></td>
                  <td align="center"><b>Huruf</b></td>
                  <td align="center"><b>Angka</b></td>
                  <td align="center"><b>Huruf</b></td>
                  <td align="center"><b>predikat</b></td>
                </tr>
            <?php 
                            $no=0;
                                foreach($rapot as $r){
                                  $no=$no+1;
                echo "<tr>";
                  echo "<td align='center'>$no</td>";
                  echo "<td>{$r->nama_matapelajaran}</td>";
                  echo "<td align='center'>{$r->kkm}</td>";
                  $tampil_na=number_format($r->nilai_akhir,2);
                  $na_pembulatan=ceil($tampil_na);
                  echo "<td align='center'>{$na_pembulatan}</td>";
                  $angka1 = substr($na_pembulatan,0,1);
                  if ($angka1==1) {
                    $huruf1='Satu ';
                  }
                  elseif ($angka1==2) {
                    $huruf1='Dua ';
                  }
                  elseif ($angka1==3) {
                    $huruf1='Tiga ';
                  }
                  elseif ($angka1==4) {
                    $huruf1='Empat ';
                  }
                  elseif ($angka1==5) {
                    $huruf1='Lima ';
                  }
                  elseif ($angka1==6) {
                    $huruf1='Enam ';
                  }
                  elseif ($angka1==7) {
                    $huruf1='Tujuh ';
                  }
                  elseif ($angka1==8) {
                    $huruf1='Delapan ';
                  }
                  elseif ($angka1==9) {
                    $huruf1='Sembilan ';
                  }
                  elseif ($angka1==0) {
                    $huruf1='Nol ';
                  }
                  $angka2 = substr($na_pembulatan,1,1);
                  if ($angka2==1) {
                    $huruf2='Satu ';
                  }
                  elseif ($angka2==2) {
                    $huruf2='Dua ';
                  }
                  elseif ($angka2==3) {
                    $huruf2='Tiga ';
                  }
                  elseif ($angka2==4) {
                    $huruf2='Empat ';
                  }
                  elseif ($angka2==5) {
                    $huruf2='Lima ';
                  }
                  elseif ($angka2==6) {
                    $huruf2='Enam ';
                  }
                  elseif ($angka2==7) {
                    $huruf2='Tujuh ';
                  }
                  elseif ($angka2==8) {
                    $huruf2='Delapan ';
                  }
                  elseif ($angka2==9) {
                    $huruf2='Sembilan ';
                  }
                  elseif ($angka2==0) {
                    $huruf2='Nol ';
                  }
                  echo "<td align='center'>{$huruf1}{$huruf2}</td>";
                  echo "<td align='center'>{$r->nilai_praktek}</td>";
                  $angka_praktek1 = substr($r->nilai_praktek,0,1);
                  if ($angka_praktek1==1) {
                    $huruf_praktek1='Satu ';
                  }
                  elseif ($angka_praktek1==2) {
                    $huruf_praktek1='Dua ';
                  }
                  elseif ($angka_praktek1==3) {
                    $huruf_praktek1='Tiga ';
                  }
                  elseif ($angka_praktek1==4) {
                    $huruf_praktek1='Empat ';
                  }
                  elseif ($angka_praktek1==5) {
                    $huruf_praktek1='Lima ';
                  }
                  elseif ($angka_praktek1==6) {
                    $huruf_praktek1='Enam ';
                  }
                  elseif ($angka_praktek1==7) {
                    $huruf_praktek1='Tujuh ';
                  }
                  elseif ($angka_praktek1==8) {
                    $huruf_praktek1='Delapan ';
                  }
                  elseif ($angka_praktek1==9) {
                    $huruf_praktek1='Sembilan ';
                  }
                  elseif ($angka_praktek1==0) {
                    $huruf_praktek1='Nol ';
                  }
                  $angka_praktek2 = substr($r->nilai_praktek,1,1);
                  if ($angka_praktek2==1) {
                    $huruf_praktek2='Satu ';
                  }
                  elseif ($angka_praktek2==2) {
                    $huruf_praktek2='Dua ';
                  }
                  elseif ($angka_praktek2==3) {
                    $huruf_praktek2='Tiga ';
                  }
                  elseif ($angka_praktek2==4) {
                    $huruf_praktek2='Empat ';
                  }
                  elseif ($angka_praktek2==5) {
                    $huruf_praktek2='Lima ';
                  }
                  elseif ($angka_praktek2==6) {
                    $huruf_praktek2='Enam ';
                  }
                  elseif ($angka_praktek2==7) {
                    $huruf_praktek2='Tujuh ';
                  }
                  elseif ($angka_praktek2==8) {
                    $huruf_praktek2='Delapan ';
                  }
                  elseif ($angka_praktek2==9) {
                    $huruf_praktek2='Sembilan ';
                  }
                  elseif ($angka_praktek2==0) {
                    $huruf_praktek2='Nol ';
                  }

                  echo "<td align='center'>{$huruf_praktek1}{$huruf_praktek2}</td>";
                  echo "<td align='center'>{$r->sikap}</td>";
                echo "</tr>";
            }
                ?>
              </tbody>
            </table>
            <br>
            <?php
            $tanggal1 = substr(date('d-m-Y'),0,1);
            $tanggal2 = substr(date('d-m-Y'),1,1);
            $bulan = substr(date('d-m-Y'),3,2);
            $tahun = substr(date('d-m-Y'),6,4);
            if ($bulan==01) {
              $b="Januari";
            }
            elseif ($bulan==02) {
              $b="Februari";
            }
            elseif ($bulan==03) {
              $b="Maret";
            }
            elseif ($bulan==04) {
              $b="April";
            }
            elseif ($bulan==05) {
              $b="Mei";
            }
            elseif ($bulan==06) {
              $b="Juni";
            }
            elseif ($bulan==07) {
              $b="Juli";
            }
            elseif ($bulan==08) {
              $b="Agustus";
            }
            elseif ($bulan==09) {
              $b="Sebtember";
            }
            elseif ($bulan==10) {
              $b="Oktober";
            }
            elseif ($bulan==11) {
              $b="November";
            }
            elseif ($bulan==12) {
              $b="Desember";
            }
            if ($tanggal1==1 || $tanggal1==2 || $tanggal1==3) {?>
              <p align="right"><?php echo "Purbalingga {$tanggal1}{$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            else{?>
              <p align="right"><?php echo "Purbalingga, {$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            ?>
            <table width="100%" >
              <tbody>
                <tr>
                  <td><table width="200">
              <tbody>
                <tr>
                  <td><table width="300">
              <tbody>
                <tr>
                  <td>Orang Tua / Wali Peserta Didik</td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="400">
              <tbody>
                <tr>
                  <td>Wali Kelas</td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="200">
              <tbody>
                <tr>
                  <td>Kepala Sekolah</td>
                </tr>
              </tbody>
            </table>
            </td>
                </tr>
              </tbody>
            </table>
            <br>
            <br>
            <br>
            <br>
            <table width="100%" >
              <tbody>
                <tr>
                  <td><table width="200">
              <tbody>
                <tr>
                  <td><table width="300">
              <tbody>
                <tr>
                  <td>...................................................</td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="400">
                  <?php foreach($wali_kelas as $w)?>
              <tbody>
                <tr>
                <?php echo "<td>{$w->nama_guru}</td>"; ?>
                </tr>
                <tr>
                  <td><?php echo "NIP. {$w->nomor_induk}";?></td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="200">
                  <?php foreach($kepala_sekolah as $k)?>
              <tbody>
                <tr>
                  <?php echo "<td>{$k->nama_guru}</td>"; ?>
                </tr>
                <tr>
                  <td><?php echo "NIP. {$k->nomor_induk}";?></td>
                </tr>
              </tbody>
            </table>
            </td>
                </tr>
              </tbody>
            </table>
            </td>
                </tr>
              </tbody>
            </table>

                        </div>
                      </div>
                    </div>
                  
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Kerja Praktek Jurusan Teknik Informatika Universites Islam Indonesia by azizsembada
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/template/build/js/custom.min.js"></script>

    <!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
  </body>
</html>