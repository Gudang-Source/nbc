    <!-- page content -->
<?php foreach($rapot as $r){} ?>
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Rapot Siswa</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Cari!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><b>Pengembangan Diri & Akhlaq Mulia</b> Siswa Siswa SMA N 1 Rembang</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>

                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">


                    <div class="" role="tabpanel" data-example-id="togglable-tabs">
                      <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Kurikulum 2013</a>
                        </li>
                        <li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">KTSP</a>
                        </li>
                      </ul>
                      <div id="myTabContent" class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
                          <p>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache cliche tempor, williamsburg carles vegan helvetica. Reprehenderit butcher retro keffiyeh dreamcatcher
                            synth. Cosby sweater eu banh mi, qui irure terr.</p>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
                        <div class="accordion" id="accordion" role="tablist" aria-multiselectable="true">
                      <div class="panel">
                        <a class="panel-heading collapsed" role="tab" id="headingTwo" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                          <h4 class="panel-title">Lihat Halaman Rapot Lainnya</h4>
                        </a>
                        <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                          <div class="panel-body">
                            <table>
                            <tr>
                              <td>
                                <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/rapot_lhb'); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <input type="hidden" name="nis" value="<?php echo $r->nis ?>">
                                <input type="hidden" name="ta" value="<?php echo $r->ta ?>">
                                <button id="send" type="submit" class="btn btn-primary">LHB</button></form>
                              </td>
                              <td>
                                <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/rapot_kks'); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <input type="hidden" name="nis" value="<?php echo $r->nis ?>">
                                <input type="hidden" name="ta" value="<?php echo $r->ta ?>">
                                <button id="send" type="submit" class="btn btn-primary">KKS</button></form>
                              </td>
                              <td>
                                <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/rapot_pd'); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <input type="hidden" name="nis" value="<?php echo $r->nis ?>">
                                <input type="hidden" name="ta" value="<?php echo $r->ta ?>">
                                <button id="send" type="submit" class="btn btn-primary">PD</button></form>
                              </td>
                              <td>
                                <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/cetak_rapot_pdf_pd'); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <input type="hidden" name="nis" value="<?php echo $r->nis ?>">
                                <input type="hidden" name="ta" value="<?php echo $r->ta ?>">
                                <button id="send" type="submit" class="btn btn-primary">Cetak PDF PD</button></form>
                              </td>
                            </tr>
                          </table>
                          </div>
                        </div>
                      </div>
                      </div>
            <table width="100%">
              <tbody>
                <tr>
                  <td><table width="200">
              <tbody>
                <tr>
                  <td>Nama Peserta Didik</td>
                  <td>:</td>
                  <td><b><?php echo "$r->nama_siswa";?></b></td>
                </tr>
                <tr>
                  <td>Nomor Induk</td>
                  <td>:</td>
                  <td><b><?php echo "$r->nis";?></td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="200" align="right">
              <tbody>
                <tr>
                  <td>Kelas / Semester</td>
                  <td>:</td>
                  <?php $semester = substr($r->nama_ta,10); 
                  $ta = substr($r->nama_ta,0,9); ?>
                  <td><b><?php echo "$r->nama_kelas / $semester";?></td>
                </tr>
                <tr>
                  <td>Tahun Pelajaran</td>
                  <td>:</td>
                  <td><b><?php echo "$ta";?></b></td>
                </tr>
              </tbody>
            </table>
            </td>
                </tr>
              </tbody>
            </table>
            <br><br>
            <p><b>Pengembangan Diri</b></p>
            <br>
            <table width="100%" border="1">
              <tbody>
                <tr>
                  <td width="5%" align="center"><b>No</b></td>
                  <td align="center" width="25%"><b>Jenis Kegiatan</b></td></td>
                <td align="center"><b>Keterangan</b></td>
                </tr>
                <tr>
                  <td align="center"><b>A</b></td>
                  <td colspan="2"><b>Kegiatan Extra Kurikuler</b></td>
                </tr>
                  <?php 
                  $no=0;
                  foreach($nilai_eskul as $e){
                    $no=$no+1;
                    echo "<tr>";
                      echo "<td align='center'>$no</td>";
                      echo "<td>{$e->nama_eskul}</td>";
                      echo "<td>{$e->nilai_akhir}, {$e->komentar}</td>";
                    echo "</tr>";
                    } ?>
                <tr>
                  <td align="center"><b>B</b></td>
                  <td colspan="2"><b>Keikutsertaan dalam Organisasi/kegiatan di sekolah</b></td>
                </tr>
                <tr>
                  <td>-</td>
                  <td>-</td>
                  <td>-</td>
                </tr>
              </tbody>
            </table>
            <br><br>
            <p><b>Akhlaq Mulia Dan Kepribadian</b></p>
            <br>
            <table width="100%" border="1">
              <tbody>
                <tr>
                  <td width="5%" align="center"><b>No</b></td>
                  <td align="center" width="25%"><b>Aspek Yang Diniali</b></td></td>
                <td align="center"><b>Keterangan</b></td>
                </tr>
                  <?php 
                  $no=0;
                  foreach($rapot as $r){} ?>
                  <tr>
                    <td align="center">1</td>
                    <td>Kelakuan</td>
                    <td><?php echo "{$r->nilai_kelakuan}, {$r->komentar_kelakuan}"; ?></td>
                  </tr>
                  <tr>
                    <td align="center">2</td>
                    <td>Kerajinan Dan Kedisiplinan</td>
                    <td><?php echo "{$r->nilai_kerajinan}, {$r->komentar_kerajinan}"; ?></td>
                  </tr>
                  <tr>
                    <td align="center">3</td>
                    <td>Kerapihan</td>
                    <td><?php echo "{$r->nilai_kerapihan}, {$r->komentar_kerapihan}"; ?></td>
                  </tr>
                  <tr>
                    <td align="center">4</td>
                    <td>Kebersihan</td>
                    <td><?php echo "{$r->nilai_kebersihan}, {$r->komentar_kebersihan}"; ?></td>
                  </tr>
              </tbody>
            </table>
            <br><br>
            <p><b>Ketidak hadiran</b></p>
            <br>
            <table width="100%" border="1">
              <tbody>
                <tr>
                  <td width="5%" align="center"><b>No</b></td>
                  <td align="center" width="25%"><b>Alasan Kehadiran</b></td></td>
                <td align="center"><b>Lama</b></td>
                </tr>
                  <?php 
                  $no=0;
                  foreach($rapot as $r){} ?>
                  <tr>
                    <td align="center">1</td>
                    <td>Sakit</td>
                    <td><?php echo "{$r->s}  Hari"; ?></td>
                  </tr>
                  <tr>
                    <td align="center">2</td>
                    <td>Izin</td>
                    <td><?php echo "{$r->i} Hari"; ?></td>
                  </tr>
                  <tr>
                    <td align="center">3</td>
                    <td>Tanpa Keterangan</td>
                    <td><?php echo "{$r->a} Hari"; ?></td>
                  </tr>
              </tbody>
            </table>
            <br><br>
            <p><b>Catatan Wali Kelas</b></p>
            <br>
            <table width="100%" border="1">
              <tbody>
                <tr>
                  <td><b>-</b></td>
                </tr>
            </table>
            <br><br>
            <table width="100%" border="1">
              <tbody>
                <tr>
                  <td><b>Keterangan Kenaikan Kelas :</b></td>
                </tr>
            </table>
            <br>
            <?php
            $tanggal1 = substr(date('d-m-Y'),0,1);
            $tanggal2 = substr(date('d-m-Y'),1,1);
            $bulan = substr(date('d-m-Y'),3,2);
            $tahun = substr(date('d-m-Y'),6,4);
            if ($bulan==01) {
              $b="Januari";
            }
            elseif ($bulan==02) {
              $b="Februari";
            }
            elseif ($bulan==03) {
              $b="Maret";
            }
            elseif ($bulan==04) {
              $b="April";
            }
            elseif ($bulan==05) {
              $b="Mei";
            }
            elseif ($bulan==06) {
              $b="Juni";
            }
            elseif ($bulan==07) {
              $b="Juli";
            }
            elseif ($bulan==08) {
              $b="Agustus";
            }
            elseif ($bulan==09) {
              $b="Sebtember";
            }
            elseif ($bulan==10) {
              $b="Oktober";
            }
            elseif ($bulan==11) {
              $b="November";
            }
            elseif ($bulan==12) {
              $b="Desember";
            }
            if ($tanggal1==1 || $tanggal1==2 || $tanggal1==3) {?>
              <p align="right"><?php echo "Purbalingga {$tanggal1}{$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            else{?>
              <p align="right"><?php echo "Purbalingga, {$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            ?>
            <table width="100%" >
              <tbody>
                <tr>
                  <td><table width="200">
              <tbody>
                <tr>
                  <td><table width="300">
              <tbody>
                <tr>
                  <td>Orang Tua / Wali Peserta Didik</td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="400">
              <tbody>
                <tr>
                  <td>Wali Kelas</td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="200">
              <tbody>
                <tr>
                  <td>Kepala Sekolah</td>
                </tr>
              </tbody>
            </table>
            </td>
                </tr>
              </tbody>
            </table>
            <br>
            <br>
            <br>
            <br>
            <table width="100%" >
              <tbody>
                <tr>
                  <td><table width="200">
              <tbody>
                <tr>
                  <td><table width="300">
              <tbody>
                <tr>
                  <td>...................................................</td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="400">
                  <?php foreach($wali_kelas as $w)?>
              <tbody>
                <tr>
                <?php echo "<td>{$w->nama_guru}</td>"; ?>
                </tr>
                <tr>
                  <td><?php echo "NIP. {$w->nomor_induk}";?></td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="200">
                  <?php foreach($kepala_sekolah as $k)?>
              <tbody>
                <tr>
                  <?php echo "<td>{$k->nama_guru}</td>"; ?>
                </tr>
                <tr>
                  <td><?php echo "NIP. {$k->nomor_induk}";?></td>
                </tr>
              </tbody>
            </table>
            </td>
                </tr>
              </tbody>
            </table>
            </td>
                </tr>
              </tbody>
            </table>

                        </div>
                      </div>
                    </div>
                  
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Kerja Praktek Jurusan Teknik Informatika Universites Islam Indonesia by azizsembada
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/template/build/js/custom.min.js"></script>

    <!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
  </body>
</html>