         <style>
      .table1 {
    font-family: sans-serif;
    color: #232323;
    border-collapse: collapse;
}

.table1, .th, .td {
    border: 1px solid #999;
}
</style>
<table border="1" width="100%" class="table1">
                            <tr>
                              <th class="th" width="10">No.</th>
                              <th class="th" width="120">Mata Pelajaran</th>
                              <th class="th" width="100">Aspek</th>
                              <th class="th">Deskripsi</th>
                            </tr>
                            <tr>
                              <th class="th" colspan="4">Kelompok B ( Umum )</th>
                            </tr>
                            <?php 
                            $no=0;
                            foreach($rapotpk as $p){ 
                            $no=$no+1;
                            ?>
                            <tr>
                              <td class="td" rowspan="2"><?php echo "$no"; ?></td>
                              <td class="td" rowspan="2"><?php echo "$p->nama_matapelajaran"; ?></td>
                              <td class="td">Pengetahuan</td>
                              <td class="td"><?php echo "$p->komentar_pengetahuan"; ?></td>
                            </tr>
                            <tr>
                              <td class="td">Keterampi</td>
                              <td class="td"><?php echo "$p->komentar_keterampilan"; ?></td>
                            </tr>
                            <?php } ?>
                            <tr>
                              <th class="td" colspan="4">Kelompok C ( Peminatan )</th>
                            </tr>
                            <?php 
                            $no=0;
                            foreach($rapotpk2 as $a){ 
                            $no=$no+1;
                            ?>
                            <tr>
                              <td class="td" rowspan="2"><?php echo "$no"; ?></td>
                              <td class="td" rowspan="2"><?php echo "$a->nama_matapelajaran"; ?></td>
                              <td class="td">Pengetahuan</td>
                              <td class="td"><?php echo "$a->komentar_pengetahuan"; ?></td>
                            </tr>
                            <tr>
                              <td class="td">Keterampi</td>
                              <td class="td"><?php echo "$a->komentar_keterampilan"; ?></td>
                            </tr>
                            <?php } ?>
                          </table>