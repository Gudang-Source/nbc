    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Daftar Nilai Akhir Kelas X IPS</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Cari!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Data Nilai Akhir Siswa SMA N 1 Rembang</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>

                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  <div class="accordion" id="accordion" role="tablist" aria-multiselectable="true">
                    <div class="panel">
                        <a class="panel-heading collapsed" role="tab" id="headingOne" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                          <h4 class="panel-title">Tampilkan Data Berdasarkan Kelas</h4>
                        </a>
                        <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                          <div class="panel-body">
                            <p><strong>Pilih Kelas</strong>
                            </p>
                              <a href="<?php echo base_url("index.php/akademik/daftar_nilai_akhir_kelas_x_ipa"); ?>" type="button" class="btn btn-primary">SEMUA Kelas</a>
                            <?php
                            foreach($kelas as $k){?>
                            <a href="<?php echo base_url('index.php/akademik/daftar_nilai_akhir_kelas_x_ipa_kelas/'.$k->id_kelas); ?>" class="btn btn-primary" ><?php echo "$k->nama_kelas"; ?></a>
                            <?php
                            }
                            ?>
                          </div>
                        </div>
                      </div>
                      <div class="panel">
                        <a class="panel-heading collapsed" role="tab" id="headingTwo" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                          <h4 class="panel-title">Tampilkan Data Berdasarkan Matapelajaran</h4>
                        </a>
                        <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                          <div class="panel-body">
                            <p><strong>Pilih Mata Pelajaran</strong>
                            </p>
                              <a href="<?php echo base_url("index.php/akademik/daftar_nilai_akhir_kelas_x_ipa"); ?>" type="button" class="btn btn-primary">SEMUA MAPEL</a>
                            <?php
                            foreach($matapelajaran as $m){?>
                            <a href="<?php echo base_url('index.php/akademik/daftar_nilai_akhir_kelas_x_ipa_mapel/'.$m->id_matapelajaran); ?>" class="btn btn-primary" ><?php echo "$m->nama_matapelajaran"; ?></a>
                            <?php
                            }
                            ?>
                          </div>
                        </div>
                      </div>
                      <div class="panel">
                        <a class="panel-heading collapsed" role="tab" id="headingThree" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                          <h4 class="panel-title">Tampilkan Data Berdasarkan Kelas Dan Matapelajaran</h4>
                        </a>
                        <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                          <div class="panel-body">
                          <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/akademik/daftar_nilai_akhir_kelas_x_ipa_kelas_mapel'); ?>" method="post" novalidate>
                          <p><strong>Pilih Data Matapelajaran</strong>
                            </p>
                          <?php
                            foreach($matapelajaran as $m){?>
                              <label class="btn btn-primary" data-toggle-class="btn-primary" data-toggle-passive-class="btn-primary">
                              <input type="radio" name="matapelajaran" value="<?php echo "$m->id_matapelajaran" ?>"> &nbsp; <?php echo "$m->nama_matapelajaran"; ?> &nbsp;
                            </label>
                            <?php } ?>
                          <p><strong>Pilih Data Kelas</strong>
                            </p>
                              <?php
                              foreach($kelas as $k){?>
                            <label class="btn btn-primary" data-toggle-class="btn-primary" data-toggle-passive-class="btn-primary">
                              <input type="radio" name="kelas" value="<?php echo "$k->id_kelas" ?>"> &nbsp; <?php echo "$k->nama_kelas"; ?> &nbsp;
                            </label>
                              <?php } ?>
                                  <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                    <button id="send" type="submit" class="btn btn-success">Tampilkan</button>
                                  </div>
                                  </div>
                          </from>
                          </div>
                        </div>
                      </div>
                      </div>
                    <!-- end of accordion -->
                    <p class="text-muted font-13 m-b-30">
                      Jangan lupa untuk cek data dan jika terdapat kesalahan Segera !!! di perbaiki
                    </p>
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>NIS</th>
                          <th>Nama</th>
                          <th>Matapelajaran</th>
                          <th>Tahun Ajaran</th>
                          <th>Kelas</th>
                          <th>Nilai Tugas</th>
                          <th>Nilai Ulangan</th>
                          <th>Nilai UTS</th>
                          <th>Nilai UAS</th>
                          <th>Nilai Praktek</th>
                          <th>Nilai Akhir</th>
                          <th>Tindakan</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php 
                            $no=0;
                                foreach($nilai_akhir as $n){
                                $no=$no+1;
                                echo "<tr>";
                                echo "<td>$no</td>"; 
                                echo "<td>{$n->nis}</td>";?>
                                <td><a href="<?php echo base_url("index.php/akademik/rapot_lhb/".$n->nis); ?>" type="button" class="btn btn-primary btn-xs"><?php echo "{$n->nama_siswa}"; ?></a></td>
                                <?php
                                echo "<td>{$n->nama_matapelajaran}</td>";
                                echo "<td>{$n->nama_ta}</td>";
                                echo "<td>{$n->nama_kelas}</td>";
                                $nt=number_format($n->nilai_tugas,2);
                                echo "<td>{$nt}</td>";
                                $nu=number_format($n->nilai_ulangan,2);
                                echo "<td>{$nu}</td>";
                                echo "<td>{$n->uts}</td>";
                                echo "<td>{$n->uas}</td>";
                                $np=number_format($n->nilai_praktek,2);
                                echo "<td>{$np}</td>";
                                $nilai_akhir=($n->nilai_tugas+$n->nilai_ulangan+$n->uts+$n->uas)/4;
                                $na=number_format($nilai_akhir,2);
                                echo "<td>{$na}</td>";
                                ?>
                                <td><a href="<?php echo base_url("index.php/akademik/edit_nilai_akhir/".$n->id_nilai_akhir); ?>" type="button" class="btn btn-primary btn-xs">EDIT</a>
                                  <a href="<?php echo base_url("index.php/akademik/hapus_nilai_akhir/".$n->id_nilai_akhir); ?>" type="button" class="btn btn-danger btn-xs">HAPUS</a>
                  </td>
                  <?php
                              echo "</tr>";}
                        ?>
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Kerja Praktek Jurusan Teknik Informatika Universites Islam Indonesia by azizsembada
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/template/build/js/custom.min.js"></script>

    <!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
  </body>
</html>