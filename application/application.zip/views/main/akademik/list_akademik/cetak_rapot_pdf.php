    <!-- page content -->
    <style>
      .table1 {
    font-family: sans-serif;
    color: #232323;
    border-collapse: collapse;
}

.table1, .th, .td {
    border: 1px solid #999;
}
    </style>
<?php foreach($rapot as $r){} ?>
        <div class="right_col" role="main">
          <div class="">
            <div class="row">
                          <h4 align="center">LAPORAN HASIL BELAJAR PESERTA DIDIK</h4>
          <h4 align="center">SMA NEGERI 1 REMBANG</h4>
            <table width="100%">
              <tbody>
                <tr>
                  <td><table width="200">
              <tbody>
                <tr>
                  <td>Nama Peserta Didik</td>
                  <td>:</td>
                  <td><b><?php echo "$r->nama_siswa";?></b></td>
                </tr>
                <tr>
                  <td>Nomor Induk</td>
                  <td>:</td>
                  <td><b><?php echo "$r->nis";?></td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="200" align="right">
              <tbody>
                <tr>
                  <td align="right">Kelas / Semester</td>
                  <td>:</td>
                  <?php $semester = substr($r->nama_ta,10); 
                  $ta = substr($r->nama_ta,0,9); ?>
                  <td align="right"><b><?php echo "$r->nama_kelas / $semester";?></td>
                </tr>
                <tr>
                  <td align="right">Tahun Pelajaran</td>
                  <td>:</td>
                  <td align="right"><b><?php echo "$ta";?></b></td>
                </tr>
              </tbody>
            </table>
            </td>
                </tr>
              </tbody>
            </table>

            <table width="800" class="table1">
              <tbody>
                <tr>
                  <td rowspan="3" width="5%" align="center" width="5" class="td"><b>No</b></td>
                  <td rowspan="3" align="center" width="200" class="td"><b>Komponen</b></td>
                  <td rowspan="3" width="5%" align="center" class="td"><b>Kriteria Ketuntasan minimum (KKM)</b></td>
                <td colspan="5" align="center" class="td"><b>Nilai Hasil Belajar</b></td>
                </tr>
                <tr>
                  <td colspan="2" align="center" class="td"><b>Pengetahuan</b></td>
                  <td colspan="2" align="center" class="td"><b>Praktik</b></td>
                <td align="center" class="td"><b>Sikap</b></td>
                </tr>
                <tr>
                  <td align="center" class="td" width="10"><b>Angka</b></td>
                  <td align="center" class="td" width="80"><b>Huruf</b></td>
                  <td align="center" class="td" width="10"><b>Angka</b></td>
                  <td align="center" class="td" width="80"><b>Huruf</b></td>
                  <td align="center" class="td" width="10"><b>predikat</b></td>
                </tr>
            <?php 
                            $no=0;
                                foreach($rapot as $r){
                                  $no=$no+1;
                echo "<tr>";
                  echo "<td align='center' class='td'>$no</td>";
                  echo "<td class='td'>{$r->nama_matapelajaran}</td>";
                  echo "<td align='center' class='td'>{$r->kkm}</td>";
                  $tampil_na=number_format($r->nilai_akhir,2);
                  $na_pembulatan=ceil($tampil_na);
                  echo "<td align='center' class='td'>{$na_pembulatan}</td>";
                  $angka1 = substr($na_pembulatan,0,1);
                  if ($angka1==1) {
                    $huruf1='Satu ';
                  }
                  elseif ($angka1==2) {
                    $huruf1='Dua ';
                  }
                  elseif ($angka1==3) {
                    $huruf1='Tiga ';
                  }
                  elseif ($angka1==4) {
                    $huruf1='Empat ';
                  }
                  elseif ($angka1==5) {
                    $huruf1='Lima ';
                  }
                  elseif ($angka1==6) {
                    $huruf1='Enam ';
                  }
                  elseif ($angka1==7) {
                    $huruf1='Tujuh ';
                  }
                  elseif ($angka1==8) {
                    $huruf1='Delapan ';
                  }
                  elseif ($angka1==9) {
                    $huruf1='Sembilan ';
                  }
                  elseif ($angka1==0) {
                    $huruf1='Nol ';
                  }
                  $angka2 = substr($na_pembulatan,1,1);
                  if ($angka2==1) {
                    $huruf2='Satu ';
                  }
                  elseif ($angka2==2) {
                    $huruf2='Dua ';
                  }
                  elseif ($angka2==3) {
                    $huruf2='Tiga ';
                  }
                  elseif ($angka2==4) {
                    $huruf2='Empat ';
                  }
                  elseif ($angka2==5) {
                    $huruf2='Lima ';
                  }
                  elseif ($angka2==6) {
                    $huruf2='Enam ';
                  }
                  elseif ($angka2==7) {
                    $huruf2='Tujuh ';
                  }
                  elseif ($angka2==8) {
                    $huruf2='Delapan ';
                  }
                  elseif ($angka2==9) {
                    $huruf2='Sembilan ';
                  }
                  elseif ($angka2==0) {
                    $huruf2='Nol ';
                  }
                  echo "<td align='center' class='td'>{$huruf1}{$huruf2}</td>";
                  echo "<td align='center' class='td'>{$r->nilai_praktek}</td>";
                  $angka_praktek1 = substr($r->nilai_praktek,0,1);
                  if ($angka_praktek1==1) {
                    $huruf_praktek1='Satu ';
                  }
                  elseif ($angka_praktek1==2) {
                    $huruf_praktek1='Dua ';
                  }
                  elseif ($angka_praktek1==3) {
                    $huruf_praktek1='Tiga ';
                  }
                  elseif ($angka_praktek1==4) {
                    $huruf_praktek1='Empat ';
                  }
                  elseif ($angka_praktek1==5) {
                    $huruf_praktek1='Lima ';
                  }
                  elseif ($angka_praktek1==6) {
                    $huruf_praktek1='Enam ';
                  }
                  elseif ($angka_praktek1==7) {
                    $huruf_praktek1='Tujuh ';
                  }
                  elseif ($angka_praktek1==8) {
                    $huruf_praktek1='Delapan ';
                  }
                  elseif ($angka_praktek1==9) {
                    $huruf_praktek1='Sembilan ';
                  }
                  elseif ($angka_praktek1==0) {
                    $huruf_praktek1='Nol ';
                  }
                  $angka_praktek2 = substr($r->nilai_praktek,1,1);
                  if ($angka_praktek2==1) {
                    $huruf_praktek2='Satu ';
                  }
                  elseif ($angka_praktek2==2) {
                    $huruf_praktek2='Dua ';
                  }
                  elseif ($angka_praktek2==3) {
                    $huruf_praktek2='Tiga ';
                  }
                  elseif ($angka_praktek2==4) {
                    $huruf_praktek2='Empat ';
                  }
                  elseif ($angka_praktek2==5) {
                    $huruf_praktek2='Lima ';
                  }
                  elseif ($angka_praktek2==6) {
                    $huruf_praktek2='Enam ';
                  }
                  elseif ($angka_praktek2==7) {
                    $huruf_praktek2='Tujuh ';
                  }
                  elseif ($angka_praktek2==8) {
                    $huruf_praktek2='Delapan ';
                  }
                  elseif ($angka_praktek2==9) {
                    $huruf_praktek2='Sembilan ';
                  }
                  elseif ($angka_praktek2==0) {
                    $huruf_praktek2='Nol ';
                  }

                  echo "<td align='center' class='td'>{$huruf_praktek1}{$huruf_praktek2}</td>";
                  echo "<td align='center' class='td'>{$r->sikap}</td>";
                echo "</tr>";
            }
                ?>
              </tbody>
            </table>
            <br>
            <?php
            $tanggal1 = substr(date('d-m-Y'),0,1);
            $tanggal2 = substr(date('d-m-Y'),1,1);
            $bulan = substr(date('d-m-Y'),3,2);
            $tahun = substr(date('d-m-Y'),6,4);
            if ($bulan==01) {
              $b="Januari";
            }
            elseif ($bulan==02) {
              $b="Februari";
            }
            elseif ($bulan==03) {
              $b="Maret";
            }
            elseif ($bulan==04) {
              $b="April";
            }
            elseif ($bulan==05) {
              $b="Mei";
            }
            elseif ($bulan==06) {
              $b="Juni";
            }
            elseif ($bulan==07) {
              $b="Juli";
            }
            elseif ($bulan==08) {
              $b="Agustus";
            }
            elseif ($bulan==09) {
              $b="Sebtember";
            }
            elseif ($bulan==10) {
              $b="Oktober";
            }
            elseif ($bulan==11) {
              $b="November";
            }
            elseif ($bulan==12) {
              $b="Desember";
            }
            if ($tanggal1==1) {?>
              <p align="right"><?php echo "Purbalingga {$tanggal1}{$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            else{?>
              <p align="right"><?php echo "Purbalingga, {$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            ?>
            <table width="800">
  <tbody>
    <tr>
      <td width="200">Orang Tua/Wali Peserta Didik</td>
      <td width="200">Wali Kelas</td>
      <td width="400">Kepala Sekolah</td>
    </tr>
    <tr>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
    </tr>
    <?php foreach($wali_kelas as $w)?>
    <?php foreach($kepala_sekolah as $k)?>
    <tr>
      <td rowspan="2">...........................................................</td>
      <?php echo "<td>{$w->nama_guru}</td>"; ?>
      <?php echo "<td>{$k->nama_guru}</td>"; ?>
    </tr>
    <tr>
      <td><?php echo "NIP. {$w->nomor_induk}";?></td>
      <td><?php echo "NIP. {$k->nomor_induk}";?></td>
    </tr>
  </tbody>
</table>
          </div>
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/template/build/js/custom.min.js"></script>

    <!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
  </body>
</html>