        <style>
      .table1 {
    font-family: sans-serif;
    color: #232323;
    border-collapse: collapse;
}

.table1, .th, .td {
    border: 1px solid #999;
}
</style>
<?php foreach ($rapot as $r) {} ?>
                          <table width="100%">
                            <tr>
                              <td width="350">
                                <table >
                                  <tr>
                                    <td width="100">Nama Sekolah</td>
                                    <td width="1">:</td>
                                    <td>SMA N 1 Rembang , Purbalingga</td>
                                  </tr>
                                  <tr>
                                    <td >Alamat</td>
                                    <td >:</td>
                                    <td>Jalan Monumen Jendral Soedirman</td>
                                  </tr>
                                  <tr>
                                    <td ></td>
                                    <td ></td>
                                    <td>Rembang,Purbalingga 53356</td>
                                  </tr>
                                  <tr>
                                    <td >Nama Peserta Didik</td>
                                    <td >:</td>
                                    <td><?php echo "$r->nama_siswa"; ?></td>
                                  </tr>
                                  <tr>
                                    <td >Nomor Induk / NISN</td>
                                    <td >:</td>
                                    <td><?php echo "$r->nis / $r->nisn"; ?></td>
                                  </tr>
                                </table>
                              </td>
                              <td align="right" valign="top" width="150">
                                <table >
                                  <tr>
                                    <td width="50" >Kelas</td>
                                    <td >:</td>
                                    <td><?php echo "$r->nama_kelas"; ?></td>
                                  </tr>
                                  <tr>
                                    <td >semester</td>
                                    <td >:</td>
                                    <?php 
                                       $semester=substr($r->nama_ta,10);
                                       if ($semester==1) { ?>
                                         <td><?php echo "$semester / Ganjil"; ?></td>
                                         <?php
                                       }
                                       elseif ($semester==2) { ?>
                                         <td><?php echo "$semester / Genap"; ?></td>
                                         <?php
                                       }
                                     ?>
                                  </tr>
                                  <tr>
                                    <td >Tahun Pelajaran</td>
                                    <td >:</td>
                                    <?php
                                    $ta=substr($r->nama_ta,0,9);
                                    ?>
                                    <td><?php echo "$ta"; ?></td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                          </table>
<br>
<h3>B. PENGETAHUAN DAN KETRAMPILAN</h3>
                          <br>
                          <table border="1" width="100%" class="table1">
                            <tr>
                              <th class="th" rowspan="2"><center>No</center></th>
                              <th class="th" rowspan="2"><center>Matapelajaran</center></th>
                              <th class="th" rowspan="2"><center>KKM</center></th>
                              <th class="th" colspan="2"><center>Pengetahuan</center></th>
                              <th class="th" colspan="2"><center>Ketrampilan</center></th>
                            </tr>
                            <tr>
                              <th class="th" ><center>Nilai</center></th>
                              <th class="th"><center>Predikat</center></th>
                              <th class="th"><center>Nilai</center></th>
                              <th class="th"><center>Predikat</center></th>
                            </tr>
                            <tr>
                              <td class="td" colspan="7">Kelompok A ( UMUM )</td>
                            </tr>
                            <?php 
                                $no=0;
                              foreach ($rapot_a as $a) { 
                                $no=$no+1;
                                $tampil_na=number_format($a->nilai_akhir,2);
                                $na_pembulatan=ceil($tampil_na);
                                ?>
                            <tr>
                              <td class="td"><?php echo "<center>$no</center>"; ?></td>
                              <td class="td"><?php echo "$a->nama_matapelajaran"; ?></td>
                              <td class="td"><?php echo "<center>$a->kkm</center>"; ?></td>
                              <td class="td"><?php echo "<center>$na_pembulatan</center>"; ?></td>
                              <?php
                                if ($na_pembulatan>=$a->batas1) {
                                    echo "<td class='td' align='center'>A</td>";
                                  }
                                elseif ($na_pembulatan>=$a->batas2 && $na_pembulatan<=$a->batas3) {
                                    echo "<td class='td' align='center'>B</td>";
                                  }
                                elseif ($na_pembulatan>=$a->batas4 && $na_pembulatan<=$a->batas5) {
                                    echo "<td class='td' align='center'>C</td>";
                                  }
                                elseif ($na_pembulatan<=$a->batas6) {
                                    echo "<td class='td' align='center'>D</td>";
                                  }
                              ?>
                                  <td class="td"><?php echo "<center>$a->nilai_ketrampilan</center>"; ?></td>
                              <?php
                                if ($a->nilai_ketrampilan>=$a->batas1) {
                                    echo "<td class='td' align='center'>A</td>";
                                  }
                                elseif ($a->nilai_ketrampilan>=$a->batas2 && $a->nilai_ketrampilan<=$a->batas3) {
                                    echo "<td class='td' align='center'>B</td>";
                                  }
                                elseif ($a->nilai_ketrampilan>=$a->batas4 && $a->nilai_ketrampilan<=$a->batas5) {
                                    echo "<td class='td' align='center'>C</td>";
                                  }
                                elseif ($a->nilai_ketrampilan<=$a->batas6) {
                                    echo "<td class='td' align='center'>D</td>";
                                  }
                              ?>
                            </tr>
                            <?php } ?>
                            <tr>
                              <td class="td" colspan="7">Kelompok B ( UMUM )</td>
                            </tr>
                            <?php 
                                $no=0;
                              foreach ($rapot_b as $b) { 
                                $no=$no+1;
                                $tampil_na=number_format($b->nilai_akhir,2);
                                $na_pembulatan=ceil($tampil_na);
                                ?>
                            <tr>
                              <td class="td"><?php echo "<center>$no</center>"; ?></td>
                              <td class="td"><?php echo "$b->nama_matapelajaran"; ?></td>
                              <td class="td"><?php echo "<center>$b->kkm</center>"; ?></td>
                              <td class="td"><?php echo "<center>$na_pembulatan</center>"; ?></td>
                              <?php
                                if ($na_pembulatan>=$b->batas1) {
                                    echo "<td class='td' align='center'>A</td>";
                                  }
                                elseif ($na_pembulatan>=$b->batas2 && $na_pembulatan<=$b->batas3) {
                                    echo "<td class='td' align='center'>B</td>";
                                  }
                                elseif ($na_pembulatan>=$b->batas4 && $na_pembulatan<=$b->batas5) {
                                    echo "<td class='td' align='center'>C</td>";
                                  }
                                elseif ($na_pembulatan<=$b->batas6) {
                                    echo "<td class='td' align='center'>D</td>";
                                  }
                              ?>
                                  <td class="td"><?php echo "<center>$b->nilai_ketrampilan</center>"; ?></td>
                                <?php
                                if ($b->nilai_ketrampilan>=$b->batas1) {
                                    echo "<td class='td' align='center'>A</td>";
                                  }
                                elseif ($b->nilai_ketrampilan>=$b->batas2 && $b->nilai_ketrampilan<=$b->batas3) {
                                    echo "<td class='td' align='center'>B</td>";
                                  }
                                elseif ($b->nilai_ketrampilan>=$b->batas4 && $b->nilai_ketrampilan<=$b->batas5) {
                                    echo "<td class='td' align='center'>C</td>";
                                  }
                                elseif ($b->nilai_ketrampilan<=$b->batas6) {
                                    echo "<td class='td' align='center'>D</td>";
                                  }
                              ?>
                            </tr>
                            <?php } ?>
                            <tr>
                              <td class="td" colspan="7">Peminatan</td>
                            </tr>
                            <?php 
                                $no=0;
                              foreach ($rapotpk3 as $p) { 
                                $no=$no+1;
                                $tampil_na=number_format($p->nilai_akhir,2);
                                $na_pembulatan=ceil($tampil_na);
                                ?>
                            <tr>
                              <td class="td"><?php echo "<center>$no</center>"; ?></td>
                              <td class="td"><?php echo "$p->nama_matapelajaran"; ?></td>
                              <td class="td"><?php echo "<center>$p->kkm</center>"; ?></td>
                              <td class="td"><?php echo "<center>$na_pembulatan</center>"; ?></td>
                              <?php
                                if ($na_pembulatan>=$p->batas1) {
                                    echo "<td class='td' align='center'>A</td>";
                                  }
                                elseif ($na_pembulatan>=$p->batas2 && $na_pembulatan<=$p->batas3) {
                                    echo "<td class='td' align='center'>B</td>";
                                  }
                                elseif ($na_pembulatan>=$p->batas4 && $na_pembulatan<=$p->batas5) {
                                    echo "<td class='td' align='center'>C</td>";
                                  }
                                elseif ($na_pembulatan<=$p->batas6) {
                                    echo "<td class='td' align='center'>D</td>";
                                  }
                              ?>
                                  <td class="td"><?php echo "<center>$p->nilai_ketrampilan</center>"; ?></td>
                                  <?php
                                if ($p->nilai_ketrampilan>=$p->batas1) {
                                    echo "<td class='td' align='center'>A</td>";
                                  }
                                elseif ($p->nilai_ketrampilan>=$p->batas2 && $p->nilai_ketrampilan<=$p->batas3) {
                                    echo "<td class='td' align='center'>B</td>";
                                  }
                                elseif ($p->nilai_ketrampilan>=$p->batas4 && $p->nilai_ketrampilan<=$p->batas5) {
                                    echo "<td class='td' align='center'>C</td>";
                                  }
                                elseif ($p->nilai_ketrampilan<=$p->batas6) {
                                    echo "<td class='td' align='center'>D</td>";
                                  }
                              ?>
                            </tr>
                            <?php } ?>
                            <tr>
                              <td class="td" colspan="7">Lintas Minat</td>
                            </tr>
                            <?php 
                                $no=0;
                              foreach ($rapotpk2 as $l) { 
                                $no=$no+1;
                                $tampil_na=number_format($l->nilai_akhir,2);
                                $na_pembulatan=ceil($tampil_na);
                                ?>
                            <tr>
                              <td class="td"><?php echo "<center>$no</center>"; ?></td>
                              <td class="td"><?php echo "$l->nama_matapelajaran"; ?></td>
                              <td class="td"><?php echo "<center>$l->kkm</center>"; ?></td>
                              <td class="td"><?php echo "<center>$na_pembulatan</center>"; ?></td>
                              <?php
                                if ($na_pembulatan>=$l->batas1) {
                                    echo "<td class='td' align='center'>A</td>";
                                  }
                                elseif ($na_pembulatan>=$l->batas2 && $na_pembulatan<=$l->batas3) {
                                    echo "<td class='td' align='center'>B</td>";
                                  }
                                elseif ($na_pembulatan>=$l->batas4 && $na_pembulatan<=$l->batas5) {
                                    echo "<td class='td' align='center'>C</td>";
                                  }
                                elseif ($na_pembulatan<=$l->batas6) {
                                    echo "<td class='td' align='center'>D</td>";
                                  }
                              ?>
                                  <td class="td"><?php echo "<center>$l->nilai_ketrampilan</center>"; ?></td>
                                <?php
                                if ($l->nilai_ketrampilan>=$l->batas1) {
                                    echo "<td class='td' align='center'>A</td>";
                                  }
                                elseif ($l->nilai_ketrampilan>=$l->batas2 && $l->nilai_ketrampilan<=$l->batas3) {
                                    echo "<td class='td' align='center'>B</td>";
                                  }
                                elseif ($l->nilai_ketrampilan>=$l->batas4 && $l->nilai_ketrampilan<=$l->batas5) {
                                    echo "<td class='td' align='center'>C</td>";
                                  }
                                elseif ($l->nilai_ketrampilan<=$l->batas6) {
                                    echo "<td class='td' align='center'>D</td>";
                                  }
                              ?>
                            </tr>
                            <?php } ?>
                          </table>
                                                    <br>
            <?php
            $tanggal1 = substr(date('d-m-Y'),0,1);
            $tanggal2 = substr(date('d-m-Y'),1,1);
            $bulan = substr(date('d-m-Y'),3,2);
            $tahun = substr(date('d-m-Y'),6,4);
            if ($bulan==01) {
              $b="Januari";
            }
            elseif ($bulan==02) {
              $b="Februari";
            }
            elseif ($bulan==03) {
              $b="Maret";
            }
            elseif ($bulan==04) {
              $b="April";
            }
            elseif ($bulan==05) {
              $b="Mei";
            }
            elseif ($bulan==06) {
              $b="Juni";
            }
            elseif ($bulan==07) {
              $b="Juli";
            }
            elseif ($bulan==08) {
              $b="Agustus";
            }
            elseif ($bulan==09) {
              $b="Sebtember";
            }
            elseif ($bulan==10) {
              $b="Oktober";
            }
            elseif ($bulan==11) {
              $b="November";
            }
            elseif ($bulan==12) {
              $b="Desember";
            }
            if ($tanggal1==1 || $tanggal1==2 || $tanggal1==3) {?>
              <p align="right"><?php echo "Purbalingga {$tanggal1}{$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            else{?>
              <p align="right"><?php echo "Purbalingga, {$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            ?>
            <table width="800">
  <tbody>
    <tr>
      <td width="200">Orang Tua/Wali Peserta Didik</td>
      <td width="200">Wali Kelas</td>
      <td width="400">Kepala Sekolah</td>
    </tr>
    <tr>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
    </tr>
    <?php foreach($wali_kelas as $w)?>
    <?php foreach($kepala_sekolah as $k)?>
    <tr>
      <td rowspan="2">...........................................................</td>
      <?php echo "<td>{$w->nama_guru}</td>"; ?>
      <?php echo "<td>{$k->nama_guru}</td>"; ?>
    </tr>
    <tr>
      <td><?php echo "NIP. {$w->nomor_induk}";?></td>
      <td><?php echo "NIP. {$k->nomor_induk}";?></td>
    </tr>
  </tbody>
</table>