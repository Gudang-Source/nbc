        <style>
      .table1 {
    font-family: sans-serif;
    color: #232323;
    border-collapse: collapse;
}

.table1, .th, .td {
    border: 1px solid #999;
}
</style>
<table border="1" width="100%" class="table1">
                            <tr>
                              <th class="th" width="10">No.</th>
                              <th class="th" width="150">Mata Pelajaran</th>
                              <th class="th" width="100">Aspek</th>
                              <th class="th">Deskripsi</th>
                            </tr>
                            <tr>
                              <th class="th" colspan="4" align="left">Lintas Minat</th>
                            </tr>
                            <?php 
                            $no=0;
                            foreach($rapotpk2 as $p){ 
                            $no=$no+1;
                            ?>
                            <tr>
                              <td class="td" rowspan="2"><?php echo "$no"; ?></td>
                              <td class="td" rowspan="2"><?php echo "$p->nama_matapelajaran"; ?></td>
                              <td class="td">Pengetahuan</td>
                              <td class="td"><?php echo "$p->komentar_pengetahuan"; ?></td>
                            </tr>
                            <tr>
                              <td class="td">Keterampi</td>
                              <td class="td"><?php echo "$p->komentar_keterampilan"; ?></td>
                            </tr>
                            <?php } ?>
                          </table>
                          <br>
            <?php
            $tanggal1 = substr(date('d-m-Y'),0,1);
            $tanggal2 = substr(date('d-m-Y'),1,1);
            $bulan = substr(date('d-m-Y'),3,2);
            $tahun = substr(date('d-m-Y'),6,4);
            if ($bulan==01) {
              $b="Januari";
            }
            elseif ($bulan==02) {
              $b="Februari";
            }
            elseif ($bulan==03) {
              $b="Maret";
            }
            elseif ($bulan==04) {
              $b="April";
            }
            elseif ($bulan==05) {
              $b="Mei";
            }
            elseif ($bulan==06) {
              $b="Juni";
            }
            elseif ($bulan==07) {
              $b="Juli";
            }
            elseif ($bulan==08) {
              $b="Agustus";
            }
            elseif ($bulan==09) {
              $b="Sebtember";
            }
            elseif ($bulan==10) {
              $b="Oktober";
            }
            elseif ($bulan==11) {
              $b="November";
            }
            elseif ($bulan==12) {
              $b="Desember";
            }
            if ($tanggal1==1 || $tanggal1==2 || $tanggal1==3) {?>
              <p align="right"><?php echo "Purbalingga {$tanggal1}{$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            else{?>
              <p align="right"><?php echo "Purbalingga, {$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            ?>
            <table width="800">
  <tbody>
    <tr>
      <td width="200">Orang Tua/Wali Peserta Didik</td>
      <td width="200">Wali Kelas</td>
      <td width="400">Kepala Sekolah</td>
    </tr>
    <tr>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
    </tr>
    <?php foreach($wali_kelas as $w)?>
    <?php foreach($kepala_sekolah as $k)?>
    <tr>
      <td rowspan="2">...........................................................</td>
      <?php echo "<td>{$w->nama_guru}</td>"; ?>
      <?php echo "<td>{$k->nama_guru}</td>"; ?>
    </tr>
    <tr>
      <td><?php echo "NIP. {$w->nomor_induk}";?></td>
      <td><?php echo "NIP. {$k->nomor_induk}";?></td>
    </tr>
  </tbody>
</table>