 		<!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Daftar <small>Semua Guru SMA N 1 Rembang Purbalingga</small></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Cari!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Data Guru SMA N 1 Rembang</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>

                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                      Jangan lupa untuk cek data dan jika terdapat kesalahan Segera !!! di perbaiki
                    </p>
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Nama Guru</th>
                          <th>Mata Pelajaran</th>
                          <th>Tahun Ajaran</th>
                          <th>kelas</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php 
                            $no=0;
                                foreach($ajar as $a){
                                $no=$no+1;
                                echo "<tr>";
                                echo "<td>$no</td>"; 
                                echo "<td>{$a->nama_guru}</td>";
                                echo "<td>{$a->nama_matapelajaran}</td>";
                                echo "<td>{$a->ta}</td>";
                                ?>

                                <td>
                                <?php
                                if ($a->kelas1!=0) {
                                  echo "{$a->nama_kelas} "; 
                                }
                                if ($a->kelas2!=0) {
                                  if ($a->kelas2==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas2==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas2==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas2==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas2==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas2==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas2==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas2==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas2==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas2==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas2==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas2==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas2==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas2==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas2==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas2==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas2==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas2==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas2==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas2==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas2==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas2==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas2==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas2==24) {
                                    echo "XII IPS 4 ";
                                  }    
                                }
                                if ($a->kelas3!=0) {
                                  if ($a->kelas3==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas3==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas3==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas3==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas3==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas3==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas3==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas3==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas3==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas3==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas3==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas3==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas3==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas3==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas3==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas3==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas3==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas3==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas3==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas3==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas3==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas3==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas3==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas3==24) {
                                    echo "XII IPS 4 ";
                                  } 
                                }
                                if ($a->kelas4!=0) {
                                  if ($a->kelas4==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas4==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas4==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas4==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas4==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas4==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas4==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas4==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas4==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas4==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas4==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas4==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas4==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas4==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas4==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas4==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas4==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas4==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas4==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas4==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas4==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas4==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas4==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas4==24) {
                                    echo "XII IPS 4 ";
                                  } 
                                }
                                if ($a->kelas5!=0) {
                                  if ($a->kelas5==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas5==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas5==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas5==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas5==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas5==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas5==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas5==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas5==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas5==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas5==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas5==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas5==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas5==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas5==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas5==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas5==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas5==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas5==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas5==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas5==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas5==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas5==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas5==24) {
                                    echo "XII IPS 4 ";
                                  }  
                                }
                                if ($a->kelas6!=0) {
                                  if ($a->kelas6==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas6==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas6==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas6==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas6==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas6==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas6==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas6==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas6==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas6==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas6==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas6==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas6==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas6==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas6==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas6==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas6==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas6==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas6==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas6==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas6==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas6==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas6==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas6==24) {
                                    echo "XII IPS 4 ";
                                  }  
                                }
                              if ($a->kelas7!=0) {
                                  if ($a->kelas7==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas7==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas7==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas7==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas7==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas7==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas7==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas7==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas7==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas7==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas7==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas7==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas7==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas7==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas7==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas7==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas7==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas7==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas7==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas7==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas7==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas7==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas7==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas7==24) {
                                    echo "XII IPS 4 ";
                                  }  
                                }
                                if ($a->kelas8!=0) {
                                  if ($a->kelas8==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas8==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas8==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas8==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas8==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas8==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas8==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas8==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas8==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas8==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas8==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas8==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas8==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas8==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas8==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas8==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas8==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas8==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas8==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas8==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas8==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas8==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas8==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas8==24) {
                                    echo "XII IPS 4 ";
                                  }  
                                }
                                if ($a->kelas9!=0) {
                                  if ($a->kelas9==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas9==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas9==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas9==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas9==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas9==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas9==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas9==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas9==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas9==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas9==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas9==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas9==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas9==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas9==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas9==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas9==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas9==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas9==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas9==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas9==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas9==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas9==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas9==24) {
                                    echo "XII IPS 4 ";
                                  }  
                                }
                                if ($a->kelas10!=0) {
                                  if ($a->kelas10==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas10==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas10==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas10==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas10==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas10==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas10==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas10==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas10==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas10==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas10==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas10==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas10==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas10==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas10==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas10==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas10==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas10==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas10==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas10==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas10==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas10==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas10==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas10==24) {
                                    echo "XII IPS 4 ";
                                  }  
                                }
                                if ($a->kelas11!=0) {
                                  if ($a->kelas11==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas11==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas11==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas11==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas11==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas11==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas11==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas11==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas11==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas11==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas11==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas11==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas11==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas11==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas11==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas11==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas11==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas11==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas11==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas11==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas11==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas11==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas11==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas11==24) {
                                    echo "XII IPS 4 ";
                                  }  
                                }
                                if ($a->kelas12!=0) {
                                  if ($a->kelas12==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas12==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas12==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas12==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas12==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas12==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas12==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas12==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas12==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas12==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas12==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas12==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas12==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas12==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas12==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas12==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas12==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas12==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas12==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas12==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas12==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas12==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas12==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas12==24) {
                                    echo "XII IPS 4 ";
                                  }  
                                }
                                if ($a->kelas13!=0) {
                                  if ($a->kelas13==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas13==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas13==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas13==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas13==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas13==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas13==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas13==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas13==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas13==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas13==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas13==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas13==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas13==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas13==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas13==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas13==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas13==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas13==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas13==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas13==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas13==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas13==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas13==24) {
                                    echo "XII IPS 4 ";
                                  }  
                                }
                                if ($a->kelas14!=0) {
                                  if ($a->kelas14==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas14==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas14==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas14==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas14==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas14==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas14==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas14==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas14==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas14==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas14==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas14==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas14==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas14==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas14==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas14==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas14==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas14==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas14==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas14==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas14==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas14==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas14==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas14==24) {
                                    echo "XII IPS 4 ";
                                  }  
                                }
                                if ($a->kelas15!=0) {
                                  if ($a->kelas15==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas15==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas15==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas15==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas15==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas15==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas15==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas15==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas15==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas15==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas15==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas15==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas15==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas15==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas15==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas15==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas15==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas15==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas15==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas15==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas15==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas15==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas15==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas15==24) {
                                    echo "XII IPS 4 ";
                                  }  
                                }
                                if ($a->kelas16!=0) {
                                  if ($a->kelas16==1) {
                                    echo "X MIA 1 ";
                                  }
                                  elseif ($a->kelas16==2) {
                                    echo "X MIA 2 ";
                                  }
                                  elseif ($a->kelas16==3) {
                                    echo "X MIA 3 ";
                                  }
                                  elseif ($a->kelas16==4) {
                                    echo "X MIA 4 ";
                                  }
                                  elseif ($a->kelas16==5) {
                                    echo "X IPS 1 ";
                                  }
                                  elseif ($a->kelas16==6) {
                                    echo "X IPS 2 ";
                                  }
                                  elseif ($a->kelas16==7) {
                                    echo "X IPS 3 ";
                                  } 
                                  elseif ($a->kelas16==8) {
                                    echo "X IPS 4 ";
                                  }
                                  elseif ($a->kelas16==9) {
                                    echo "XI IPA 1 ";
                                  }
                                  elseif ($a->kelas16==10) {
                                    echo "XI IPA 2 ";
                                  }
                                  elseif ($a->kelas16==11) {
                                    echo "XI IPA 3 ";
                                  } 
                                  elseif ($a->kelas16==12) {
                                    echo "XI IPA 4 ";
                                  }
                                  elseif ($a->kelas16==13) {
                                    echo "XI IPS 1 ";
                                  }
                                  elseif ($a->kelas16==14) {
                                    echo "XI IPS 2 ";
                                  }
                                  elseif ($a->kelas16==15) {
                                    echo "XI IPS 3 ";
                                  }
                                  elseif ($a->kelas16==16) {
                                    echo "XI IPS 4 ";
                                  }
                                  elseif ($a->kelas16==17) {
                                    echo "XII IPA 1 ";
                                  }
                                  elseif ($a->kelas16==18) {
                                    echo "XII IPA 2 ";
                                  }
                                  elseif ($a->kelas16==19) {
                                    echo "XII IPA 3 ";
                                  }
                                  elseif ($a->kelas16==20) {
                                    echo "XII IPA 4 ";
                                  }
                                  elseif ($a->kelas16==21) {
                                    echo "XII IPS 1 ";
                                  }
                                  elseif ($a->kelas16==22) {
                                    echo "XII IPS 2 ";
                                  }
                                  elseif ($a->kelas16==23) {
                                    echo "XII IPS 3 ";
                                  }
                                  elseif ($a->kelas16==24) {
                                    echo "XII IPS 4 ";
                                  }  
                                }
                                if ($a->kelas17!=0) {
                                  if ($a->kelas17==1) {
                                    echo "X MIA 1";
                                  }
                                  elseif ($a->kelas17==2) {
                                    echo "X MIA 2";
                                  }
                                  elseif ($a->kelas17==3) {
                                    echo "X MIA 3";
                                  }
                                  elseif ($a->kelas17==4) {
                                    echo "X MIA 4";
                                  }
                                  elseif ($a->kelas17==5) {
                                    echo "X IPS 1";
                                  }
                                  elseif ($a->kelas17==6) {
                                    echo "X IPS 2";
                                  }
                                  elseif ($a->kelas17==7) {
                                    echo "X IPS 3";
                                  } 
                                  elseif ($a->kelas17==8) {
                                    echo "X IPS 4";
                                  }
                                  elseif ($a->kelas17==9) {
                                    echo "XI IPA 1";
                                  }
                                  elseif ($a->kelas17==10) {
                                    echo "XI IPA 2";
                                  }
                                  elseif ($a->kelas17==11) {
                                    echo "XI IPA 3";
                                  } 
                                  elseif ($a->kelas17==12) {
                                    echo "XI IPA 4";
                                  }
                                  elseif ($a->kelas17==13) {
                                    echo "XI IPS 1";
                                  }
                                  elseif ($a->kelas17==14) {
                                    echo "XI IPS 2";
                                  }
                                  elseif ($a->kelas17==15) {
                                    echo "XI IPS 3";
                                  }
                                  elseif ($a->kelas17==16) {
                                    echo "XI IPS 4";
                                  }
                                  elseif ($a->kelas17==17) {
                                    echo "XII IPA 1";
                                  }
                                  elseif ($a->kelas17==18) {
                                    echo "XII IPA 2";
                                  }
                                  elseif ($a->kelas17==19) {
                                    echo "XII IPA 3";
                                  }
                                  elseif ($a->kelas17==20) {
                                    echo "XII IPA 4";
                                  }
                                  elseif ($a->kelas17==21) {
                                    echo "XII IPS 1";
                                  }
                                  elseif ($a->kelas17==22) {
                                    echo "XII IPS 2";
                                  }
                                  elseif ($a->kelas17==23) {
                                    echo "XII IPS 3";
                                  }
                                  elseif ($a->kelas17==24) {
                                    echo "XII IPS 4";
                                  }  
                                }
                                if ($a->kelas18!=0) {
                                  if ($a->kelas18==1) {
                                    echo "X MIA 1";
                                  }
                                  elseif ($a->kelas18==2) {
                                    echo "X MIA 2";
                                  }
                                  elseif ($a->kelas18==3) {
                                    echo "X MIA 3";
                                  }
                                  elseif ($a->kelas18==4) {
                                    echo "X MIA 4";
                                  }
                                  elseif ($a->kelas18==5) {
                                    echo "X IPS 1";
                                  }
                                  elseif ($a->kelas18==6) {
                                    echo "X IPS 2";
                                  }
                                  elseif ($a->kelas18==7) {
                                    echo "X IPS 3";
                                  } 
                                  elseif ($a->kelas18==8) {
                                    echo "X IPS 4";
                                  }
                                  elseif ($a->kelas18==9) {
                                    echo "XI IPA 1";
                                  }
                                  elseif ($a->kelas18==10) {
                                    echo "XI IPA 2";
                                  }
                                  elseif ($a->kelas18==11) {
                                    echo "XI IPA 3";
                                  } 
                                  elseif ($a->kelas18==12) {
                                    echo "XI IPA 4";
                                  }
                                  elseif ($a->kelas18==13) {
                                    echo "XI IPS 1";
                                  }
                                  elseif ($a->kelas18==14) {
                                    echo "XI IPS 2";
                                  }
                                  elseif ($a->kelas18==15) {
                                    echo "XI IPS 3";
                                  }
                                  elseif ($a->kelas18==16) {
                                    echo "XI IPS 4";
                                  }
                                  elseif ($a->kelas18==17) {
                                    echo "XII IPA 1";
                                  }
                                  elseif ($a->kelas18==18) {
                                    echo "XII IPA 2";
                                  }
                                  elseif ($a->kelas18==19) {
                                    echo "XII IPA 3";
                                  }
                                  elseif ($a->kelas18==20) {
                                    echo "XII IPA 4";
                                  }
                                  elseif ($a->kelas18==21) {
                                    echo "XII IPS 1";
                                  }
                                  elseif ($a->kelas18==22) {
                                    echo "XII IPS 2";
                                  }
                                  elseif ($a->kelas18==23) {
                                    echo "XII IPS 3";
                                  }
                                  elseif ($a->kelas18==24) {
                                    echo "XII IPS 4";
                                  }  
                                }
                                if ($a->kelas19!=0) {
                                  if ($a->kelas19==1) {
                                    echo "X MIA 1";
                                  }
                                  elseif ($a->kelas19==2) {
                                    echo "X MIA 2";
                                  }
                                  elseif ($a->kelas19==3) {
                                    echo "X MIA 3";
                                  }
                                  elseif ($a->kelas19==4) {
                                    echo "X MIA 4";
                                  }
                                  elseif ($a->kelas19==5) {
                                    echo "X IPS 1";
                                  }
                                  elseif ($a->kelas19==6) {
                                    echo "X IPS 2";
                                  }
                                  elseif ($a->kelas19==7) {
                                    echo "X IPS 3";
                                  } 
                                  elseif ($a->kelas19==8) {
                                    echo "X IPS 4";
                                  }
                                  elseif ($a->kelas19==9) {
                                    echo "XI IPA 1";
                                  }
                                  elseif ($a->kelas19==10) {
                                    echo "XI IPA 2";
                                  }
                                  elseif ($a->kelas19==11) {
                                    echo "XI IPA 3";
                                  } 
                                  elseif ($a->kelas19==12) {
                                    echo "XI IPA 4";
                                  }
                                  elseif ($a->kelas19==13) {
                                    echo "XI IPS 1";
                                  }
                                  elseif ($a->kelas19==14) {
                                    echo "XI IPS 2";
                                  }
                                  elseif ($a->kelas19==15) {
                                    echo "XI IPS 3";
                                  }
                                  elseif ($a->kelas19==16) {
                                    echo "XI IPS 4";
                                  }
                                  elseif ($a->kelas19==17) {
                                    echo "XII IPA 1";
                                  }
                                  elseif ($a->kelas19==18) {
                                    echo "XII IPA 2";
                                  }
                                  elseif ($a->kelas19==19) {
                                    echo "XII IPA 3";
                                  }
                                  elseif ($a->kelas19==20) {
                                    echo "XII IPA 4";
                                  }
                                  elseif ($a->kelas19==21) {
                                    echo "XII IPS 1";
                                  }
                                  elseif ($a->kelas19==22) {
                                    echo "XII IPS 2";
                                  }
                                  elseif ($a->kelas19==23) {
                                    echo "XII IPS 3";
                                  }
                                  elseif ($a->kelas19==24) {
                                    echo "XII IPS 4";
                                  }  
                                }
                                if ($a->kelas20!=0) {
                                  if ($a->kelas20==1) {
                                    echo "X MIA 1";
                                  }
                                  elseif ($a->kelas20==2) {
                                    echo "X MIA 2";
                                  }
                                  elseif ($a->kelas20==3) {
                                    echo "X MIA 3";
                                  }
                                  elseif ($a->kelas20==4) {
                                    echo "X MIA 4";
                                  }
                                  elseif ($a->kelas20==5) {
                                    echo "X IPS 1";
                                  }
                                  elseif ($a->kelas20==6) {
                                    echo "X IPS 2";
                                  }
                                  elseif ($a->kelas20==7) {
                                    echo "X IPS 3";
                                  } 
                                  elseif ($a->kelas20==8) {
                                    echo "X IPS 4";
                                  }
                                  elseif ($a->kelas20==9) {
                                    echo "XI IPA 1";
                                  }
                                  elseif ($a->kelas20==10) {
                                    echo "XI IPA 2";
                                  }
                                  elseif ($a->kelas20==11) {
                                    echo "XI IPA 3";
                                  } 
                                  elseif ($a->kelas20==12) {
                                    echo "XI IPA 4";
                                  }
                                  elseif ($a->kelas20==13) {
                                    echo "XI IPS 1";
                                  }
                                  elseif ($a->kelas20==14) {
                                    echo "XI IPS 2";
                                  }
                                  elseif ($a->kelas20==15) {
                                    echo "XI IPS 3";
                                  }
                                  elseif ($a->kelas20==16) {
                                    echo "XI IPS 4";
                                  }
                                  elseif ($a->kelas20==17) {
                                    echo "XII IPA 1";
                                  }
                                  elseif ($a->kelas20==18) {
                                    echo "XII IPA 2";
                                  }
                                  elseif ($a->kelas20==19) {
                                    echo "XII IPA 3";
                                  }
                                  elseif ($a->kelas20==20) {
                                    echo "XII IPA 4";
                                  }
                                  elseif ($a->kelas20==21) {
                                    echo "XII IPS 1";
                                  }
                                  elseif ($a->kelas20==22) {
                                    echo "XII IPS 2";
                                  }
                                  elseif ($a->kelas20==23) {
                                    echo "XII IPS 3";
                                  }
                                  elseif ($a->kelas20==24) {
                                    echo "XII IPS 4";
                                  }  
                                }
                                if ($a->kelas21!=0) {
                                  if ($a->kelas21==1) {
                                    echo "X MIA 1";
                                  }
                                  elseif ($a->kelas21==2) {
                                    echo "X MIA 2";
                                  }
                                  elseif ($a->kelas21==3) {
                                    echo "X MIA 3";
                                  }
                                  elseif ($a->kelas21==4) {
                                    echo "X MIA 4";
                                  }
                                  elseif ($a->kelas21==5) {
                                    echo "X IPS 1";
                                  }
                                  elseif ($a->kelas21==6) {
                                    echo "X IPS 2";
                                  }
                                  elseif ($a->kelas21==7) {
                                    echo "X IPS 3";
                                  } 
                                  elseif ($a->kelas21==8) {
                                    echo "X IPS 4";
                                  }
                                  elseif ($a->kelas21==9) {
                                    echo "XI IPA 1";
                                  }
                                  elseif ($a->kelas21==10) {
                                    echo "XI IPA 2";
                                  }
                                  elseif ($a->kelas21==11) {
                                    echo "XI IPA 3";
                                  } 
                                  elseif ($a->kelas21==12) {
                                    echo "XI IPA 4";
                                  }
                                  elseif ($a->kelas21==13) {
                                    echo "XI IPS 1";
                                  }
                                  elseif ($a->kelas21==14) {
                                    echo "XI IPS 2";
                                  }
                                  elseif ($a->kelas21==15) {
                                    echo "XI IPS 3";
                                  }
                                  elseif ($a->kelas21==16) {
                                    echo "XI IPS 4";
                                  }
                                  elseif ($a->kelas21==17) {
                                    echo "XII IPA 1";
                                  }
                                  elseif ($a->kelas21==18) {
                                    echo "XII IPA 2";
                                  }
                                  elseif ($a->kelas21==19) {
                                    echo "XII IPA 3";
                                  }
                                  elseif ($a->kelas21==20) {
                                    echo "XII IPA 4";
                                  }
                                  elseif ($a->kelas21==21) {
                                    echo "XII IPS 1";
                                  }
                                  elseif ($a->kelas21==22) {
                                    echo "XII IPS 2";
                                  }
                                  elseif ($a->kelas21==23) {
                                    echo "XII IPS 3";
                                  }
                                  elseif ($a->kelas21==24) {
                                    echo "XII IPS 4";
                                  }  
                                }
                                if ($a->kelas22!=0) {
                                  if ($a->kelas22==1) {
                                    echo "X MIA 1";
                                  }
                                  elseif ($a->kelas22==2) {
                                    echo "X MIA 2";
                                  }
                                  elseif ($a->kelas22==3) {
                                    echo "X MIA 3";
                                  }
                                  elseif ($a->kelas22==4) {
                                    echo "X MIA 4";
                                  }
                                  elseif ($a->kelas22==5) {
                                    echo "X IPS 1";
                                  }
                                  elseif ($a->kelas22==6) {
                                    echo "X IPS 2";
                                  }
                                  elseif ($a->kelas22==7) {
                                    echo "X IPS 3";
                                  } 
                                  elseif ($a->kelas22==8) {
                                    echo "X IPS 4";
                                  }
                                  elseif ($a->kelas22==9) {
                                    echo "XI IPA 1";
                                  }
                                  elseif ($a->kelas22==10) {
                                    echo "XI IPA 2";
                                  }
                                  elseif ($a->kelas22==11) {
                                    echo "XI IPA 3";
                                  } 
                                  elseif ($a->kelas22==12) {
                                    echo "XI IPA 4";
                                  }
                                  elseif ($a->kelas22==13) {
                                    echo "XI IPS 1";
                                  }
                                  elseif ($a->kelas22==14) {
                                    echo "XI IPS 2";
                                  }
                                  elseif ($a->kelas22==15) {
                                    echo "XI IPS 3";
                                  }
                                  elseif ($a->kelas22==16) {
                                    echo "XI IPS 4";
                                  }
                                  elseif ($a->kelas22==17) {
                                    echo "XII IPA 1";
                                  }
                                  elseif ($a->kelas22==18) {
                                    echo "XII IPA 2";
                                  }
                                  elseif ($a->kelas22==19) {
                                    echo "XII IPA 3";
                                  }
                                  elseif ($a->kelas22==20) {
                                    echo "XII IPA 4";
                                  }
                                  elseif ($a->kelas22==21) {
                                    echo "XII IPS 1";
                                  }
                                  elseif ($a->kelas22==22) {
                                    echo "XII IPS 2";
                                  }
                                  elseif ($a->kelas22==23) {
                                    echo "XII IPS 3";
                                  }
                                  elseif ($a->kelas22==24) {
                                    echo "XII IPS 4";
                                  }  
                                }
                                if ($a->kelas23!=0) {
                                  if ($a->kelas23==1) {
                                    echo "X MIA 1";
                                  }
                                  elseif ($a->kelas23==2) {
                                    echo "X MIA 2";
                                  }
                                  elseif ($a->kelas23==3) {
                                    echo "X MIA 3";
                                  }
                                  elseif ($a->kelas23==4) {
                                    echo "X MIA 4";
                                  }
                                  elseif ($a->kelas23==5) {
                                    echo "X IPS 1";
                                  }
                                  elseif ($a->kelas23==6) {
                                    echo "X IPS 2";
                                  }
                                  elseif ($a->kelas23==7) {
                                    echo "X IPS 3";
                                  } 
                                  elseif ($a->kelas23==8) {
                                    echo "X IPS 4";
                                  }
                                  elseif ($a->kelas23==9) {
                                    echo "XI IPA 1";
                                  }
                                  elseif ($a->kelas23==10) {
                                    echo "XI IPA 2";
                                  }
                                  elseif ($a->kelas23==11) {
                                    echo "XI IPA 3";
                                  } 
                                  elseif ($a->kelas23==12) {
                                    echo "XI IPA 4";
                                  }
                                  elseif ($a->kelas23==13) {
                                    echo "XI IPS 1";
                                  }
                                  elseif ($a->kelas23==14) {
                                    echo "XI IPS 2";
                                  }
                                  elseif ($a->kelas23==15) {
                                    echo "XI IPS 3";
                                  }
                                  elseif ($a->kelas23==16) {
                                    echo "XI IPS 4";
                                  }
                                  elseif ($a->kelas23==17) {
                                    echo "XII IPA 1";
                                  }
                                  elseif ($a->kelas23==18) {
                                    echo "XII IPA 2";
                                  }
                                  elseif ($a->kelas23==19) {
                                    echo "XII IPA 3";
                                  }
                                  elseif ($a->kelas23==20) {
                                    echo "XII IPA 4";
                                  }
                                  elseif ($a->kelas23==21) {
                                    echo "XII IPS 1";
                                  }
                                  elseif ($a->kelas23==22) {
                                    echo "XII IPS 2";
                                  }
                                  elseif ($a->kelas23==23) {
                                    echo "XII IPS 3";
                                  }
                                  elseif ($a->kelas23==24) {
                                    echo "XII IPS 4";
                                  }  
                                }
                                if ($a->kelas24!=0) {
                                  if ($a->kelas24==1) {
                                    echo "X MIA 1";
                                  }
                                  elseif ($a->kelas24==2) {
                                    echo "X MIA 2";
                                  }
                                  elseif ($a->kelas24==3) {
                                    echo "X MIA 3";
                                  }
                                  elseif ($a->kelas24==4) {
                                    echo "X MIA 4";
                                  }
                                  elseif ($a->kelas24==5) {
                                    echo "X IPS 1";
                                  }
                                  elseif ($a->kelas24==6) {
                                    echo "X IPS 2";
                                  }
                                  elseif ($a->kelas24==7) {
                                    echo "X IPS 3";
                                  } 
                                  elseif ($a->kelas24==8) {
                                    echo "X IPS 4";
                                  }
                                  elseif ($a->kelas24==9) {
                                    echo "XI IPA 1";
                                  }
                                  elseif ($a->kelas24==10) {
                                    echo "XI IPA 2";
                                  }
                                  elseif ($a->kelas24==11) {
                                    echo "XI IPA 3";
                                  } 
                                  elseif ($a->kelas24==12) {
                                    echo "XI IPA 4";
                                  }
                                  elseif ($a->kelas24==13) {
                                    echo "XI IPS 1";
                                  }
                                  elseif ($a->kelas24==14) {
                                    echo "XI IPS 2";
                                  }
                                  elseif ($a->kelas24==15) {
                                    echo "XI IPS 3";
                                  }
                                  elseif ($a->kelas24==16) {
                                    echo "XI IPS 4";
                                  }
                                  elseif ($a->kelas24==17) {
                                    echo "XII IPA 1";
                                  }
                                  elseif ($a->kelas24==18) {
                                    echo "XII IPA 2";
                                  }
                                  elseif ($a->kelas24==19) {
                                    echo "XII IPA 3";
                                  }
                                  elseif ($a->kelas24==20) {
                                    echo "XII IPA 4";
                                  }
                                  elseif ($a->kelas24==21) {
                                    echo "XII IPS 1";
                                  }
                                  elseif ($a->kelas24==22) {
                                    echo "XII IPS 2";
                                  }
                                  elseif ($a->kelas24==23) {
                                    echo "XII IPS 3";
                                  }
                                  elseif ($a->kelas24==24) {
                                    echo "XII IPS 4";
                                  }  
                                }
                                echo "</td>";

                              echo "</tr>";}

                        ?>
                      </tbody>
                    </table>
                      <center><a href="<?php echo base_url("index.php/akademik/daftar_guru/"); ?>" type="button" class="btn btn-primary">Kembali</a></center>;
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Kerja Praktek Jurusan Teknik Informatika Universites Islam Indonesia by azizsembada
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/template/build/js/custom.min.js"></script>

    <!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
  </body>
</html>