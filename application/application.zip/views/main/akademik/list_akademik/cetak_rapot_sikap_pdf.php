        <style>
      .table1 {
    font-family: sans-serif;
    color: #232323;
    border-collapse: collapse;
}

.table1, .th, .td {
    border: 1px solid #999;
}
</style>
<?php foreach ($rapot as $r) {} ?>
                          <table width="100%">
                            <tr>
                              <td width="350">
                                <table >
                                  <tr>
                                    <td width="100">Nama Sekolah</td>
                                    <td width="1">:</td>
                                    <td>SMA N 1 Rembang , Purbalingga</td>
                                  </tr>
                                  <tr>
                                    <td >Alamat</td>
                                    <td >:</td>
                                    <td>Jalan Monumen Jendral Soedirman</td>
                                  </tr>
                                  <tr>
                                    <td ></td>
                                    <td ></td>
                                    <td>Rembang,Purbalingga 53356</td>
                                  </tr>
                                  <tr>
                                    <td >Nama Peserta Didik</td>
                                    <td >:</td>
                                    <td><?php echo "$r->nama_siswa"; ?></td>
                                  </tr>
                                  <tr>
                                    <td >Nomor Induk / NISN</td>
                                    <td >:</td>
                                    <td><?php echo "$r->nis / $r->nisn"; ?></td>
                                  </tr>
                                </table>
                              </td>
                              <td align="right" valign="top" width="150">
                                <table >
                                  <tr>
                                    <td width="50" >Kelas</td>
                                    <td >:</td>
                                    <td><?php echo "$r->nama_kelas"; ?></td>
                                  </tr>
                                  <tr>
                                    <td >semester</td>
                                    <td >:</td>
                                    <?php 
                                       $semester=substr($r->nama_ta,10);
                                       if ($semester==1) { ?>
                                         <td><?php echo "$semester / Ganjil"; ?></td>
                                         <?php
                                       }
                                       elseif ($semester==2) { ?>
                                         <td><?php echo "$semester / Genap"; ?></td>
                                         <?php
                                       }
                                     ?>
                                  </tr>
                                  <tr>
                                    <td >Tahun Pelajaran</td>
                                    <td >:</td>
                                    <?php
                                    $ta=substr($r->nama_ta,0,9);
                                    ?>
                                    <td><?php echo "$ta"; ?></td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                          </table>
                          <br>
                          <h3 align="center">CAPAIAN HASIL BELAJAR</h3>
                          <br>
                          <table width="100%">
                            <tr>
                              <td width="1%"><strong>A.</strong></td>
                              <td><strong>Sikap</strong></td>
                            </tr>
                            <tr>
                              <td></td>
                              <td width="150px"><strong>1. Sikap Spiritual</strong></td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>
                                <table width="100%" border="1" class="table1">
                                  <tr>
                                    <th width="25%" class="th"><center>Predikat</center></th>
                                    <th width="75%" class="th"><center>Deskripsi</center></th>
                                  </tr>
                                  <tr>
                                    <td align="center" class="td"><?php echo "{$r->sikap_spiritual}"; ?></td>
                                    <td align="justify" class="td"><?php echo "$r->deskripsi_spiritual"; ?></td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td width="150px"></td>
                              <td width="150px"><strong>2. Sikap Sosial</strong></td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>
                                <table width="100%" border="1" class="table1">
                                  <tr>
                                    <th width="25%" class="th"><center>Predikat</center></th>
                                    <th width="75%" class="th"><center>Deskripsi</center></th>
                                  </tr>
                                  <tr>
                                    <td align="center" class="td"><?php echo "$r->sikap_sosial"; ?></td>
                                    <td align="justify" class="td"><?php echo "$r->deskripsi_sosial"; ?></td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                          </table>
                          <br>
            <?php
            $tanggal1 = substr(date('d-m-Y'),0,1);
            $tanggal2 = substr(date('d-m-Y'),1,1);
            $bulan = substr(date('d-m-Y'),3,2);
            $tahun = substr(date('d-m-Y'),6,4);
            if ($bulan==01) {
              $b="Januari";
            }
            elseif ($bulan==02) {
              $b="Februari";
            }
            elseif ($bulan==03) {
              $b="Maret";
            }
            elseif ($bulan==04) {
              $b="April";
            }
            elseif ($bulan==05) {
              $b="Mei";
            }
            elseif ($bulan==06) {
              $b="Juni";
            }
            elseif ($bulan==07) {
              $b="Juli";
            }
            elseif ($bulan==08) {
              $b="Agustus";
            }
            elseif ($bulan==09) {
              $b="Sebtember";
            }
            elseif ($bulan==10) {
              $b="Oktober";
            }
            elseif ($bulan==11) {
              $b="November";
            }
            elseif ($bulan==12) {
              $b="Desember";
            }
            if ($tanggal1==1 || $tanggal1==2 || $tanggal1==3) {?>
              <p align="right"><?php echo "Purbalingga {$tanggal1}{$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            else{?>
              <p align="right"><?php echo "Purbalingga, {$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            ?>
            <table width="800">
  <tbody>
    <tr>
      <td width="200">Orang Tua/Wali Peserta Didik</td>
      <td width="200">Wali Kelas</td>
      <td width="400">Kepala Sekolah</td>
    </tr>
    <tr>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
    </tr>
    <?php foreach($wali_kelas as $w)?>
    <?php foreach($kepala_sekolah as $k)?>
    <tr>
      <td rowspan="2">...........................................................</td>
      <?php echo "<td>{$w->nama_guru}</td>"; ?>
      <?php echo "<td>{$k->nama_guru}</td>"; ?>
    </tr>
    <tr>
      <td><?php echo "NIP. {$w->nomor_induk}";?></td>
      <td><?php echo "NIP. {$k->nomor_induk}";?></td>
    </tr>
  </tbody>
</table>
                        <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/template/build/js/custom.min.js"></script>

    <!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
  </body>
</html>