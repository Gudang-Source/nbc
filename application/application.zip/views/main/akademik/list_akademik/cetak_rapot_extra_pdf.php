        <style>
      .table1 {
    font-family: sans-serif;
    color: #232323;
    border-collapse: collapse;
}

.table1, .th, .td {
    border: 1px solid #999;
}
</style>
<?php foreach ($rapot as $r) {} ?>
<table width="100%">
                            <tr>
                              <td width="350">
                                <table >
                                  <tr>
                                    <td width="100">Nama Sekolah</td>
                                    <td width="1">:</td>
                                    <td>SMA N 1 Rembang , Purbalingga</td>
                                  </tr>
                                  <tr>
                                    <td >Alamat</td>
                                    <td >:</td>
                                    <td>Jalan Monumen Jendral Soedirman</td>
                                  </tr>
                                  <tr>
                                    <td ></td>
                                    <td ></td>
                                    <td>Rembang,Purbalingga 53356</td>
                                  </tr>
                                  <tr>
                                    <td >Nama Peserta Didik</td>
                                    <td >:</td>
                                    <td><?php echo "$r->nama_siswa"; ?></td>
                                  </tr>
                                  <tr>
                                    <td >Nomor Induk / NISN</td>
                                    <td >:</td>
                                    <td><?php echo "$r->nis / $r->nisn"; ?></td>
                                  </tr>
                                </table>
                              </td>
                              <td align="right" valign="top" width="150">
                                <table >
                                  <tr>
                                    <td width="50" >Kelas</td>
                                    <td >:</td>
                                    <td><?php echo "$r->nama_kelas"; ?></td>
                                  </tr>
                                  <tr>
                                    <td >semester</td>
                                    <td >:</td>
                                    <?php 
                                       $semester=substr($r->nama_ta,10);
                                       if ($semester==1) { ?>
                                         <td><?php echo "$semester / Ganjil"; ?></td>
                                         <?php
                                       }
                                       elseif ($semester==2) { ?>
                                         <td><?php echo "$semester / Genap"; ?></td>
                                         <?php
                                       }
                                     ?>
                                  </tr>
                                  <tr>
                                    <td >Tahun Pelajaran</td>
                                    <td >:</td>
                                    <?php
                                    $ta=substr($r->nama_ta,0,9);
                                    ?>
                                    <td><?php echo "$ta"; ?></td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                          </table>
                          <br>
<table>
                            <tr>
                              <td width="1px"><strong>C.</strong></td>
                              <td><strong>Extra Kurikuler</strong></td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>
                                <table width="100%" border="1" class="table1">
                                  <tr>
                                    <th class="th" width="5%"><center>No</center></th>
                                    <th class="th" width="30%">Kegiatan Extra Kulikuler</th>
                                    <th class="th" width="5%"><center>Nilai</center></th>
                                    <th class="th" width="50%">Deskripsi</th>
                                  </tr>
                                    <?php
                                      $no=0;
                                      foreach ($nilai_eskul as $n) {
                                        $no=$no+1;
                                        echo "<tr>";
                                        echo "<td class='td' align='center'>$no</td>";
                                        echo "<td class='td'>$n->nama_eskul</td>";
                                        echo "<td class='td' align='center'>$n->nilai_akhir</td>";
                                        echo "<td class='td'>$n->komentar</td>";
                                        echo "</tr>";
                                      }
                                    ?>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td>D. </td>
                              <td width="150px"><strong>Prestasi</strong></td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>
                                <table width="100%" border="1" class="table1">
                                  <tr>
                                    <th class="th" width="5%"><center>No</center></th>
                                    <th class="th" width="35%">Jenis Kegiatan</th>
                                    <th class="th" width="60%">Keterangan</th>
                                  </tr>
                                  <tr>
                                    <td class="td" align="center">1</td>
                                    <td class="td">&nbsp;</td>
                                    <td class="td">&nbsp;</td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td >&nbsp;</td>
                            </tr>
                            <tr>
                              <td>E. </td>
                              <td width="150px"><strong>Kehadiran</strong></td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>
                                <table width="100%" border="1" class="table1">
                                  <tr>
                                    <td class="td" width="5%">Sakit</td>
                                    <td class="td" width="35%"><?php echo "{$r->s} Hari"; ?></td>
                                  </tr>
                                  <tr>
                                    <td class="td" width="5%">Izin</td>
                                    <td class="td" width="35%"><?php echo "{$r->i} Hari"; ?></td>
                                  </tr>
                                  <tr>
                                    <td class="td" width="5%">Tanpa Keterangan</td>
                                    <td class="td" width="35%"><?php echo "{$r->a} Hari"; ?></td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td>F. </td>
                              <td><strong>Catatan Wali Kelas</strong></td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>
                                <table width="100%" border="1" class="table1">
                                  <tr>
                                    <?php foreach ($catatan_wali_kelas as $c) {} 
                                  echo "<td class='td'>$c->catatan</td>";
                              ?>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                             <tr>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td>G. </td>
                              <td class="td" width="150px"><strong>Tanggapan Orang Tua / Wali</strong></td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>
                                <table width="100%" border="1" class="table1">
                                  <tr>
                                    <th class="th" width="5%">&nbsp;</th>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                          </table>
                          <br>
            <?php
            $tanggal1 = substr(date('d-m-Y'),0,1);
            $tanggal2 = substr(date('d-m-Y'),1,1);
            $bulan = substr(date('d-m-Y'),3,2);
            $tahun = substr(date('d-m-Y'),6,4);
            if ($bulan==01) {
              $b="Januari";
            }
            elseif ($bulan==02) {
              $b="Februari";
            }
            elseif ($bulan==03) {
              $b="Maret";
            }
            elseif ($bulan==04) {
              $b="April";
            }
            elseif ($bulan==05) {
              $b="Mei";
            }
            elseif ($bulan==06) {
              $b="Juni";
            }
            elseif ($bulan==07) {
              $b="Juli";
            }
            elseif ($bulan==08) {
              $b="Agustus";
            }
            elseif ($bulan==09) {
              $b="Sebtember";
            }
            elseif ($bulan==10) {
              $b="Oktober";
            }
            elseif ($bulan==11) {
              $b="November";
            }
            elseif ($bulan==12) {
              $b="Desember";
            }
            if ($tanggal1==1 || $tanggal1==2 || $tanggal1==3) {?>
              <p align="right"><?php echo "Purbalingga {$tanggal1}{$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            else{?>
              <p align="right"><?php echo "Purbalingga, {$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            ?>
<table width="800">
  <tbody>
    <tr>
      <td width="200">Orang Tua/Wali Peserta Didik</td>
      <td width="200">Wali Kelas</td>
      <td width="400">Kepala Sekolah</td>
    </tr>
    <tr>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
    </tr>
    <?php foreach($wali_kelas as $w)?>
    <?php foreach($kepala_sekolah as $k)?>
    <tr>
      <td rowspan="2">...........................................................</td>
      <?php echo "<td>{$w->nama_guru}</td>"; ?>
      <?php echo "<td>{$k->nama_guru}</td>"; ?>
    </tr>
    <tr>
      <td><?php echo "NIP. {$w->nomor_induk}";?></td>
      <td><?php echo "NIP. {$k->nomor_induk}";?></td>
    </tr>
  </tbody>
</table>