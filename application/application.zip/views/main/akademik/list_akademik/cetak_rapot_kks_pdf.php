    <!-- page content -->
        <style>
      .table1 {
    font-family: sans-serif;
    color: #232323;
    border-collapse: collapse;
}

.table1, .th, .td {
    border: 1px solid #999;
}
    </style>
<?php foreach($rapot as $r){} ?>
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
                  <div class="x_content">
            <table width="100%">
              <tbody>
                <tr>
                  <td><table width="200">
              <tbody>
                <tr>
                  <td>Nama Peserta Didik</td>
                  <td>:</td>
                  <td><b><?php echo "$r->nama_siswa";?></b></td>
                </tr>
                <tr>
                  <td>Nomor Induk</td>
                  <td>:</td>
                  <td><b><?php echo "$r->nis";?></td>
                </tr>
              </tbody>
            </table>
            </td>
                  <td><table width="200" align="right">
              <tbody>
                <tr>
                  <td align="right">Kelas / Semester</td>
                  <td align="right">:</td>
                  <?php $semester = substr($r->nama_ta,10); 
                  $ta = substr($r->nama_ta,0,9); ?>
                  <td align="right"><b><?php echo "$r->nama_kelas / $semester";?></td>
                </tr>
                <tr>
                  <td align="right">Tahun Pelajaran</td>
                  <td align="right">:</td>
                  <td align="right"><b><?php echo "$ta";?></b></td>
                </tr>
              </tbody>
            </table>
            </td>
                </tr>
              </tbody>
            </table>
            <br><br>
            <p><b>Ketercapaian Kompetensi Siswa</b></p>
            <br>
            <table width="100%" class="table1">
              <tbody>
                <tr>
                  <td width="5%" align="center"><b>No</b></td>
                  <td align="center" width="25%"><b>Komponen</b></td></td>
                <td align="center"><b>Keterangan</b></td>
                </tr>
                  <?php 
                  $no=0;
                  foreach($rapot as $r){
                    $no=$no+1;
                    echo "<tr>";
                      echo "<td class='td'>$no</td>";
                      echo "<td class='td'>{$r->nama_matapelajaran}</td>";
                      echo "<td class='td'>{$r->komentar}</td>";
                    echo "</tr>";
                    } ?>
              </tbody>
            </table>
            <br>
            <?php
            $tanggal1 = substr(date('d-m-Y'),0,1);
            $tanggal2 = substr(date('d-m-Y'),1,1);
            $bulan = substr(date('d-m-Y'),3,2);
            $tahun = substr(date('d-m-Y'),6,4);
            if ($bulan==01) {
              $b="Januari";
            }
            elseif ($bulan==02) {
              $b="Februari";
            }
            elseif ($bulan==03) {
              $b="Maret";
            }
            elseif ($bulan==04) {
              $b="April";
            }
            elseif ($bulan==05) {
              $b="Mei";
            }
            elseif ($bulan==06) {
              $b="Juni";
            }
            elseif ($bulan==07) {
              $b="Juli";
            }
            elseif ($bulan==08) {
              $b="Agustus";
            }
            elseif ($bulan==09) {
              $b="Sebtember";
            }
            elseif ($bulan==10) {
              $b="Oktober";
            }
            elseif ($bulan==11) {
              $b="November";
            }
            elseif ($bulan==12) {
              $b="Desember";
            }
            if ($tanggal1==1) {?>
              <p align="right"><?php echo "Purbalingga {$tanggal1}{$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            else{?>
              <p align="right"><?php echo "Purbalingga, {$tanggal2} {$b} {$tahun}"; ?></p>
              <?php
            }
            ?>
             <table width="800">
  <tbody>
    <tr>
      <td width="200">Orang Tua/Wali Peserta Didik</td>
      <td width="200">Wali Kelas</td>
      <td width="400">Kepala Sekolah</td>
    </tr>
    <tr>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td><p>&nbsp;</p>
        <p>&nbsp;</p></td>
    </tr>
    <?php foreach($wali_kelas as $w)?>
    <?php foreach($kepala_sekolah as $k)?>
    <tr>
      <td rowspan="2">...........................................................</td>
      <?php echo "<td>{$w->nama_guru}</td>"; ?>
      <?php echo "<td>{$k->nama_guru}</td>"; ?>
    </tr>
    <tr>
      <td><?php echo "NIP. {$w->nomor_induk}";?></td>
      <td><?php echo "NIP. {$k->nomor_induk}";?></td>
    </tr>
  </tbody>
</table>

        <!-- /page content -->

        <!-- footer content -->
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/template/build/js/custom.min.js"></script>

    <!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
  </body>
</html>