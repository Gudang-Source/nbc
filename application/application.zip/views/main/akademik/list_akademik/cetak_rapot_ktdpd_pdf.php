        <style>
      .table1 {
    font-family: sans-serif;
    color: #232323;
    border-collapse: collapse;
}

.table1, .th, .td {
    border: 1px solid #999;
}
</style>
<h1 align="center">KETERANGAN TENTANG DIRI PESERTA DIDIK</h1>
<?php foreach($rapot as $r){} ?>
                          <table>
                            <tr>
                              <td width="20px">1.</td>
                              <td width="200px">Nama Peserta Didik (Lengkap)</td>
                              <td width="20px">:</td>
                              <td><?php echo "$r->nama_siswa"; ?></td>
                            </tr>
                            <tr>
                              <td width="20px">2.</td>
                              <td width="200px">NIS / NISN</td>
                              <td width="20px">:</td>
                              <td><?php echo "$r->nis / $r->nisn"; ?></td>
                            </tr>
                            <tr>
                              <td width="20px">3.</td>
                              <td width="200px">Tempat Tanggal lahir</td>
                              <td width="20px">:</td>
                              <?php
                              $cek_panjang_tanggal=strlen($r->tanggallahir_siswa);
                              if ($cek_panjang_tanggal==9) {
                                $cek_karakter2 = substr($r->tanggallahir_siswa,1,1);
                                if ($cek_karakter2=="/") {
                                  // format tanggal m/dd/yyyy
                                  $bulan = substr($r->tanggallahir_siswa,0,1);
                                  $hari = substr($r->tanggallahir_siswa,2,2);
                                  $tahun = substr($r->tanggallahir_siswa,5,4);
                                  if ($bulan==1) {
                                    $bulan="Januari";
                                  }
                                  elseif ($bulan==2) {
                                    $bulan="Februari";
                                  }
                                  elseif ($bulan==3) {
                                    $bulan="Maret";
                                  }
                                  elseif ($bulan==4) {
                                    $bulan="April";
                                  }
                                  elseif ($bulan==5) {
                                    $bulan="Mei";
                                  }
                                  elseif ($bulan==6) {
                                    $bulan="Juni";
                                  }
                                  elseif ($bulan==7) {
                                    $bulan="Juli";
                                  }
                                  elseif ($bulan==8) {
                                    $bulan="Agustus";
                                  }
                                  elseif ($bulan==9) {
                                    $bulan="September";
                                  }
                                  elseif ($bulan==10) {
                                    $bulan="Oktober";
                                  }
                                  elseif ($bulan==11) {
                                    $bulan="November";
                                  }
                                  elseif ($bulan==12) {
                                    $bulan="Desember";
                                  }
                                }
                                else{
                                  //formatny mm/d/yyyy
                                  $bulan = substr($r->tanggallahir_siswa,0,2);
                                  $hari = substr($r->tanggallahir_siswa,3,1);
                                  $tahun = substr($r->tanggallahir_siswa,5,4);
                                  if ($bulan==1) {
                                    $bulan="Januari";
                                  }
                                  elseif ($bulan==2) {
                                    $bulan="Februari";
                                  }
                                  elseif ($bulan==3) {
                                    $bulan="Maret";
                                  }
                                  elseif ($bulan==4) {
                                    $bulan="April";
                                  }
                                  elseif ($bulan==5) {
                                    $bulan="Mei";
                                  }
                                  elseif ($bulan==6) {
                                    $bulan="Juni";
                                  }
                                  elseif ($bulan==7) {
                                    $bulan="Juli";
                                  }
                                  elseif ($bulan==8) {
                                    $bulan="Agustus";
                                  }
                                  elseif ($bulan==9) {
                                    $bulan="September";
                                  }
                                  elseif ($bulan==10) {
                                    $bulan="Oktober";
                                  }
                                  elseif ($bulan==11) {
                                    $bulan="November";
                                  }
                                  elseif ($bulan==12) {
                                    $bulan="Desember";
                                  }
                                }
                              }
                              elseif ($cek_panjang_tanggal==8) {
                                // format m/d/yyyy
                                  $bulan = substr($r->tanggallahir_siswa,0,1);
                                  $hari = substr($r->tanggallahir_siswa,2,1);
                                  $tahun = substr($r->tanggallahir_siswa,4,4);
                                  if ($bulan==1) {
                                    $bulan="Januari";
                                  }
                                  elseif ($bulan==2) {
                                    $bulan="Februari";
                                  }
                                  elseif ($bulan==3) {
                                    $bulan="Maret";
                                  }
                                  elseif ($bulan==4) {
                                    $bulan="April";
                                  }
                                  elseif ($bulan==5) {
                                    $bulan="Mei";
                                  }
                                  elseif ($bulan==6) {
                                    $bulan="Juni";
                                  }
                                  elseif ($bulan==7) {
                                    $bulan="Juli";
                                  }
                                  elseif ($bulan==8) {
                                    $bulan="Agustus";
                                  }
                                  elseif ($bulan==9) {
                                    $bulan="September";
                                  }
                                  elseif ($bulan==10) {
                                    $bulan="Oktober";
                                  }
                                  elseif ($bulan==11) {
                                    $bulan="November";
                                  }
                                  elseif ($bulan==12) {
                                    $bulan="Desember";
                                  }
                              }
                              else{
                                //format mm/dd/yyyy
                                  $bulan = substr($r->tanggallahir_siswa,0,2);
                                  $hari = substr($r->tanggallahir_siswa,3,2);
                                  $tahun = substr($r->tanggallahir_siswa,6,4);
                                  if ($bulan==1) {
                                    $bulan="Januari";
                                  }
                                  elseif ($bulan==2) {
                                    $bulan="Februari";
                                  }
                                  elseif ($bulan==3) {
                                    $bulan="Maret";
                                  }
                                  elseif ($bulan==4) {
                                    $bulan="April";
                                  }
                                  elseif ($bulan==5) {
                                    $bulan="Mei";
                                  }
                                  elseif ($bulan==6) {
                                    $bulan="Juni";
                                  }
                                  elseif ($bulan==7) {
                                    $bulan="Juli";
                                  }
                                  elseif ($bulan==8) {
                                    $bulan="Agustus";
                                  }
                                  elseif ($bulan==9) {
                                    $bulan="September";
                                  }
                                  elseif ($bulan==10) {
                                    $bulan="Oktober";
                                  }
                                  elseif ($bulan==11) {
                                    $bulan="November";
                                  }
                                  elseif ($bulan==12) {
                                    $bulan="Desember";
                                  }
                              }
                              
                              ?>
                              <td><?php echo "$r->tempatlahir_siswa , $hari $bulan $tahun"; ?></td>
                            </tr>
                            <tr>
                              <td width="20px">4.</td>
                              <td width="200px">Jenis Kelamin</td>
                              <td width="20px">:</td>
                              <td><?php echo "$r->jeniskelamin_siswa"; ?></td>
                            </tr>
                            <tr>
                              <td width="20px">5.</td>
                              <td width="200px">Agama</td>
                              <td width="20px">:</td>
                              <td>Belum Ada Data</td>
                            </tr>
                            <tr>
                              <td width="20px">6.</td>
                              <td width="200px">Status Dalam Keluarga</td>
                              <td width="20px">:</td>
                              <td>Belum Ada Data</td>
                            </tr>
                            <tr>
                              <td width="20px">7.</td>
                              <td width="200px">Anak ke</td>
                              <td width="20px">:</td>
                              <td>Belum Ada Data</td>
                            </tr>
                            <tr>
                              <td width="20px">8.</td>
                              <td width="200px">Alamat Peserta Didik</td>
                              <td width="20px">:</td>
                              <?php
                              $kec = substr($r->kecamatan,4);
                              ?>
                              <td><?php echo "RT $r->rt RW $r->rw Desa $r->desa Kecamatan $kec kabupaten $r->kabupaten kedepos belum ada data"; ?></td> 
                            </tr>
                            <tr>
                              <td width="20px">9.</td>
                              <td width="200px">No telepon Rumah / HP</td>
                              <td width="20px">:</td>
                              <td>Belum ada data</td> 
                            </tr>
                            <tr>
                              <td width="20px">10.</td>
                              <td width="200px">Sekolah Asal</td>
                              <td width="20px">:</td>
                              <td>Belum ada data</td> 
                            </tr>
                            <tr>
                              <td width="20px">11.</td>
                              <td width="200px">Di terima di sekolah ini</td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>Di kelas</td>
                              <td> : </td>
                              <td>Belum ada data</td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>Pada tanggal</td>
                              <td> : </td>
                              <td>Belum ada data</td>
                            </tr>
                            <tr>
                              <td width="20px">12.</td>
                              <td width="200px">Nama Orang Tua</td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>a. Ayah</td>
                              <td> : </td>
                              <td><?php echo "$r->nama_ayah"; ?></td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>b. Ibu</td>
                              <td> : </td>
                              <td><?php echo "$r->nama_ibu"; ?></td>
                            </tr>
                            <tr>
                              <td width="20px">13.</td>
                              <td width="200px">Alamat Orang Tua</td>
                              <td width="20px">:</td>
                              <td>Belum ada data</td> 
                            </tr>
                            <tr>
                              <td></td>
                              <td width="200px">No telepon Rumah / HP</td>
                              <td width="20px">:</td>
                              <td>Belum ada data</td> 
                            </tr>
                            <tr>
                              <td width="20px">14.</td>
                              <td width="200px">Pekerjaan Orang Tua</td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>a. Ayah</td>
                              <td> : </td>
                              <td><?php echo "$r->pekerjaan_ayah"; ?></td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>b. Ibu</td>
                              <td> : </td>
                              <td><?php echo "$r->pekerjaan_ibu"; ?></td>
                            </tr>
                            <tr>
                              <td width="20px">15.</td>
                              <td width="200px">Nama Wali Peserta Didik</td>
                              <td width="20px">:</td>
                              <td>Belum ada data</td> 
                            </tr>
                            <tr>
                              <td width="20px">16.</td>
                              <td width="200px">Alamat Wali</td>
                              <td width="20px">:</td>
                              <td>Belum ada data</td> 
                            </tr>
                            <tr>
                              <td></td>
                              <td width="200px">No telepon Rumah / HP</td>
                              <td width="20px">:</td>
                              <td>Belum ada data</td> 
                            </tr>
                            <tr>
                              <td width="20px">17.</td>
                              <td width="200px">Pekerjaan Wali Peserta Didik</td>
                              <td width="20px">:</td>
                              <td>Belum ada data</td> 
                            </tr>
                          </table>
                          <br>
            <?php
            $tanggal1 = substr(date('d-m-Y'),0,1);
            $tanggal2 = substr(date('d-m-Y'),1,1);
            $bulan = substr(date('d-m-Y'),3,2);
            $tahun = substr(date('d-m-Y'),6,4);
            if ($bulan==01) {
              $b="Januari";
            }
            elseif ($bulan==02) {
              $b="Februari";
            }
            elseif ($bulan==03) {
              $b="Maret";
            }
            elseif ($bulan==04) {
              $b="April";
            }
            elseif ($bulan==05) {
              $b="Mei";
            }
            elseif ($bulan==06) {
              $b="Juni";
            }
            elseif ($bulan==07) {
              $b="Juli";
            }
            elseif ($bulan==08) {
              $b="Agustus";
            }
            elseif ($bulan==09) {
              $b="Sebtember";
            }
            elseif ($bulan==10) {
              $b="Oktober";
            }
            elseif ($bulan==11) {
              $b="November";
            }
            elseif ($bulan==12) {
              $b="Desember";
            }
            ?>
            <table width="100%">
              <tr>
                <td width="40%">&nbsp;</td>
                <td width="10%">&nbsp;</td>
                <td width="50%">
                  <?php
                  if ($tanggal1==1 || $tanggal1==2 || $tanggal1==3) {?>
                    <p align="left"><?php echo "Purbalingga {$tanggal1}{$tanggal2} {$b} {$tahun}"; ?></p>
                    <?php
                  }
                  else{?>
                    <p align="left"><?php echo "Purbalingga, {$tanggal2} {$b} {$tahun}"; ?></p>
                    <?php
                  }
                  ?>
                </td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>Kepala Sekolah</td>
              </tr>
              <tr>
                <td align="right">
                  <table align="right" class="table1" border="1" height="70px" width="40">
                    <tr>
                      <td class="td" height="60px" width="30"><center>pasfoto 3x4</center></td>
                    </tr>
                  </table>
                </td>
                <td height="60px" width="30">&nbsp;</td>
                <td >&nbsp;</td>
              </tr>
              <?php foreach ($kepala_sekolah as $k)?>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td><?php echo "$k->nama_guru"; ?></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td><?php echo "NIP. {$k->nomor_induk}"; ?></td>
              </tr>
            </table>

            <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/template/build/js/custom.min.js"></script>

    <!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
  </body>
</html>