         <style>
      .table1 {
    font-family: sans-serif;
    color: #232323;
    border-collapse: collapse;
}

.table1, .th, .td {
    border: 1px solid #999;
}
</style>

 <table width="100%">
 <?php foreach ($rapot as $r) {} ?>
                            <tr>
                              <td width="350">
                                <table >
                                  <tr>
                                    <td width="100">Nama Sekolah</td>
                                    <td width="1">:</td>
                                    <td>SMA N 1 Rembang , Purbalingga</td>
                                  </tr>
                                  <tr>
                                    <td >Alamat</td>
                                    <td >:</td>
                                    <td>Jalan Monumen Jendral Soedirman</td>
                                  </tr>
                                  <tr>
                                    <td ></td>
                                    <td ></td>
                                    <td>Rembang,Purbalingga 53356</td>
                                  </tr>
                                  <tr>
                                    <td >Nama Peserta Didik</td>
                                    <td >:</td>
                                    <td><?php echo "$r->nama_siswa"; ?></td>
                                  </tr>
                                  <tr>
                                    <td >Nomor Induk / NISN</td>
                                    <td >:</td>
                                    <td><?php echo "$r->nis / $r->nisn"; ?></td>
                                  </tr>
                                </table>
                              </td>
                              <td align="right" valign="top" width="150">
                                <table >
                                  <tr>
                                    <td width="50" >Kelas</td>
                                    <td >:</td>
                                    <td><?php echo "$r->nama_kelas"; ?></td>
                                  </tr>
                                  <tr>
                                    <td >semester</td>
                                    <td >:</td>
                                    <?php 
                                       $semester=substr($r->nama_ta,10);
                                       if ($semester==1) { ?>
                                         <td><?php echo "$semester / Ganjil"; ?></td>
                                         <?php
                                       }
                                       elseif ($semester==2) { ?>
                                         <td><?php echo "$semester / Genap"; ?></td>
                                         <?php
                                       }
                                     ?>
                                  </tr>
                                  <tr>
                                    <td >Tahun Pelajaran</td>
                                    <td >:</td>
                                    <?php
                                    $ta=substr($r->nama_ta,0,9);
                                    ?>
                                    <td><?php echo "$ta"; ?></td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                          </table>
<br><br>
                          <h3 align="center">DESKRIPSI PENGETAHUAN DAN KETRAMPILAN</h3>
                          <br><br>
                          <table border="1" width="100%" class="table1">
                            <tr>
                              <th class="th">No.</th>
                              <th width="150px" class="th">Mata Pelajaran</th>
                              <th width="100px" class="th">Aspek</th>
                              <th class="th">Deskripsi</th>
                            </tr>
                            <tr>
                              <th colspan="4" class="th" align="left">Kelompok A ( Umum )</th>
                            </tr>
                            <?php 
                            $no=0;
                            foreach($rapotpk as $p){ 
                            $no=$no+1;
                            ?>
                            <tr>
                              <td rowspan="2" class="td"><?php echo "$no"; ?></td>
                              <td rowspan="2" class="td"><?php echo "$p->nama_matapelajaran"; ?></td>
                              <td class="td">Pengetahuan</td>
                              <td class="td"><?php echo "$p->komentar_pengetahuan"; ?></td>
                            </tr>
                            <tr>
                              <td class="td">Keterampi</td>
                              <td class="td"><?php echo "$p->komentar_keterampilan"; ?></td>
                            </tr>
                            <?php } ?>
                          </table>