    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Daftar Nilai</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Cari!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Data Nilai Siswa SMA N 1 Rembang</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>

                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                <div class="accordion" id="accordion" role="tablist" aria-multiselectable="true">
                      <div class="panel">
                        <a class="panel-heading collapsed" role="tab" id="headingTwo" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                          <h4 class="panel-title">Tampilkan Data Berdasarkan Matapelajaran</h4>
                        </a>
                        <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                          <div class="panel-body">
                            <p><strong>Pilih Mata Pelajaran</strong>
                            </p>
                             <?php foreach($guru as $g) ?>
                              <a href="<?php echo base_url("index.php/guru/daftar_nilai/".$g->id_guru); ?>" type="button" class="btn btn-primary">SEMUA MAPEL</a>
                            <?php
                            foreach($ajar as $a){?>
                            <a href="<?php echo base_url('index.php/guru/daftar_nilai_ujian_mapel/'.$a->id_matapelajaran); ?>" class="btn btn-primary" ><?php echo "$a->nama_matapelajaran"; ?></a>
                            <?php
                            }
                            ?>
                          </div>
                        </div>
                      </div>
                      <div class="panel">
                        <a class="panel-heading collapsed" role="tab" id="headingThree" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                          <h4 class="panel-title">Tampilkan Data Berdasarkan Kelas Dan Matapelajaran</h4>
                        </a>
                        <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                          <div class="panel-body">
                            <p><strong>Pilih Kelas Dan Mapel</strong>
                            </p>
                            <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/guru/daftar_nilai_ujian_kelas'); ?>" method="post" novalidate>
                              <div class="item form-group">
                              <?php foreach($ajar as $g)?>
                              <input type="hidden" name="id_guru" value="<?php echo $g->id_guru ?>">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="mata_pelajaran">Mata Pelajaran <span class="required">*</span>
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">

                              <select name="matapelajaran" >
                              <option value="0">-Pilih Mata Pelajaran-</option>
                              <?php 
                                foreach($ajar as $a){ 
                                echo "<option value=$a->id_matapelajaran >{$a->nama_matapelajaran}</option>";}
                                ?></select>
                                </div>
                                </div>
                                 <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="kelas">kelas <span class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                      <select name="kelas" >
                                      <option value="0">-Pilih Kelas-</option>
                                      <?php 
                                      foreach($kelas as $k){
                                      echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                      ?>
                                      </select>
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                    <button id="send" type="submit" class="btn btn-success">Tampilkan</button>
                                  </div>
                                  </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- end of accordion -->

                    <p class="text-muted font-13 m-b-30">
                      Jangan lupa untuk cek data dan jika terdapat kesalahan Segera !!! di perbaiki
                    </p>
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>NIS</th>
                          <th>Nama</th>
                          <th>Matapelajaran</th>
                          <th>Tahun Ajaran</th>
                          <th>Kelas</th>
                          <th>UTS</th>
                          <th>UAS</th>
                          <th>Praktek</th>
                          <th>Rerata</th>
                          <th>Tindakan</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php 
                            $no=0;
                                foreach($nilai_ujian as $n){
                                $no=$no+1;
                                echo "<tr>";
                                echo "<td>{$no}</td>"; 
                                echo "<td>{$n->nis}</td>";
                                echo "<td>{$n->nama_siswa}</td>";
                                echo "<td>{$n->nama_matapelajaran}</td>";
                                echo "<td>{$n->nama_ta}</td>";
                                echo "<td>{$n->nama_kelas}</td>";
                                if($n->uts<$n->kkm){
                                  echo "<td><b><p style='color:red'>{$n->uts}</p></b></td>";
                                }
                                else {
                                  echo "<td><b>{$n->uts}</b></td>";
                                }
                                if($n->uas<$n->kkm){
                                  echo "<td><b><p style='color:red'>{$n->uas}</p></b></td>";
                                }
                                else {
                                  echo "<td><b>{$n->uas}</b></td>";
                                }
                                if($n->praktek<$n->kkm){
                                  echo "<td><b><p style='color:red'>{$n->praktek}</p></b></td>";
                                }
                                else {
                                  echo "<td><b>{$n->praktek}</b></td>";
                                }
                                $rerata=($n->uts+$n->uas+$n->praktek)/3;
                                $rerata_tampil=number_format($rerata,2);
                                echo "<td>{$rerata_tampil}</td>";
                                ?>
                                <td><a href="<?php echo base_url("index.php/guru/edit_nilai_ujian/".$n->id_nilai_ujian); ?>" type="button" class="btn btn-primary btn-xs">EDIT</a>
                                  <a href="<?php echo base_url("index.php/guru/hapus_nilai_ujian/".$n->id_nilai_ujian); ?>" type="button" class="btn btn-danger btn-xs">HAPUS</a>
                  </td>
                  <?php
                              echo "</tr>";}
                        ?>
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Kerja Praktek Jurusan Teknik Informatika Universites Islam Indonesia by azizsembada
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/template/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/template/build/js/custom.min.js"></script>

    <!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
  </body>
</html>