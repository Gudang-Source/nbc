        <!-- page content -->

        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Tambah Nilai</h3>
              </div>

              <div class="title_right">
                </div>
              </div>
            </div>
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Form Tambah Nilai Remidial 2</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="" role="tabpanel" data-example-id="togglable-tabs">
                      <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Input dengan Excel</a>
                        </li>
                        <li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Input dengan Form</a>
                        </li>
                      </ul>
                      <div id="myTabContent" class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
                           <p>Pastikan File yang di upload adalah file exel yang benar</p>
                      <span class="section">Upload file Exel</span>
                      <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/guru/proses_tambah_nilai_remidi2'); ?>" method="post" enctype="multipart/form-data" novalidate>
                      <?php
                      foreach($ajar as $g){}?>
                      <input type="hidden" name="id_guru" value="<?php echo $g->id_guru ?>">
                      <input type="hidden" name="kkm" value="<?php echo $g->kkm ?>">
                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="mata_pelajaran">Mata Pelajaran <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">

                          <select name="matapelajaran" >
                              <option value="0">-Pilih Mata Pelajaran-</option>
                              <?php 
                                foreach($ajar as $a){ 
                                echo "<option value=$a->id_matapelajaran >{$a->nama_matapelajaran}</option>";}
                                ?>

                          </select>
                        </div>
                      </div>
                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="tahun_ajaran">Tahun Ajaran <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                      <select name="ta" >
                              <option value="0">-Pilih Tahun Ajaran-</option>
                              <?php 
                                foreach($tahun_ajaran as $t){ 
                                echo "<option value=$t->id_ta >{$t->nama_ta}</option>";}
                                ?>

                      </select>
                        </div>
                      </div>
                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="kelas">kelas <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">

                          <select name="kelas" >
                              <option value="0">-Pilih Kelas-</option>
                              <?php 
                                foreach($kelas as $k){

                                    echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                    ?>
                          </select>
                        </div>
                      </div>
                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="nama">File Excel<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  id="file" name="file" placeholder="" required="required" type="file">
                        </div>
                      </div>
                      <div class="ln_solid"></div>
                      <h3><font color="red">PASTIKAN FILE EXCEL YANG ANDA UPLOAD ADALAH FILE YANG BENAR !!!</font></h3>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">
                          <a href="<?php echo base_url('index.php/guru/daftar_nilai'); ?>" class="btn btn-primary">Cancel</a>
                          <button id="send" type="submit" class="btn btn-success">Submit</button>
                        </div>
                      </div>
                    </form>
                    <?php echo $this->session->flashdata('msg'); ?>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
                          <p>Pastikan data yang di input benar</p>
                      <span class="section">Input Data Nilai</span>
                      <form class="form-horizontal form-label-left" action="<?php echo base_url('index.php/guru/proses_tambah_nilai_remidi2_form'); ?>" method="post" enctype="multipart/form-data" novalidate>
                      <?php
                      foreach($ajar as $g){}?>
                      <input type="hidden" name="id_guru" value="<?php echo $g->id_guru ?>">
                      <input type="hidden" name="kkm" value="<?php echo $g->kkm ?>">
                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="mata_pelajaran">Mata Pelajaran<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">

                          <select name="matapelajaran" >
                              <option value="0">-Pilih Mata Pelajaran-</option>
                              <?php 
                                foreach($ajar as $a){ 
                                echo "<option value=$a->id_matapelajaran >{$a->nama_matapelajaran}</option>";}
                                ?>

                          </select>
                        </div>
                      </div>
                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="tahun_ajaran">Tahun Ajaran <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                      <select name="ta" >
                              <option value="0">-Pilih Tahun Ajaran-</option>
                              <?php 
                                foreach($tahun_ajaran as $t){ 
                                echo "<option value=$t->id_ta >{$t->nama_ta}</option>";}
                                ?>

                      </select>
                        </div>
                      </div>
                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="kelas">kelas <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">

                          <select name="kelas" >
                              <option value="0">-Pilih Kelas-</option>
                              <?php 
                                foreach($kelas as $k){

                                    echo "<option value=$k->id_kelas >{$k->nama_kelas}</option>";}
                                    ?>
                          </select>
                        </div>
                      </div>
                       <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="nama">NIS<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  class="form-control col-md-7 col-xs-12" id="nis" name="nis" placeholder="" required="required" type="text">
                        </div>
                        </div>
                        <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="nama">Nilai Remidial 2<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  class="form-control col-md-7 col-xs-12" id="remidi2" name="remidi2" placeholder="" required="required" type="text">
                        </div>
                      </div>
                      <div class="ln_solid"></div>
                      <h3><font color="red">PASTIKAN DATA YANG ANDA INPUT BENAR !!!</font></h3>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">
                          <a href="<?php echo base_url('index.php/guru/daftar_nilai'); ?>" class="btn btn-primary">Cancel</a>
                          <button id="send" type="submit" class="btn btn-success">Submit</button>
                        </div>
                      </div>
                    </form>
                        </div>
                        </div>
                      </div>
                    </div>    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
             Kerja Praktek Jurusan Teknik Informatika Universites Islam Indonesia by azizsembada
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/nprogress/nprogress.js"></script>
    <!-- validator -->
    <script src="<?php echo base_url(); ?>assets/template/vendors/validator/validator.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/template/build/js/custom.min.js"></script>

    <script src="<?php echo base_url(); ?>assets/template/vendors/dropzone/dist/min/dropzone.min.js"></script>

    <!-- validator -->
    <script>
      // initialize the validator function
      validator.message.date = 'not a real date';

      // validate a field on "blur" event, a 'select' on 'change' event & a '.reuired' classed multifield on 'keyup':
      $('form')
        .on('blur', 'input[required], input.optional, select.required', validator.checkField)
        .on('change', 'select.required', validator.checkField)
        .on('keypress', 'input[required][pattern]', validator.keypress);

      $('.multi.required').on('keyup blur', 'input', function() {
        validator.checkField.apply($(this).siblings().last()[0]);
      });

      $('form').submit(function(e) {
        e.preventDefault();
        var submit = true;

        // evaluate the form using generic validaing
        if (!validator.checkAll($(this))) {
          submit = false;
        }

        if (submit)
          this.submit();

        return false;
      });
    </script>
    <!-- /validator -->
  </body>
</html>