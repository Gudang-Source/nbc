<?php 
class Akademik extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('m_data');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
		$this->load->library('PdfGenerator');
		if($this->session->userdata('status') != "login_guru"){
			redirect("login");
		}
	}
	function index(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['siswa']=$this->m_data->jumlah_data_siswa("jeniskelamin_siswa","siswa");
    	$data1['guru']=$this->m_data->jumlah_data_guru("jenis_kelamin","guru");
    	$data1['siswa_kelas_ipa']=$this->m_data->jumlah_kelas_jurusan("IPA");
    	$data1['siswa_kelas_ips']=$this->m_data->jumlah_kelas_jurusan("IPS");
    	$data1['siswa_kelas_x']=$this->m_data->jumlah_kelas("X ");
    	$data1['siswa_kelas_xi']=$this->m_data->jumlah_kelas("XI ");
    	$data1['siswa_kelas_xii']=$this->m_data->jumlah_kelas("XII ");
    	$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/v_akademik',$data1);
	}
	function rapotpk(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$whereu=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($whereu,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
    	$where=array('nis'=>$nis);
    	$data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
    	foreach($data_cek_kelas['siswa'] as $k)
    	$kelas=$k->kelas;
    	$data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
    	$data1['rapotpk']=$this->m_data->rapotpk($nis,'UMUM A',$ta)->result();
    	$data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
    	$where1=array('jabatan'=>'Kepala Sekolah');
    	$data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/rapot_pk',$data1);	
	}
    function rapotpk2(){
        $this->load->model('m_data');
        $u=$this->session->userdata("username");
        $whereu=array('username'=>$u);
        $data_cek['biro_akademik']=$this->m_data->edit_data($whereu,'biro_akademik')->result();
        foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
        $data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
        $where=array('nis'=>$nis);
        $data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
        foreach($data_cek_kelas['siswa'] as $k)
        $kelas=$k->kelas;
        $data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
        $data1['rapotpk']=$this->m_data->rapotpk($nis,'UMUM B',$ta)->result();
        $where_kelas=array('id_kelas'=>$kelas);
        $data_cek_nama_kelas['kelas']=$this->m_data->edit_data($where_kelas,'kelas')->result();
        foreach($data_cek_nama_kelas['kelas'] as $n)
        $nama_kelas=$n->nama_kelas;
        $ps=strlen($nama_kelas);
        for ($i=0; $i < $ps; $i++) { 
            $get_char=substr($nama_kelas, $i,1);
            if ($get_char=="I") {
                $get_jurusan=substr($nama_kelas, $i,3);
            }
        }
        $data1['rapotpk2']=$this->m_data->rapotpk_peminatan($nis,$get_jurusan,$ta)->result();
        $data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
        $where1=array('jabatan'=>'Kepala Sekolah');
        $data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
        $this->load->view('main/v_akademik_header',$data);
        $this->load->view('main/akademik/list_akademik/rapot_pk2',$data1);   
    }
    function rapotpk3(){
        $this->load->model('m_data');
        $u=$this->session->userdata("username");
        $whereu=array('username'=>$u);
        $data_cek['biro_akademik']=$this->m_data->edit_data($whereu,'biro_akademik')->result();
        foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
        $data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
        $where=array('nis'=>$nis);
        $data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
        foreach($data_cek_kelas['siswa'] as $k)
        $kelas=$k->kelas;
        $data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
        $data1['rapotpk']=$this->m_data->rapotpk($nis,'UMUM B',$ta)->result();
        $where_kelas=array('id_kelas'=>$kelas);
        $data_cek_nama_kelas['kelas']=$this->m_data->edit_data($where_kelas,'kelas')->result();
        foreach($data_cek_nama_kelas['kelas'] as $n)
        $nama_kelas=$n->nama_kelas;
        $ps=strlen($nama_kelas);
        for ($i=0; $i < $ps; $i++) { 
            $get_char=substr($nama_kelas, $i,1);
            if ($get_char=="I") {
                $get_jurusan=substr($nama_kelas, $i,3);
            }
        }
        if ($get_jurusan=='IPA') {
            $lintas_minat='IPS';
        }
        elseif ($get_jurusan=='IPS') {
            $lintas_minat='IPA';
        }
        $data1['rapotpk2']=$this->m_data->rapotpk_peminatan($nis,$lintas_minat,$ta)->result();
        $data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
        $where1=array('jabatan'=>'Kepala Sekolah');
        $data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
        $this->load->view('main/v_akademik_header',$data);
        $this->load->view('main/akademik/list_akademik/rapot_pk3',$data1);   
    }
    function rapotpk4(){
        $this->load->model('m_data');
        $u=$this->session->userdata("username");
        $whereu=array('username'=>$u);
        $data_cek['biro_akademik']=$this->m_data->edit_data($whereu,'biro_akademik')->result();
        foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
        $data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
        $where=array('nis'=>$nis);
        $data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
        foreach($data_cek_kelas['siswa'] as $k)
        $kelas=$k->kelas;
        $data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
        $data1['rapot_b']=$this->m_data->rapotpk($nis,'UMUM B',$ta)->result();
        $data1['rapot_a']=$this->m_data->rapotpk($nis,'UMUM A',$ta)->result();
        $where_kelas=array('id_kelas'=>$kelas);
        $data_cek_nama_kelas['kelas']=$this->m_data->edit_data($where_kelas,'kelas')->result();
        foreach($data_cek_nama_kelas['kelas'] as $n)
        $nama_kelas=$n->nama_kelas;
        $ps=strlen($nama_kelas);
        for ($i=0; $i < $ps; $i++) { 
            $get_char=substr($nama_kelas, $i,1);
            if ($get_char=="I") {
                $get_jurusan=substr($nama_kelas, $i,3);
            }
        }
        if ($get_jurusan=='IPA') {
            $lintas_minat='IPS';
        }
        elseif ($get_jurusan=='IPS') {
            $lintas_minat='IPA';
        }
        $data1['rapotpk2']=$this->m_data->rapotpk_peminatan($nis,$lintas_minat,$ta)->result();
        $data1['rapotpk3']=$this->m_data->rapotpk_peminatan($nis,$get_jurusan,$ta)->result();
        $data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
        $where1=array('jabatan'=>'Kepala Sekolah');
        $data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
        $this->load->view('main/v_akademik_header',$data);
        $this->load->view('main/akademik/list_akademik/rapot_pk4',$data1);   
    }
	function rapot_sikap(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$whereu=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($whereu,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
    	$where=array('nis'=>$nis);
    	$data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
    	foreach($data_cek_kelas['siswa'] as $k)
    	$kelas=$k->kelas;
    	$data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
    	$data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
    	$where1=array('jabatan'=>'Kepala Sekolah');
    	$data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/rapot_sikap',$data1);	
	}
    function rapot_extra(){
        $this->load->model('m_data');
        $u=$this->session->userdata("username");
        $whereu=array('username'=>$u);
        $data_cek['biro_akademik']=$this->m_data->edit_data($whereu,'biro_akademik')->result();
        foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
        $data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
        $where=array('nis'=>$nis);
        $data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
        foreach($data_cek_kelas['siswa'] as $k)
        $kelas=$k->kelas;
        $data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
        $data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
        $where1=array('jabatan'=>'Kepala Sekolah');
        $data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
        $data1['nilai_eskul']=$this->m_data->daftar_nilai_peserta_eskul($nis,$ta)->result();
        $data1['catatan_wali_kelas']=$this->m_data->catatan_wali_kelas($nis,$ta,$kelas)->result();
        $where_prestasi=array('nis'=>$nis,
                              'ta'=>$ta);
        $data1['prestasi_siswa']=$this->m_data->edit_data($where_prestasi,'prestasi_siswa')->result();
        $cek= $this->m_data->edit_data($where_prestasi,"prestasi_siswa")->num_rows();
        if ($cek>0) {
            $this->load->view('main/v_akademik_header',$data);
            $this->load->view('main/akademik/list_akademik/rapot_extra_prestasi',$data1);
        }
        else{
            $this->load->view('main/v_akademik_header',$data);
            $this->load->view('main/akademik/list_akademik/rapot_extra',$data1);
        }    
    }
	function rapot_lhb(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$whereu=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($whereu,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
    	$where=array('nis'=>$nis);
    	$data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
    	foreach($data_cek_kelas['siswa'] as $k)
    	$kelas=$k->kelas;
    	$data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
    	$data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
    	$where1=array('jabatan'=>'Kepala Sekolah');
    	$data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/rapot',$data1);	
	}
	function rapot_kks(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$whereu=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($whereu,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
    	$where=array('nis'=>$nis);
    	$data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
    	foreach($data_cek_kelas['siswa'] as $k)
    	$kelas=$k->kelas;
    	$data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
    	$data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
    	$where1=array('jabatan'=>'Kepala Sekolah');
    	$data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/rapot_kks',$data1);	
	}
	function cetak_rapot_pdf(){
		$this->load->library('PdfGenerator');
 		$this->load->model('m_data');
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
    	$where=array('nis'=>$nis);
    	$data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
    	foreach($data_cek_kelas['siswa'] as $s)
    	$kelas=$s->kelas;
    	$nama_siswa=$s->nama_siswa;
    	$w=array('id_kelas'=>$kelas);
    	$data_cek_nama_kelas['kelas']=$this->m_data->edit_data($w,'kelas')->result();
    	foreach($data_cek_nama_kelas['kelas'] as $k)
    	$nama_kelas=$k->nama_kelas;
    	$data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
    	$data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
    	$where1=array('jabatan'=>'Kepala Sekolah');
    	$data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
    	$data1['nilai_eskul']=$this->m_data->daftar_nilai_peserta_eskul($nis,$ta)->result();	
	    $html = $this->load->view('main/akademik/list_akademik/cetak_rapot_pdf',$data1, true);
	    $nama="Rapot {$nis} {$nama_siswa} {$nama_kelas}";
	    $this->pdfgenerator->generate($html,$nama);
	}
	function cetak_rapot_pdf_kks(){
		$this->load->library('PdfGenerator');
 		$this->load->model('m_data');
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
    	$where=array('nis'=>$nis);
    	$data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
    	foreach($data_cek_kelas['siswa'] as $s)
    	$kelas=$s->kelas;
    	$nama_siswa=$s->nama_siswa;
    	$w=array('id_kelas'=>$kelas);
    	$data_cek_nama_kelas['kelas']=$this->m_data->edit_data($w,'kelas')->result();
    	foreach($data_cek_nama_kelas['kelas'] as $k)
    	$nama_kelas=$k->nama_kelas;
    	$data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
    	$data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
    	$where1=array('jabatan'=>'Kepala Sekolah');
    	$data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
    	$data1['nilai_eskul']=$this->m_data->daftar_nilai_peserta_eskul($nis,$ta)->result();	
	    $html = $this->load->view('main/akademik/list_akademik/cetak_rapot_kks_pdf',$data1, true);
	    $nama="Rapot {$nis} {$nama_siswa} {$nama_kelas} KKS";
	    $this->pdfgenerator->generate($html,$nama);
	}

	function cetak_rapot_pdf_pd(){
		$this->load->library('PdfGenerator');
 		$this->load->model('m_data');
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
    	$where=array('nis'=>$nis);
    	$data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
    	foreach($data_cek_kelas['siswa'] as $s)
    	$kelas=$s->kelas;
    	$nama_siswa=$s->nama_siswa;
    	$w=array('id_kelas'=>$kelas);
    	$data_cek_nama_kelas['kelas']=$this->m_data->edit_data($w,'kelas')->result();
    	foreach($data_cek_nama_kelas['kelas'] as $k)
    	$nama_kelas=$k->nama_kelas;
    	$data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
    	$data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
    	$where1=array('jabatan'=>'Kepala Sekolah');
    	$data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
    	$data1['nilai_eskul']=$this->m_data->daftar_nilai_peserta_eskul($nis,$ta)->result();	
	    $html = $this->load->view('main/akademik/list_akademik/cetak_rapot_pd_pdf',$data1, true);
	    $nama="Rapot {$nis} {$nama_siswa} {$nama_kelas} PD";
	    $this->pdfgenerator->generate($html,$nama);
	}
	function cetak_rapot_pdf_pd1($nis){
		$this->load->library('PdfGenerator');
 		$this->load->model('m_data');
    	$where=array('nis'=>$nis);
    	$data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
    	foreach($data_cek_kelas['siswa'] as $s)
    	$kelas=$s->kelas;
    	$nama_siswa=$s->nama_siswa;
    	$w=array('id_kelas'=>$kelas);
    	$data_cek_nama_kelas['kelas']=$this->m_data->edit_data($w,'kelas')->result();
    	foreach($data_cek_nama_kelas['kelas'] as $k)
    	$nama_kelas=$k->nama_kelas;
    	$data1['rapot']=$this->m_data->rapot($nis)->result();
    	$data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
    	$where1=array('jabatan'=>'Kepala Sekolah');
    	$data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
    	$data1['nilai_eskul']=$this->m_data->daftar_nilai_peserta_eskul($nis)->result();	
	    $this->load->view('main/akademik/list_akademik/cetak_rapot_pd_pdf',$data1);
	}
	function rapot_pd(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$whereu=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($whereu,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
    	$where=array('nis'=>$nis);
    	$data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
    	foreach($data_cek_kelas['siswa'] as $k)
    	$kelas=$k->kelas;
    	$data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
    	$data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
    	$where1=array('jabatan'=>'Kepala Sekolah');
    	$data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
    	$data1['nilai_eskul']=$this->m_data->daftar_nilai_peserta_eskul($nis,$ta)->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/rapot_pd',$data1);	
	}
	function daftar_nilai_akhir_kelas_x_ipa(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_jurusan('nilai_akhir','X IPA')->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPA')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('X IPA')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_x_ipa',$data1);	
	}
	function daftar_nilai_akhir_kelas_x_ipa_kelas($id_kelas){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_kelas($id_kelas)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPA')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('X IPA')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_x_ipa',$data1);	
	}
	function daftar_nilai_akhir_kelas_x_ipa_mapel($id_matapelajaran){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_mapel($id_matapelajaran)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPA')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('X IPA')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_x_ipa',$data1);	
	}
	function daftar_nilai_akhir_kelas_x_ipa_kelas_mapel(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
		$matapelajaran=$this->input->post('matapelajaran');
		$kelas=$this->input->post('kelas');
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_mapel_kelas($matapelajaran,$kelas)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPA')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('X IPA')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_x_ipa',$data1);	
	}
	function daftar_nilai_akhir_kelas_x_ips(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik('nilai_akhir','X IPS')->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPS')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('X IPS')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_x_ips',$data1);	
	}
	function daftar_nilai_akhir_kelas_x_ips_kelas($id_kelas){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_kelas($id_kelas)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPS')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('X IPS')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_x_ips',$data1);	
	}
	function daftar_nilai_akhir_kelas_x_ips_mapel($id_matapelajaran){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_mapel($id_matapelajaran)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPS')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('X IPS')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_x_ips',$data1);	
	}
	function daftar_nilai_akhir_kelas_x_ips_kelas_mapel(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
		$matapelajaran=$this->input->post('matapelajaran');
		$kelas=$this->input->post('kelas');
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_mapel_kelas($matapelajaran,$kelas)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPS')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('X IPS')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_x_ips',$data1);	
	}
	function daftar_nilai_akhir_kelas_xi_ipa(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik('nilai_akhir','XI IPA')->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPA')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XI IPA')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xi_ipa',$data1);	
	}
	function daftar_nilai_akhir_kelas_xi_ipa_kelas($id_kelas){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_kelas($id_kelas)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPA')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XI IPA')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xi_ipa',$data1);	
	}
	function daftar_nilai_akhir_kelas_xi_ipa_mapel($id_matapelajaran){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_mapel($id_matapelajaran)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPA')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XI IPA')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xi_ipa',$data1);	
	}
	function daftar_nilai_akhir_kelas_xi_ipa_kelas_mapel(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
		$matapelajaran=$this->input->post('matapelajaran');
		$kelas=$this->input->post('kelas');
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_mapel_kelas($matapelajaran,$kelas)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPA')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XI IPA')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xi_ipa',$data1);	
	}
	function daftar_nilai_akhir_kelas_xi_ips(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik('nilai_akhir','XI IPS')->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPS')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XI IPS')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xi_ips',$data1);	
	}
	function daftar_nilai_akhir_kelas_xi_ips_kelas($id_kelas){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_kelas($id_kelas)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPS')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XI IPS')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xi_ips',$data1);	
	}
	function daftar_nilai_akhir_kelas_xi_ips_mapel($id_matapelajaran){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_mapel($id_matapelajaran)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPS')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XI IPS')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xi_ips',$data1);	
	}
	function daftar_nilai_akhir_kelas_xi_ips_kelas_mapel(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
		$matapelajaran=$this->input->post('matapelajaran');
		$kelas=$this->input->post('kelas');
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_mapel_kelas($matapelajaran,$kelas)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPS')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XI IPS')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xi_ips',$data1);	
	}
	function daftar_nilai_akhir_kelas_xii_ipa(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik('nilai_akhir','XII IPA')->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPA')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XII IPA')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xii_ipa',$data1);	
	}
	function daftar_nilai_akhir_kelas_xii_ipa_kelas($id_kelas){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_kelas($id_kelas)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPA')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XII IPA')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xii_ipa',$data1);	
	}
	function daftar_nilai_akhir_kelas_xii_ipa_mapel($id_matapelajaran){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_mapel($id_matapelajaran)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPA')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XII IPA')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xii_ipa',$data1);	
	}
	function daftar_nilai_akhir_kelas_xii_ipa_kelas_mapel(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
		$matapelajaran=$this->input->post('matapelajaran');
		$kelas=$this->input->post('kelas');
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_mapel_kelas($matapelajaran,$kelas)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPA')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XII IPA')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xii_ipa',$data1);	
	}
	function daftar_nilai_akhir_kelas_xii_ips(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik('nilai_akhir','XII IPS')->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPS')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XII IPS')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xii_ips',$data1);	
	}
	function daftar_nilai_akhir_kelas_xii_ips_kelas($id_kelas){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_kelas($id_kelas)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPS')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XII IPS')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xii_ips',$data1);	
	}
	function daftar_nilai_akhir_kelas_xii_ips_mapel($id_matapelajaran){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_mapel($id_matapelajaran)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPS')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XII IPS')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xii_ips',$data1);	
	}
	function daftar_nilai_akhir_kelas_xii_ips_kelas_mapel(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
		$matapelajaran=$this->input->post('matapelajaran');
		$kelas=$this->input->post('kelas');
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['nilai_akhir']=$this->m_data->daftar_nilai_akademik_mapel_kelas($matapelajaran,$kelas)->result();
    	$data1['matapelajaran'] = $this->m_data->daftar_mapel('IPS')->result();
    	$data1['kelas'] = $this->m_data->daftar_kelas('XII IPS')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_na_kelas_xii_ips',$data1);	
	}
	function update_database(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['siswa']=$this->m_data->jumlah_data_siswa("jeniskelamin_siswa","siswa");
    	$data1['guru']=$this->m_data->jumlah_data_guru("jenis_kelamin","guru");
    	$data1['siswa_kelas_ipa']=$this->m_data->jumlah_kelas_jurusan("IPA");
    	$data1['siswa_kelas_ips']=$this->m_data->jumlah_kelas_jurusan("IPS");
    	$data1['siswa_kelas_x']=$this->m_data->jumlah_kelas("X ");
    	$data1['siswa_kelas_xi']=$this->m_data->jumlah_kelas("XI ");
    	$data1['siswa_kelas_xii']=$this->m_data->jumlah_kelas("XII ");
    	$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
    	$ta = $this->input->post('ta');
		$query_tugas=$this->m_data->nilai_tugas_update()->result();
		foreach($query_tugas as $nt){
			$data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
			$where_tugas = array(
			'id_guru' => $nt->id_guru,
			'nis'=>$nt->nis,
			'kelas'=>$nt->kelas,
			'ta'=>$ta,
			'matapelajaran' => $nt->matapelajaran
			);
			$cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
			if ($cek_tugas>0) {
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
			}
			else{
				$this->session->set_flashdata('msg','Gagal upload ...!!');
			}
		}
		$query_ulangan=$this->m_data->nilai_ulangan_update()->result();
		foreach($query_ulangan as $nt){
			$data_ulangan = array("nilai_ulangan"=> $nt->nilai_ulangan);
			$where_ulangan = array(
			'id_guru' => $nt->id_guru,
			'nis'=>$nt->nis,
			'kelas'=>$nt->kelas,
			'ta'=>$ta,
			'matapelajaran' => $nt->matapelajaran
			);
			$cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
			if ($cek_ulangan>0) {
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
			}
			else{
				$this->session->set_flashdata('msg','Gagal upload ...!!');
			}
		}
		$query_ujian=$this->m_data->nilai_ujian_update()->result();
		foreach($query_ujian as $nt){
			$data_ujian = array("uts"=> $nt->uts,"uas"=> $nt->uas,);
			$where_ujian = array(
			'id_guru' => $nt->id_guru,
			'nis'=>$nt->nis,
			'kelas'=>$nt->kelas,
			'ta'=>$ta,
			'matapelajaran' => $nt->matapelajaran
			);
			$cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
			if ($cek_ujian>0) {
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
			}
			else{
				$this->session->set_flashdata('msg','Gagal upload ...!!');
			}
		}
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/v_akademik_update',$data1);
	}
	function daftar_nilai_eskul($id_eskul){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['eskul'] = $this->m_data->tampil_data('eskul')->result();
    	$data1['siswa'] = $this->m_data->tampil_data('siswa')->result();
    	$data1['nilai_eskul']=$this->m_data->daftar_nilai_eskul($id_eskul)->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_eskul',$data1);	
	}
	function daftar_nilai_eskul_semua(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
    	$data1['eskul'] = $this->m_data->tampil_data('eskul')->result();
    	$data1['siswa'] = $this->m_data->tampil_data('siswa')->result();
    	$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
    	$data1['nilai_eskul']=$this->m_data->daftar_nilai_eskul_semua()->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_eskul',$data1);	
	}
	function daftar_nilai_eskul_kelas(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
		$eskul=$this->input->post('eskul');
		$kelas=$this->input->post('kelas');
		$data1['nilai_eskul']=$this->m_data->daftar_nilai_eskul_kelas($eskul,$kelas)->result();
		$data1['eskul'] = $this->m_data->tampil_data('eskul')->result();
    	$data1['siswa'] = $this->m_data->tampil_data('siswa')->result();
    	$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_eskul',$data1);	
	}
	function daftar_guru(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_guru',$data1);	
	}
	function lihat_tugas_guru($id_guru){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
		$data1['ajar']=$this->m_data->lihat_tugas_guru($id_guru);
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/list_akademik/daftar_ajar_guru',$data1);	
	}
	function setting(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/form_akademik/settings',$data);
	}
	function setting_notif(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data_cek['biro_akademik']=$this->m_data->edit_data($where,'biro_akademik')->result();
		foreach($data_cek['biro_akademik'] as $b)
        $id_biro_akademik=$b->id_biro_akademik;
    	$data['biro_akademik']=$this->m_data->edit_biro_akademik($id_biro_akademik);
		$data1['alert'] = $this->m_data->tampil_data('alert')->result();
		$this->load->view('main/v_akademik_header',$data);
		$this->load->view('main/akademik/form_akademik/settings_notif',$data1,$data);
	}
	function ganti_password(){
		$id_biro_akademik=$this->input->post('id_biro_akademik');
		$password_lama=$this->input->post('password_lama');
		$password_baru=$this->input->post('password_baru');
		$password1=$this->input->post('password1');
		$password2=$this->input->post('password2');

		if($password_lama==$password2 || $password_lama==$password1){
			$data=array(
				'password'=>$password_baru
				);
			$notif="Selamat Password Berhasil di ganti";
			$data_notif=array(
				'ganti_password'=>$notif
				);
			$where=array('id_biro_akademik'=>$id_biro_akademik);
			$where1=array('id'=>'1');
			$table='biro_akademik';
		    $this->m_data->proses_edit_data($where,$data,$table);
		    $this->m_data->proses_edit_data($where1,$data_notif,"alert");
		    redirect('akademik/setting_notif');
		}
		else{
			$notif="Password lama dan baru tidak cocok atau password lama salah";
			$data_notif=array(
				'ganti_password'=>$notif
				);
			$where1=array('id'=>'1');
			$this->m_data->proses_edit_data($where1,$data_notif,"alert");
			 redirect('akademik/setting_notif');
		}
	}
    function cetak_rapot_pdf_ktdpd(){
        $this->load->library('PdfGenerator');
        $this->load->model('m_data');
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
        $where=array('nis'=>$nis);
        $data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
        foreach($data_cek_kelas['siswa'] as $s)
        $kelas=$s->kelas;
        $nama_siswa=$s->nama_siswa;
        $w=array('id_kelas'=>$kelas);
        $data_cek_nama_kelas['kelas']=$this->m_data->edit_data($w,'kelas')->result();
        foreach($data_cek_nama_kelas['kelas'] as $k)
        $nama_kelas=$k->nama_kelas;
        $data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
        $data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
        $where1=array('jabatan'=>'Kepala Sekolah');
        $data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
        $data1['nilai_eskul']=$this->m_data->daftar_nilai_peserta_eskul($nis,$ta)->result();    
        $html = $this->load->view('main/akademik/list_akademik/cetak_rapot_ktdpd_pdf',$data1, true);
        $nama="Rapot {$nis} {$nama_siswa} {$nama_kelas} KTDPD";
        $this->pdfgenerator->generate($html,$nama);
    }
    function cetak_rapot_pdf_sikap(){
        $this->load->library('PdfGenerator');
        $this->load->model('m_data');
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
        $where=array('nis'=>$nis);
        $data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
        foreach($data_cek_kelas['siswa'] as $s)
        $kelas=$s->kelas;
        $nama_siswa=$s->nama_siswa;
        $w=array('id_kelas'=>$kelas);
        $data_cek_nama_kelas['kelas']=$this->m_data->edit_data($w,'kelas')->result();
        foreach($data_cek_nama_kelas['kelas'] as $k)
        $nama_kelas=$k->nama_kelas;
        $data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
        $data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
        $where1=array('jabatan'=>'Kepala Sekolah');
        $data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
        $data1['nilai_eskul']=$this->m_data->daftar_nilai_peserta_eskul($nis,$ta)->result();    
        $html = $this->load->view('main/akademik/list_akademik/cetak_rapot_sikap_pdf',$data1, true);
        $nama="Rapot {$nis} {$nama_siswa} {$nama_kelas} SIKAP";
        $this->pdfgenerator->generate($html,$nama);
    }
    function cetak_rapot_pdf_pk(){
        $this->load->library('PdfGenerator');
        $this->load->model('m_data');
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
        $where=array('nis'=>$nis);
        $data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
        foreach($data_cek_kelas['siswa'] as $s)
        $kelas=$s->kelas;
        $nama_siswa=$s->nama_siswa;
        $w=array('id_kelas'=>$kelas);
        $data_cek_nama_kelas['kelas']=$this->m_data->edit_data($w,'kelas')->result();
        foreach($data_cek_nama_kelas['kelas'] as $k)
        $nama_kelas=$k->nama_kelas;
        $data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
        $data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
        $where1=array('jabatan'=>'Kepala Sekolah');
        $data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
        $data1['nilai_eskul']=$this->m_data->daftar_nilai_peserta_eskul($nis,$ta)->result(); 
        $data1['rapotpk']=$this->m_data->rapotpk($nis,'UMUM A',$ta)->result();   
        $html = $this->load->view('main/akademik/list_akademik/cetak_rapot_pk_pdf',$data1, true);
        $nama="Rapot {$nis} {$nama_siswa} {$nama_kelas} PK";
        $this->pdfgenerator->generate($html,$nama);
    }
    function cetak_rapot_pdf_pk2(){
        $this->load->library('PdfGenerator');
        $this->load->model('m_data');
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
        $where=array('nis'=>$nis);
        $data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
        foreach($data_cek_kelas['siswa'] as $s)
        $kelas=$s->kelas;
        $nama_siswa=$s->nama_siswa;
        $w=array('id_kelas'=>$kelas);
        $data_cek_nama_kelas['kelas']=$this->m_data->edit_data($w,'kelas')->result();
        foreach($data_cek_nama_kelas['kelas'] as $k)
        $nama_kelas=$k->nama_kelas;
        $data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
        $data1['rapotpk']=$this->m_data->rapotpk($nis,'UMUM B',$ta)->result();
        $where_kelas=array('id_kelas'=>$kelas);
        $data_cek_nama_kelas['kelas']=$this->m_data->edit_data($where_kelas,'kelas')->result();
        foreach($data_cek_nama_kelas['kelas'] as $n)
        $nama_kelas=$n->nama_kelas;
        $ps=strlen($nama_kelas);
        for ($i=0; $i < $ps; $i++) { 
            $get_char=substr($nama_kelas, $i,1);
            if ($get_char=="I") {
                $get_jurusan=substr($nama_kelas, $i,3);
            }
        }
        $data1['rapotpk2']=$this->m_data->rapotpk_peminatan($nis,$get_jurusan,$ta)->result();
        $data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
        $where1=array('jabatan'=>'Kepala Sekolah');
        $data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
        $html = $this->load->view('main/akademik/list_akademik/cetak_rapot_pk2_pdf',$data1, true);
        $nama="Rapot {$nis} {$nama_siswa} {$nama_kelas} PK2";
        $this->pdfgenerator->generate($html,$nama);
    }
    function cetak_rapot_pdf_pk3(){
        $this->load->library('PdfGenerator');
        $this->load->model('m_data');
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
        $where=array('nis'=>$nis);
        $data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
        foreach($data_cek_kelas['siswa'] as $s)
        $kelas=$s->kelas;
        $nama_siswa=$s->nama_siswa;
        $w=array('id_kelas'=>$kelas);
        $data_cek_nama_kelas['kelas']=$this->m_data->edit_data($w,'kelas')->result();
        foreach($data_cek_nama_kelas['kelas'] as $k)
        $nama_kelas=$k->nama_kelas;
        $data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
        $data1['rapotpk']=$this->m_data->rapotpk($nis,'UMUM B',$ta)->result();
        $where_kelas=array('id_kelas'=>$kelas);
        $data_cek_nama_kelas['kelas']=$this->m_data->edit_data($where_kelas,'kelas')->result();
        foreach($data_cek_nama_kelas['kelas'] as $n)
        $nama_kelas=$n->nama_kelas;
        $ps=strlen($nama_kelas);
        for ($i=0; $i < $ps; $i++) { 
            $get_char=substr($nama_kelas, $i,1);
            if ($get_char=="I") {
                $get_jurusan=substr($nama_kelas, $i,3);
            }
        }
        if ($get_jurusan=='IPA') {
            $lintas_minat='IPS';
        }
        elseif ($get_jurusan=='IPS') {
            $lintas_minat='IPA';
        }
        $data1['rapotpk2']=$this->m_data->rapotpk_peminatan($nis,$lintas_minat,$ta)->result();
        $data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
        $where1=array('jabatan'=>'Kepala Sekolah');
        $data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
        $html = $this->load->view('main/akademik/list_akademik/cetak_rapot_pk3_pdf',$data1, true);
        $nama="Rapot {$nis} {$nama_siswa} {$nama_kelas} PK3";
        $this->pdfgenerator->generate($html,$nama);
    }
function cetak_rapot_pdf_pk4(){
        $this->load->library('PdfGenerator');
        $this->load->model('m_data');
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
        $where=array('nis'=>$nis);
        $data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
        foreach($data_cek_kelas['siswa'] as $s)
        $kelas=$s->kelas;
        $nama_siswa=$s->nama_siswa;
        $w=array('id_kelas'=>$kelas);
        $data_cek_nama_kelas['kelas']=$this->m_data->edit_data($w,'kelas')->result();
        foreach($data_cek_nama_kelas['kelas'] as $k)
        $nama_kelas=$k->nama_kelas;
        $data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
        $data1['rapot_b']=$this->m_data->rapotpk($nis,'UMUM B',$ta)->result();
        $data1['rapot_a']=$this->m_data->rapotpk($nis,'UMUM A',$ta)->result();
        $where_kelas=array('id_kelas'=>$kelas);
        $data_cek_nama_kelas['kelas']=$this->m_data->edit_data($where_kelas,'kelas')->result();
        foreach($data_cek_nama_kelas['kelas'] as $n)
        $nama_kelas=$n->nama_kelas;
        $ps=strlen($nama_kelas);
        for ($i=0; $i < $ps; $i++) { 
            $get_char=substr($nama_kelas, $i,1);
            if ($get_char=="I") {
                $get_jurusan=substr($nama_kelas, $i,3);
            }
        }
        if ($get_jurusan=='IPA') {
            $lintas_minat='IPS';
        }
        elseif ($get_jurusan=='IPS') {
            $lintas_minat='IPA';
        }
        $data1['rapotpk2']=$this->m_data->rapotpk_peminatan($nis,$lintas_minat,$ta)->result();
        $data1['rapotpk3']=$this->m_data->rapotpk_peminatan($nis,$get_jurusan,$ta)->result();
        $data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
        $where1=array('jabatan'=>'Kepala Sekolah');
        $data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
        $html = $this->load->view('main/akademik/list_akademik/cetak_rapot_pk4_pdf',$data1, true);
        $nama="Rapot {$nis} {$nama_siswa} {$nama_kelas} PK4";
        $this->pdfgenerator->generate($html,$nama);
    }
        function cetak_rapot_pdf_extra(){
        $this->load->library('PdfGenerator');
        $this->load->model('m_data');
        $nis = $this->input->post('nis');
        $ta = $this->input->post('ta');
        $where=array('nis'=>$nis);
        $data_cek_kelas['siswa']=$this->m_data->edit_data($where,'siswa')->result();
        foreach($data_cek_kelas['siswa'] as $k)
        $kelas=$k->kelas;
        $nama_siswa=$k->nama_siswa;
        $where_kelas=array('id_kelas'=>$kelas);
        $data_cek_nama_kelas['kelas']=$this->m_data->edit_data($where_kelas,'kelas')->result();
        foreach($data_cek_nama_kelas['kelas'] as $n)
        $nama_kelas=$n->nama_kelas;
        $data1['rapot']=$this->m_data->rapot($nis,$ta)->result();
        $data1['wali_kelas']=$this->m_data->wali_kelas($kelas)->result();
        $where1=array('jabatan'=>'Kepala Sekolah');
        $data1['kepala_sekolah']=$this->m_data->edit_data($where1,'guru')->result();
        $data1['nilai_eskul']=$this->m_data->daftar_nilai_peserta_eskul($nis,$ta)->result();
        $data1['catatan_wali_kelas']=$this->m_data->catatan_wali_kelas($nis,$ta,$kelas)->result();
        $where_prestasi=array('nis'=>$nis,
                              'ta'=>$ta);
        $data1['prestasi_siswa']=$this->m_data->edit_data($where_prestasi,'prestasi_siswa')->result();
        $cek= $this->m_data->edit_data($where_prestasi,"prestasi_siswa")->num_rows();   
        $html = $this->load->view('main/akademik/list_akademik/cetak_rapot_extra_pdf',$data1, true);
        $nama="Rapot {$nis} {$nama_siswa} {$nama_kelas} EXTRA";
        if ($cek>0) {
            $this->pdfgenerator->generate($html,$nama);
        }
        else{
            $this->pdfgenerator->generate($html,$nama);
        }
        
    }
}