<?php 
class Guru extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('m_data');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
		if($this->session->userdata('status') != "login_guru"){
			redirect("login");
		}
	}

	function index(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['siswa']=$this->m_data->jumlah_data_siswa("jeniskelamin_siswa","siswa");
    	$data1['guru']=$this->m_data->jumlah_data_guru("jenis_kelamin","guru");
    	$data1['siswa_kelas_ipa']=$this->m_data->jumlah_kelas_jurusan("IPA");
    	$data1['siswa_kelas_ips']=$this->m_data->jumlah_kelas_jurusan("IPS");
    	$data1['siswa_kelas_x']=$this->m_data->jumlah_kelas("X ");
    	$data1['siswa_kelas_xi']=$this->m_data->jumlah_kelas("XI ");
    	$data1['siswa_kelas_xii']=$this->m_data->jumlah_kelas("XII ");
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/v_guru',$data1);	
	}
	function daftar_nilai(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$where_cari_ta=array('id_guru'=>$id_guru);
    	$data['cari_ta']=$this->m_data->edit_data($where_cari_ta,'ajar')->result();
		foreach($data['cari_ta'] as $c)
        $cari_ta=$c->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_ulangan']=$this->m_data->daftar_nilai($id_guru,'nilai_ulangan',$cari_ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai',$data1);	
	}
	function daftar_nilai_ketrampilan(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$where_cari_ta=array('id_guru'=>$id_guru);
    	$data['cari_ta']=$this->m_data->edit_data($where_cari_ta,'ajar')->result();
		foreach($data['cari_ta'] as $c)
        $cari_ta=$c->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_ketrampilan']=$this->m_data->daftar_nilai($id_guru,'nilai_ketrampilan',$cari_ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai_ketrampilan',$data1);	
	}
	function daftar_nilai_sikap_spiritual(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
      	$whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_akhir']=$this->m_data->daftar_nilai_sikap_spiritual_k13($ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai_sikap_spiritual',$data1);	
	}
	function daftar_nilai_sikap_spiritual_kelas(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
        $kelas=$this->input->post('kelas');
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_akhir']=$this->m_data->daftar_nilai_sikap_spiritual_k13_kelas($kelas,$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai_sikap_spiritual',$data1);	
	}
	function daftar_nilai_sikap_sosial(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
      	$whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_akhir']=$this->m_data->daftar_nilai_sikap_sosial_k13($ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai_sikap_sosial',$data1);	
	}
	function daftar_nilai_sikap_sosial_kelas(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
        $kelas=$this->input->post('kelas');
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_akhir']=$this->m_data->daftar_nilai_sikap_sosial_k13_kelas($kelas,$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai_sikap_sosial',$data1);	
	}
	function daftar_nilai_akhlaq(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
      	$whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_akhir']=$this->m_data->daftar_nilai_akhlaq($ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai_akhlaq',$data1);	
	}
	function daftar_nilai_akhlaq_kelas(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
        $kelas=$this->input->post('kelas');
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_akhir']=$this->m_data->daftar_nilai_akhlaq_kelas($kelas,$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai_akhlaq',$data1);	
	}
	function daftar_kehadiran_siswa(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
        $whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_akhir']=$this->m_data->daftar_kehadiran($ta)->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_kehadiran',$data1);	
	}
	function daftar_komentar_k13(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_akhir']=$this->m_data->daftar_komentar_k13($id_guru,$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_komentar_k13',$data1);	
	}
	function daftar_komentar_kelas_k13(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$id_guru=$this->input->post('id_guru');
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$matapelajaran=$this->input->post('matapelajaran');
		$kelas=$this->input->post('kelas');
		$whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_akhir']=$this->m_data->daftar_nilai_kelas($id_guru,$matapelajaran,$kelas,'nilai_akhir',$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_komentar_k13',$data1);	
	}
	function daftar_komentar_mapel_k13($id_matapelajaran){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
        $whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
    	$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_akhir']=$this->m_data->daftar_nilai_mapel($id_guru,$id_matapelajaran,'nilai_akhir',$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_komentar_k13',$data1);	
	}
	function daftar_komentar(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_akhir']=$this->m_data->daftar_nilai($id_guru,'nilai_akhir',$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_komentar',$data1);	
	}
	function daftar_komentar_kelas(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$id_guru=$this->input->post('id_guru');
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$matapelajaran=$this->input->post('matapelajaran');
		$kelas=$this->input->post('kelas');
		$whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_akhir']=$this->m_data->daftar_nilai_kelas($id_guru,$matapelajaran,$kelas,'nilai_akhir',$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_komentar',$data1);	
	}
	function daftar_komentar_mapel($id_matapelajaran){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
        $whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
    	$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_akhir']=$this->m_data->daftar_nilai_mapel($id_guru,$id_matapelajaran,'nilai_akhir',$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_komentar',$data1);	
	}
	function daftar_nilai_mapel($id_matapelajaran){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
        $whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
    	$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_ulangan']=$this->m_data->daftar_nilai_mapel($id_guru,$id_matapelajaran,'nilai_ulangan',$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai',$data1);	
	}
	function daftar_nilai_kelas(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$id_guru=$this->input->post('id_guru');
		$whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
		$matapelajaran=$this->input->post('matapelajaran');
		$kelas=$this->input->post('kelas');
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
    	$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_ulangan']=$this->m_data->daftar_nilai_kelas($id_guru,$matapelajaran,$kelas,'nilai_ulangan',$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai',$data1);	
	}
	function daftar_nilai_tugas(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
        $whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['nilai_tugas']=$this->m_data->daftar_nilai($id_guru,'nilai_tugas',$ta)->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai_tugas',$data1);	
	}
	function daftar_nilai_tugas_mapel($id_matapelajaran){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
        $whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
    	$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_tugas']=$this->m_data->daftar_nilai_mapel($id_guru,$id_matapelajaran,'nilai_tugas',$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai_tugas',$data1);	
	}
	function daftar_nilai_tugas_kelas(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$id_guru=$this->input->post('id_guru');
		$whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
		$matapelajaran=$this->input->post('matapelajaran');
		$kelas=$this->input->post('kelas');
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
    	$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_tugas']=$this->m_data->daftar_nilai_kelas($id_guru,$matapelajaran,$kelas,'nilai_tugas',$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai_tugas',$data1);	
	}
	function daftar_nilai_ujian(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
        $whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_ujian']=$this->m_data->daftar_nilai($id_guru,'nilai_ujian',$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai_ujian',$data1);	
	}
	function daftar_nilai_ujian_mapel($id_matapelajaran){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
        $whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
    	$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_ujian']=$this->m_data->daftar_nilai_mapel($id_guru,$id_matapelajaran,'nilai_ujian',$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai_ujian',$data1);	
	}
	function daftar_nilai_ujian_kelas(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$id_guru=$this->input->post('id_guru');
		$whereta=array('id_guru'=>$id_guru);
    	$data['ta']=$this->m_data->edit_data($whereta,'ajar')->result();
    	foreach($data['ta'] as $t)
    	$ta=$t->ta;
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$matapelajaran=$this->input->post('matapelajaran');
		$kelas=$this->input->post('kelas');
    	$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['nilai_ujian']=$this->m_data->daftar_nilai_kelas($id_guru,$matapelajaran,$kelas,'nilai_ujian',$ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_nilai_ujian',$data1);	
	}
	function hapus_nilai_tugas($id_nilai_tugas){
		$where = array('id_nilai_tugas' => $id_nilai_tugas);
		$table='nilai_tugas';
		$this->m_data->hapus_data($where,$table);
		redirect('guru/daftar_nilai_tugas');
	}
	function tambah_nilai_ketrampilan1($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$where=array('id_guru'=>$id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_nilai_ketrampilan1',$data1);
	}
	function tambah_nilai_ketrampilan2($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$where=array('id_guru'=>$id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_nilai_ketrampilan2',$data1);
	}
	function tambah_nilai_ketrampilan3($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$where=array('id_guru'=>$id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_nilai_ketrampilan3',$data1);
	}
	function tambah_nilai_uh1($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$where=array('id_guru'=>$id_guru);
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_nilai_uh1',$data1);
	}
	function edit_nilai($id_nilai){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['nilai_ulangan']=$this->m_data->edit_nilai($id_nilai,'nilai_ulangan','id_nilai')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/edit_nilai',$data1);
	}
	function edit_nilai_ketrampilan($id_nilai_ketrampilan){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['nilai_ketrampilan']=$this->m_data->edit_nilai($id_nilai_ketrampilan,'nilai_ketrampilan','id_nilai_ketrampilan')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/edit_nilai_ketrampilan',$data1);
	}
	function edit_komentar($id_nilai_akhir){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['nilai_akhir']=$this->m_data->edit_nilai($id_nilai_akhir,'nilai_akhir','id_nilai_akhir')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/edit_komentar',$data1);
	}
	function edit_kehadiran_siswa(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
        $nis=$this->input->post('nis');
		$ta=$this->input->post('ta');
		$kelas=$this->input->post('kelas');
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['nilai_akhir']=$this->m_data->edit_kehadiran_siswa($nis,$ta,$kelas)->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/edit_kehadiran_siswa',$data1);
	}
	function edit_nilai_sikap_spiritual(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
    	$nis=$this->input->post('nis');
		$ta=$this->input->post('ta');
		$kelas=$this->input->post('kelas');
		$data1['nilai_akhir']=$this->m_data->edit_nilai_sikap_k13($nis,$ta,$kelas)->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/edit_nilai_sikap_spiritual',$data1);
	}
	function proses_edit_nilai_sikap_spiritual(){
		$nis=$this->input->post('nis');
		$ta=$this->input->post('ta');
		$kelas=$this->input->post('kelas');
		$sikap=$this->input->post('sikap');
		$deskripsi=$this->input->post('deskripsi');

		$data=array(
			'sikap_spiritual'=>$sikap,
			'deskripsi_spiritual'=>$deskripsi
			);

		$where=array('nis'=>$nis,
					 'ta'=>$ta,
					 'kelas'=>$kelas);
		$table='nilai_akhir';
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('guru/daftar_nilai_sikap_spiritual');
	}
	function edit_nilai_sikap_sosial(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
    	$nis=$this->input->post('nis');
		$ta=$this->input->post('ta');
		$kelas=$this->input->post('kelas');
		$data1['nilai_akhir']=$this->m_data->edit_nilai_sikap_k13($nis,$ta,$kelas)->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/edit_nilai_sikap_sosial',$data1);
	}
	function proses_edit_nilai_sikap_sosial(){
		$nis=$this->input->post('nis');
		$ta=$this->input->post('ta');
		$kelas=$this->input->post('kelas');
		$sikap=$this->input->post('sikap');
		$deskripsi=$this->input->post('deskripsi');

		$data=array(
			'sikap_sosial'=>$sikap,
			'deskripsi_sosial'=>$deskripsi
			);

		$where=array('nis'=>$nis,
					 'ta'=>$ta,
					 'kelas'=>$kelas);
		$table='nilai_akhir';
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('guru/daftar_nilai_sikap_sosial');
	}
	function edit_nilai_akhlaq(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
    	$nis=$this->input->post('nis');
		$ta=$this->input->post('ta');
		$kelas=$this->input->post('kelas');
		$data1['nilai_akhir']=$this->m_data->edit_nilai_akhlaq($nis,$ta,$kelas)->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/edit_nilai_akhlaq',$data1);
	}
	function proses_edit_nilai_akhlaq(){
		$nis=$this->input->post('nis');
		$ta=$this->input->post('ta');
		$kelas=$this->input->post('kelas');
		$nilai_kelakuan=$this->input->post('nilai_kelakuan');
		$nilai_kerajinan=$this->input->post('nilai_kerajinan');
		$nilai_kerapihan=$this->input->post('nilai_kerapihan');
		$nilai_kebersihan=$this->input->post('nilai_kebersihan');
		$komentar_kelakuan=$this->input->post('komentar_kelakuan');
		$komentar_kerajinan=$this->input->post('komentar_kerajinan');
		$komentar_kerapihan=$this->input->post('komentar_kerapihan');
		$komentar_kebersihan=$this->input->post('komentar_kebersihan');

		$data=array(
			'nilai_kelakuan'=>$nilai_kelakuan,
			'nilai_kebersihan'=>$nilai_kebersihan,
			'nilai_kerapihan'=>$nilai_kerapihan,
			'nilai_kerajinan'=>$nilai_kerajinan,
			'komentar_kebersihan'=>$komentar_kebersihan,
			'komentar_kerapihan'=>$komentar_kerapihan,
			'komentar_kerajinan'=>$komentar_kerajinan,
			'komentar_kelakuan'=>$komentar_kelakuan
			);

		$where=array('nis'=>$nis,
					 'ta'=>$ta,
					 'kelas'=>$kelas);
		$table='nilai_akhir';
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('guru/daftar_nilai_akhlaq');
	}
	function proses_edit_komentar(){
		$id_nilai_akhir=$this->input->post('id_nilai_akhir');
		$sikap=$this->input->post('sikap');
		$komentar=$this->input->post('komentar');

		$data=array(
			'sikap'=>$sikap,
			'komentar'=>$komentar
			);

		$where=array('id_nilai_akhir'=>$id_nilai_akhir);
		$table='nilai_akhir';
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('guru/daftar_komentar');
	}
	function proses_edit_kehadiran_siswa(){
		$nis=$this->input->post('nis');
		$ta=$this->input->post('ta');
		$kelas=$this->input->post('kelas');
		$s=$this->input->post('sakit');
		$i=$this->input->post('izin');
		$a=$this->input->post('tanpa_keterangan');

		$data=array(
			's'=>$s,
			'i'=>$i,
			'a'=>$a
			);

		$where=array('nis'=>$nis,
					 'ta'=>$ta,
					 'kelas'=>$kelas
			);
		$table='nilai_akhir';
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('guru/daftar_kehadiran_siswa');
	}
	function edit_nilai_tugas($id_nilai_tugas){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['nilai_tugas']=$this->m_data->edit_nilai($id_nilai_tugas,'nilai_tugas','id_nilai_tugas')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/edit_nilai_tugas',$data1);
	}
	function proses_edit_nilai_tugas(){
		$id_nilai=$this->input->post('id_nilai');
		$ulangan1=$this->input->post('tugas1');
		$ulangan2=$this->input->post('tugas2');
		$ulangan3=$this->input->post('tugas3');
		$cn=$this->input->post('nis');
		$matapelajaran=$this->input->post('matapelajaran');
		$ta=$this->input->post('ta');
		$id_guru=$this->input->post('id_guru');

		$data=array(
			'tugas1'=>$tugas1,
			'tugas2'=>$tugas2,
			'tugas3'=>$tugas3
			);

		$where=array('id_nilai_tugas'=>$id_nilai_tugas);
		$table='nilai_tugas';
		$this->m_data->proses_edit_data($where,$data,$table);
		$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
		foreach($query_tugas as $nu){
			$data_tugas = array("nilai_tugas"=> $nu->nilai_tugas);
			$data_rerata = array("rerata"=> $nu->nilai_tugas);
			$data_tugas_insert = array(
				'id_guru' => $nu->id_guru,
				'nis'=>$nu->nis,
				'kelas'=>$nu->kelas,
				'ta'=>$nu->ta,
				'matapelajaran' => $nu->matapelajaran,
				"nilai_ulangan"=> $nu->nilai_ulangan);
			$where_tugas = array(
				'id_guru' => $nu->id_guru,
				'nis'=>$nu->nis,
				'kelas'=>$nu->kelas,
				'ta'=>$nu->ta,
				'matapelajaran' => $nu->matapelajaran);
			$where_rerata = array(
				'id_guru' => $id_guru,
				'nis'=>$cn,
				'ta'=>$ta,
				'matapelajaran' => $matapelajaran
					);
			$cek_tugas = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		} 
		redirect('guru/daftar_nilai_tugas');
	}
	function proses_edit_nilai_ketrampilan(){
		$id_nilai_ketrampilan=$this->input->post('id_nilai_ketrampilan');
		$ketrampilan1=$this->input->post('ketrampilan1');
		$ketrampilan2=$this->input->post('ketrampilan2');
		$ketrampilan3=$this->input->post('ketrampilan3');
		$cn=$this->input->post('nis');
		$matapelajaran=$this->input->post('matapelajaran');
		$ta=$this->input->post('ta');
		$id_guru=$this->input->post('id_guru');

		$data=array(
			'ketrampilan1'=>$ketrampilan1,
			'ketrampilan2'=>$ketrampilan2,
			'ketrampilan3'=>$ketrampilan3
			);

		$where=array('id_nilai_ketrampilan'=>$id_nilai_ketrampilan);
		$table='nilai_ketrampilan';
		$this->m_data->proses_edit_data($where,$data,$table);
		$data['ketrampilan']=$this->m_data->edit_data($where,'nilai_ketrampilan')->result();
		$max=0;
		foreach ($data['ketrampilan'] as $k)
			if ($k->ketrampilan1>$max) {
				$max=$k->ketrampilan1;
			}
			if ($k->ketrampilan2>$max) {
				$max=$k->ketrampilan2;
			}
			if ($k->ketrampilan3>$max) {
				$max=$k->ketrampilan3;
			}
		$data_ketrampilan = array("nilai_ketrampilan"=> $max);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $k->id_guru,
										'nis'=>$k->nis,
										'kelas'=>$k->kelas,
										'ta'=>$k->ta,
										'matapelajaran' => $k->matapelajaran,
								     	"nilai_ketrampilan"=> $max);
						    		 $where_ketrampilan = array(
											'id_guru' => $k->id_guru,
											'nis'=>$k->nis,
											'kelas'=>$k->kelas,
											'ta'=>$k->ta,
											'matapelajaran' => $k->matapelajaran
											);
						    		 $cek_ketrampilan = $this->m_data->edit_data($where_ketrampilan,"nilai_akhir")->num_rows();
						    		 if ($cek_ketrampilan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ketrampilan,$data_ketrampilan,$table);
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ketrampilan_insert);
						    		 }
		redirect('guru/daftar_nilai_ketrampilan');

	}
	function proses_edit_nilai(){
		$id_nilai=$this->input->post('id_nilai');
		$ulangan1=$this->input->post('ulangan1');
		$ulangan2=$this->input->post('ulangan2');
		$ulangan3=$this->input->post('ulangan3');
		$cn=$this->input->post('nis');
		$matapelajaran=$this->input->post('matapelajaran');
		$ta=$this->input->post('ta');
		$id_guru=$this->input->post('id_guru');

		$data=array(
			'ulangan1'=>$ulangan1,
			'ulangan2'=>$ulangan2,
			'ulangan3'=>$ulangan3
			);

		$where=array('id_nilai'=>$id_nilai);
		$table='nilai_ulangan';
		$this->m_data->proses_edit_data($where,$data,$table);
		$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
		redirect('guru/daftar_nilai');

	}
	function edit_nilai_ujian($id_nilai_ujian){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['nilai_ujian']=$this->m_data->edit_nilai($id_nilai_ujian,'nilai_ujian','id_nilai_ujian')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/edit_nilai_ujian',$data1);
	}
	function proses_edit_nilai_ujian(){
		$id_nilai_ujian=$this->input->post('id_nilai_ujian');
		$uts=$this->input->post('uts');
		$uas=$this->input->post('uas');
		$praktek=$this->input->post('praktek');
		$cn=$this->input->post('nis');
		$matapelajaran=$this->input->post('matapelajaran');
		$ta=$this->input->post('ta');
		$id_guru=$this->input->post('id_guru');

		$data=array(
			'uts'=>$uts,
			'uas'=>$uas,
			'praktek'=>$praktek
			);

		$where=array('id_nilai_ujian'=>$id_nilai_ujian);
		$table='nilai_ujian';
		$this->m_data->proses_edit_data($where,$data,$table);
		$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts,
						    		 	"uas"=> $uas,
								     	"nilai_praktek"=> $praktek);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts,
								     	"uas"=> $uas,
								     	"nilai_praktek"=> $praktek
								     	);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}
		redirect('guru/daftar_nilai_ujian');
	}
	function hapus_nilai($id_nilai){
		$where = array('id_nilai' => $id_nilai);
		$table='nilai_ulangan';
		$this->m_data->hapus_data($where,$table);
		redirect('guru/daftar_nilai');
	}
	function hapus_nilai_ketrampilan($id_nilai_ketrampilan){
		$where = array('id_nilai_ketrampilan' => $id_nilai_ketrampilan);
		$table='nilai_ketrampilan';
		$this->m_data->hapus_data($where,$table);
		redirect('guru/daftar_nilai_ketrampilan');
	}
	function hapus_komentar($id_nilai_akhir){
		$sikap='-';
		$komentar='-';

		$data=array(
			'sikap'=>$sikap,
			'komentar'=>$komentar
			);

		$where=array('id_nilai_akhir'=>$id_nilai_akhir);
		$table='nilai_akhir';
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('guru/daftar_komentar');
	}
	function hapus_nilai_ujian($id_nilai_ujian){
		$where = array('id_nilai_ujian' => $id_nilai_ujian);
		$table='nilai_ujian';
		$this->m_data->hapus_data($where,$table);
		redirect('guru/daftar_nilai_ujian');
	}
	function proses_tambah_nilai_uh1_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('id_ta');
		$kelas = $this->input->post('kelas');
		$ulangan1 = $this->input->post('ulangan1');
		$cn=$nis;

		$data = array(
			'nis'=>$cn,
			'id_guru'=>$id_guru,
			'matapelajaran'=>$matapelajaran,
			'ta'=>$ta,
			'kelas'=>$kelas,
			'ulangan1'=>$ulangan1
			);
		$where = array(
					'id_guru' => $id_guru,
					'id_matapelajaran' => $matapelajaran,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"ajar")->num_rows();
		     if($cek > 0){
		     		$where_nis = array( 'id_guru' => $id_guru,
										'matapelajaran' => $matapelajaran,
										'ta'=>$ta,
		     							'nis'=>$cn);
		     		$cek_nis = $this->m_data->edit_data($where_nis,"nilai_ulangan")->num_rows();
		     		if ($cek_nis > 0) {
		     			$this->session->set_flashdata('msg','Gagal upload ...!!');
		     		}
		     		else{
		     			$where_kelas1 = array('kelas1' => $kelas);
					$where_kelas2 = array('kelas2' => $kelas);
					$where_kelas3 = array('kelas3' => $kelas);
					$where_kelas4 = array('kelas4' => $kelas);
					$where_kelas5 = array('kelas5' => $kelas);
					$where_kelas6 = array('kelas6' => $kelas);
					$where_kelas7 = array('kelas7' => $kelas);
					$where_kelas8 = array('kelas8' => $kelas);
					$where_kelas9 = array('kelas9' => $kelas);
					$where_kelas10 = array('kelas10' => $kelas);
					$where_kelas11 = array('kelas11' => $kelas);
					$where_kelas12 = array('kelas12' => $kelas);
					$where_kelas13 = array('kelas13' => $kelas);
					$where_kelas14 = array('kelas14' => $kelas);
					$where_kelas15 = array('kelas15' => $kelas);
					$where_kelas16 = array('kelas16' => $kelas);
					$where_kelas17 = array('kelas17' => $kelas);
					$where_kelas18 = array('kelas18' => $kelas);
					$where_kelas19 = array('kelas19' => $kelas);
					$where_kelas20 = array('kelas20' => $kelas);
					$where_kelas21 = array('kelas21' => $kelas);
					$where_kelas22 = array('kelas22' => $kelas);
					$where_kelas23 = array('kelas23' => $kelas);
					$where_kelas24 = array('kelas24' => $kelas);
					$cek_kelas1 = $this->m_data->edit_data($where_kelas1,"ajar")->num_rows();
					$cek_kelas2 = $this->m_data->edit_data($where_kelas2,"ajar")->num_rows();
					$cek_kelas3 = $this->m_data->edit_data($where_kelas3,"ajar")->num_rows();
					$cek_kelas4 = $this->m_data->edit_data($where_kelas4,"ajar")->num_rows();
					$cek_kelas5 = $this->m_data->edit_data($where_kelas5,"ajar")->num_rows();
					$cek_kelas6 = $this->m_data->edit_data($where_kelas6,"ajar")->num_rows();
					$cek_kelas7 = $this->m_data->edit_data($where_kelas7,"ajar")->num_rows();
					$cek_kelas8 = $this->m_data->edit_data($where_kelas8,"ajar")->num_rows();
					$cek_kelas9 = $this->m_data->edit_data($where_kelas9,"ajar")->num_rows();
					$cek_kelas10 = $this->m_data->edit_data($where_kelas10,"ajar")->num_rows();
					$cek_kelas11 = $this->m_data->edit_data($where_kelas11,"ajar")->num_rows();
					$cek_kelas12 = $this->m_data->edit_data($where_kelas12,"ajar")->num_rows();
					$cek_kelas13 = $this->m_data->edit_data($where_kelas13,"ajar")->num_rows();
					$cek_kelas14 = $this->m_data->edit_data($where_kelas14,"ajar")->num_rows();
					$cek_kelas15 = $this->m_data->edit_data($where_kelas15,"ajar")->num_rows();
					$cek_kelas16 = $this->m_data->edit_data($where_kelas16,"ajar")->num_rows();
					$cek_kelas17 = $this->m_data->edit_data($where_kelas17,"ajar")->num_rows();
					$cek_kelas18 = $this->m_data->edit_data($where_kelas18,"ajar")->num_rows();
					$cek_kelas19 = $this->m_data->edit_data($where_kelas19,"ajar")->num_rows();
					$cek_kelas20 = $this->m_data->edit_data($where_kelas20,"ajar")->num_rows();
					$cek_kelas21 = $this->m_data->edit_data($where_kelas21,"ajar")->num_rows();
					$cek_kelas22 = $this->m_data->edit_data($where_kelas22,"ajar")->num_rows();
					$cek_kelas23 = $this->m_data->edit_data($where_kelas23,"ajar")->num_rows();
					$cek_kelas24 = $this->m_data->edit_data($where_kelas24,"ajar")->num_rows();
					if ($cek_kelas1>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas2>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas3>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas4>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas5>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas6>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas7>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas8>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas9>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas10>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas11>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas12>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas13>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas14>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas15>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas16>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas17>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas18>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas19>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas20>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas21>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas22>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas23>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas24>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					else{
						$this->session->set_flashdata('msg','Gagal upload ...!!'); 
					}
				}
   		}
        redirect('guru/daftar_nilai');
	}
	function proses_tambah_nilai_ketrampilan1_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('id_ta');
		$kelas = $this->input->post('kelas');
		$ketrampilan1 = $this->input->post('ketrampilan1');
		$cn=$nis;

		$data = array(
			'nis'=>$cn,
			'id_guru'=>$id_guru,
			'matapelajaran'=>$matapelajaran,
			'ta'=>$ta,
			'kelas'=>$kelas,
			'ketrampilan1'=>$ketrampilan1
			);
		$where = array(
					'id_guru' => $id_guru,
					'id_matapelajaran' => $matapelajaran,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"ajar")->num_rows();
		     if($cek > 0){
		     		$where_nis = array( 'id_guru' => $id_guru,
										'matapelajaran' => $matapelajaran,
										'ta'=>$ta,
		     							'nis'=>$cn);
		     		$cek_nis = $this->m_data->edit_data($where_nis,"nilai_ketrampilan")->num_rows();
		     		if ($cek_nis > 0) {
		     			$this->session->set_flashdata('msg','Gagal upload ...!!');
		     		}
		     		else{
		     			$where_kelas1 = array('kelas1' => $kelas);
					$where_kelas2 = array('kelas2' => $kelas);
					$where_kelas3 = array('kelas3' => $kelas);
					$where_kelas4 = array('kelas4' => $kelas);
					$where_kelas5 = array('kelas5' => $kelas);
					$where_kelas6 = array('kelas6' => $kelas);
					$where_kelas7 = array('kelas7' => $kelas);
					$where_kelas8 = array('kelas8' => $kelas);
					$where_kelas9 = array('kelas9' => $kelas);
					$where_kelas10 = array('kelas10' => $kelas);
					$where_kelas11 = array('kelas11' => $kelas);
					$where_kelas12 = array('kelas12' => $kelas);
					$where_kelas13 = array('kelas13' => $kelas);
					$where_kelas14 = array('kelas14' => $kelas);
					$where_kelas15 = array('kelas15' => $kelas);
					$where_kelas16 = array('kelas16' => $kelas);
					$where_kelas17 = array('kelas17' => $kelas);
					$where_kelas18 = array('kelas18' => $kelas);
					$where_kelas19 = array('kelas19' => $kelas);
					$where_kelas20 = array('kelas20' => $kelas);
					$where_kelas21 = array('kelas21' => $kelas);
					$where_kelas22 = array('kelas22' => $kelas);
					$where_kelas23 = array('kelas23' => $kelas);
					$where_kelas24 = array('kelas24' => $kelas);
					$cek_kelas1 = $this->m_data->edit_data($where_kelas1,"ajar")->num_rows();
					$cek_kelas2 = $this->m_data->edit_data($where_kelas2,"ajar")->num_rows();
					$cek_kelas3 = $this->m_data->edit_data($where_kelas3,"ajar")->num_rows();
					$cek_kelas4 = $this->m_data->edit_data($where_kelas4,"ajar")->num_rows();
					$cek_kelas5 = $this->m_data->edit_data($where_kelas5,"ajar")->num_rows();
					$cek_kelas6 = $this->m_data->edit_data($where_kelas6,"ajar")->num_rows();
					$cek_kelas7 = $this->m_data->edit_data($where_kelas7,"ajar")->num_rows();
					$cek_kelas8 = $this->m_data->edit_data($where_kelas8,"ajar")->num_rows();
					$cek_kelas9 = $this->m_data->edit_data($where_kelas9,"ajar")->num_rows();
					$cek_kelas10 = $this->m_data->edit_data($where_kelas10,"ajar")->num_rows();
					$cek_kelas11 = $this->m_data->edit_data($where_kelas11,"ajar")->num_rows();
					$cek_kelas12 = $this->m_data->edit_data($where_kelas12,"ajar")->num_rows();
					$cek_kelas13 = $this->m_data->edit_data($where_kelas13,"ajar")->num_rows();
					$cek_kelas14 = $this->m_data->edit_data($where_kelas14,"ajar")->num_rows();
					$cek_kelas15 = $this->m_data->edit_data($where_kelas15,"ajar")->num_rows();
					$cek_kelas16 = $this->m_data->edit_data($where_kelas16,"ajar")->num_rows();
					$cek_kelas17 = $this->m_data->edit_data($where_kelas17,"ajar")->num_rows();
					$cek_kelas18 = $this->m_data->edit_data($where_kelas18,"ajar")->num_rows();
					$cek_kelas19 = $this->m_data->edit_data($where_kelas19,"ajar")->num_rows();
					$cek_kelas20 = $this->m_data->edit_data($where_kelas20,"ajar")->num_rows();
					$cek_kelas21 = $this->m_data->edit_data($where_kelas21,"ajar")->num_rows();
					$cek_kelas22 = $this->m_data->edit_data($where_kelas22,"ajar")->num_rows();
					$cek_kelas23 = $this->m_data->edit_data($where_kelas23,"ajar")->num_rows();
					$cek_kelas24 = $this->m_data->edit_data($where_kelas24,"ajar")->num_rows();
					if ($cek_kelas1>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas2>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas3>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas4>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas5>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas6>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas7>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas8>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas9>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas10>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas11>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas12>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas13>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas14>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas15>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas16>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas17>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas18>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas19>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas20>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas21>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas22>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas23>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas24>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					else{
						$this->session->set_flashdata('msg','Gagal upload ...!!'); 
					}
				}
   		}
        redirect('guru/daftar_nilai_ketrampilan');
	}
	function proses_tambah_nilai_ketrampilan2(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     "ketrampilan2"=> $rowData[0][1]);
		     $where = array(
					'id_guru' => $id_guru,
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ketrampilan")->num_rows();
		     if($cek > 0){
				$table='nilai_ketrampilan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$data['ketrampilan']=$this->m_data->edit_data($where,'nilai_ketrampilan')->result();
		$max=0;
		foreach ($data['ketrampilan'] as $k)
			if ($k->ketrampilan1>$max) {
				$max=$k->ketrampilan1;
			}
			if ($k->ketrampilan2>$max) {
				$max=$k->ketrampilan2;
			}
			if ($k->ketrampilan3>$max) {
				$max=$k->ketrampilan3;
			}
		$data_ketrampilan = array("nilai_ketrampilan"=> $max);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $k->id_guru,
										'nis'=>$k->nis,
										'kelas'=>$k->kelas,
										'ta'=>$k->ta,
										'matapelajaran' => $k->matapelajaran,
								     	"nilai_ketrampilan"=> $max);
						    		 $where_ketrampilan = array(
											'id_guru' => $k->id_guru,
											'nis'=>$k->nis,
											'kelas'=>$k->kelas,
											'ta'=>$k->ta,
											'matapelajaran' => $k->matapelajaran
											);
						    		 $cek_ketrampilan = $this->m_data->edit_data($where_ketrampilan,"nilai_akhir")->num_rows();
						    		 if ($cek_ketrampilan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ketrampilan,$data_ketrampilan,$table);
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ketrampilan_insert);
						    		 }
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai_ketrampilan');
	}
	}
	function proses_tambah_nilai_ketrampilan2_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('id_ta');
		$kelas = $this->input->post('kelas');
		$ketrampilan2 = $this->input->post('ketrampilan2');
		$cn=$nis;

		$data = array(
			'ketrampilan2'=>$ketrampilan2
			);
		$where = array(
					'nis'=>$cn,
					'id_guru' => $id_guru,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ketrampilan")->num_rows();
		     if($cek > 0){
				$table='nilai_ketrampilan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!');
				$data['ketrampilan']=$this->m_data->edit_data($where,'nilai_ketrampilan')->result();
		$max=0;
		foreach ($data['ketrampilan'] as $k)
			if ($k->ketrampilan1>$max) {
				$max=$k->ketrampilan1;
			}
			if ($k->ketrampilan2>$max) {
				$max=$k->ketrampilan2;
			}
			if ($k->ketrampilan3>$max) {
				$max=$k->ketrampilan3;
			}
		$data_ketrampilan = array("nilai_ketrampilan"=> $max);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $k->id_guru,
										'nis'=>$k->nis,
										'kelas'=>$k->kelas,
										'ta'=>$k->ta,
										'matapelajaran' => $k->matapelajaran,
								     	"nilai_ketrampilan"=> $max);
						    		 $where_ketrampilan = array(
											'id_guru' => $k->id_guru,
											'nis'=>$k->nis,
											'kelas'=>$k->kelas,
											'ta'=>$k->ta,
											'matapelajaran' => $k->matapelajaran
											);
						    		 $cek_ketrampilan = $this->m_data->edit_data($where_ketrampilan,"nilai_akhir")->num_rows();
						    		 if ($cek_ketrampilan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ketrampilan,$data_ketrampilan,$table);
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ketrampilan_insert);
						    		 }
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_ketrampilan');
	}
	function proses_tambah_nilai_ketrampilan3_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('id_ta');
		$kelas = $this->input->post('kelas');
		$ketrampilan3 = $this->input->post('ketrampilan3');
		$cn=$nis;

		$data = array(
			'ketrampilan3'=>$ketrampilan3
			);
		$where = array(
					'nis'=>$cn,
					'id_guru' => $id_guru,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ketrampilan")->num_rows();
		     if($cek > 0){
				$table='nilai_ketrampilan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!');
				$data['ketrampilan']=$this->m_data->edit_data($where,'nilai_ketrampilan')->result();
		$max=0;
		foreach ($data['ketrampilan'] as $k)
			if ($k->ketrampilan1>$max) {
				$max=$k->ketrampilan1;
			}
			if ($k->ketrampilan2>$max) {
				$max=$k->ketrampilan2;
			}
			if ($k->ketrampilan3>$max) {
				$max=$k->ketrampilan3;
			}
		$data_ketrampilan = array("nilai_ketrampilan"=> $max);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $k->id_guru,
										'nis'=>$k->nis,
										'kelas'=>$k->kelas,
										'ta'=>$k->ta,
										'matapelajaran' => $k->matapelajaran,
								     	"nilai_ketrampilan"=> $max);
						    		 $where_ketrampilan = array(
											'id_guru' => $k->id_guru,
											'nis'=>$k->nis,
											'kelas'=>$k->kelas,
											'ta'=>$k->ta,
											'matapelajaran' => $k->matapelajaran
											);
						    		 $cek_ketrampilan = $this->m_data->edit_data($where_ketrampilan,"nilai_akhir")->num_rows();
						    		 if ($cek_ketrampilan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ketrampilan,$data_ketrampilan,$table);
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ketrampilan_insert);
						    		 }
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_ketrampilan');
	}
	function proses_tambah_nilai_ketrampilan3(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     "ketrampilan3"=> $rowData[0][1]);
		     $where = array(
					'id_guru' => $id_guru,
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ketrampilan")->num_rows();
		     if($cek > 0){
				$table='nilai_ketrampilan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$data['ketrampilan']=$this->m_data->edit_data($where,'nilai_ketrampilan')->result();
		$max=0;
		foreach ($data['ketrampilan'] as $k)
			if ($k->ketrampilan1>$max) {
				$max=$k->ketrampilan1;
			}
			if ($k->ketrampilan2>$max) {
				$max=$k->ketrampilan2;
			}
			if ($k->ketrampilan3>$max) {
				$max=$k->ketrampilan3;
			}
		$data_ketrampilan = array("nilai_ketrampilan"=> $max);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $k->id_guru,
										'nis'=>$k->nis,
										'kelas'=>$k->kelas,
										'ta'=>$k->ta,
										'matapelajaran' => $k->matapelajaran,
								     	"nilai_ketrampilan"=> $max);
						    		 $where_ketrampilan = array(
											'id_guru' => $k->id_guru,
											'nis'=>$k->nis,
											'kelas'=>$k->kelas,
											'ta'=>$k->ta,
											'matapelajaran' => $k->matapelajaran
											);
						    		 $cek_ketrampilan = $this->m_data->edit_data($where_ketrampilan,"nilai_akhir")->num_rows();
						    		 if ($cek_ketrampilan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ketrampilan,$data_ketrampilan,$table);
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ketrampilan_insert);
						    		 }
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai_ketrampilan');
	}
	}
	function proses_tambah_nilai_ketrampilan1(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     "nis"=> $cn,
		     "id_guru"=>$id_guru,
		     "matapelajaran"=>$matapelajaran,
		     "ta"=>$ta,
		     "kelas"=>$kelas,
		     "ketrampilan1"=> $rowData[0][1]);
		     $where = array(
					'id_guru' => $id_guru,
					'id_matapelajaran' => $matapelajaran,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"ajar")->num_rows();
		     if($cek > 0){
		     		$where_nis = array( 'id_guru' => $id_guru,
										'matapelajaran' => $matapelajaran,
										'ta'=>$ta,
		     							'nis'=>$cn);
		     		$cek_nis = $this->m_data->edit_data($where_nis,"nilai_ketrampilan")->num_rows();
		     		if($cek_nis > 0){
		     			$where_uh = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'kelas'=>$kelas,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
		     			$data_uh = array("ketrampilan1"=> $rowData[0][1]);
		     			$this->m_data->proses_edit_data($where_uh,$data_uh,'nilai_ketrampilan');
		     			$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
		     		}
		     		else{
		     			$where_kelas1 = array('kelas1' => $kelas);
						$where_kelas2 = array('kelas2' => $kelas);
						$where_kelas3 = array('kelas3' => $kelas);
						$where_kelas4 = array('kelas4' => $kelas);
						$where_kelas5 = array('kelas5' => $kelas);
						$where_kelas6 = array('kelas6' => $kelas);
						$where_kelas7 = array('kelas7' => $kelas);
						$where_kelas8 = array('kelas8' => $kelas);
						$where_kelas9 = array('kelas9' => $kelas);
						$where_kelas10 = array('kelas10' => $kelas);
						$where_kelas11 = array('kelas11' => $kelas);
						$where_kelas12 = array('kelas12' => $kelas);
						$where_kelas13 = array('kelas13' => $kelas);
						$where_kelas14 = array('kelas14' => $kelas);
						$where_kelas15 = array('kelas15' => $kelas);
						$where_kelas16 = array('kelas16' => $kelas);
						$where_kelas17 = array('kelas17' => $kelas);
						$where_kelas18 = array('kelas18' => $kelas);
						$where_kelas19 = array('kelas19' => $kelas);
						$where_kelas20 = array('kelas20' => $kelas);
						$where_kelas21 = array('kelas21' => $kelas);
						$where_kelas22 = array('kelas22' => $kelas);
						$where_kelas23 = array('kelas23' => $kelas);
						$where_kelas24 = array('kelas24' => $kelas);
						$cek_kelas1 = $this->m_data->edit_data($where_kelas1,"ajar")->num_rows();
						$cek_kelas2 = $this->m_data->edit_data($where_kelas2,"ajar")->num_rows();
						$cek_kelas3 = $this->m_data->edit_data($where_kelas3,"ajar")->num_rows();
						$cek_kelas4 = $this->m_data->edit_data($where_kelas4,"ajar")->num_rows();
						$cek_kelas5 = $this->m_data->edit_data($where_kelas5,"ajar")->num_rows();
						$cek_kelas6 = $this->m_data->edit_data($where_kelas6,"ajar")->num_rows();
						$cek_kelas7 = $this->m_data->edit_data($where_kelas7,"ajar")->num_rows();
						$cek_kelas8 = $this->m_data->edit_data($where_kelas8,"ajar")->num_rows();
						$cek_kelas9 = $this->m_data->edit_data($where_kelas9,"ajar")->num_rows();
						$cek_kelas10 = $this->m_data->edit_data($where_kelas10,"ajar")->num_rows();
						$cek_kelas11 = $this->m_data->edit_data($where_kelas11,"ajar")->num_rows();
						$cek_kelas12 = $this->m_data->edit_data($where_kelas12,"ajar")->num_rows();
						$cek_kelas13 = $this->m_data->edit_data($where_kelas13,"ajar")->num_rows();
						$cek_kelas14 = $this->m_data->edit_data($where_kelas14,"ajar")->num_rows();
						$cek_kelas15 = $this->m_data->edit_data($where_kelas15,"ajar")->num_rows();
						$cek_kelas16 = $this->m_data->edit_data($where_kelas16,"ajar")->num_rows();
						$cek_kelas17 = $this->m_data->edit_data($where_kelas17,"ajar")->num_rows();
						$cek_kelas18 = $this->m_data->edit_data($where_kelas18,"ajar")->num_rows();
						$cek_kelas19 = $this->m_data->edit_data($where_kelas19,"ajar")->num_rows();
						$cek_kelas20 = $this->m_data->edit_data($where_kelas20,"ajar")->num_rows();
						$cek_kelas21 = $this->m_data->edit_data($where_kelas21,"ajar")->num_rows();
						$cek_kelas22 = $this->m_data->edit_data($where_kelas22,"ajar")->num_rows();
						$cek_kelas23 = $this->m_data->edit_data($where_kelas23,"ajar")->num_rows();
						$cek_kelas24 = $this->m_data->edit_data($where_kelas24,"ajar")->num_rows();
					if ($cek_kelas1>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}		 
					}
					elseif ($cek_kelas2>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas3>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas4>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas5>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas6>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas7>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas8>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas9>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas10>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas11>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas12>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas13>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas14>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas15>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas16>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas17>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas18>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas19>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas20>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas21>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas22>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas23>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas24>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ketrampilan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ketrampilan=$this->m_data->nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ketrampilan as $nu){
						    		 $data_ketrampilan = array("nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ketrampilan);
								     $data_ketrampilan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ketrampilan"=> $nu->nilai_ketrampilan);
						    		 $where_ketrampilan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					else{
						$this->session->set_flashdata('msg','Gagal upload ...!!'); 
					}
		     		}
				}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai_ketrampilan');
	}
	}

	function proses_tambah_nilai_uh1(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     "nis"=> $cn,
		     "id_guru"=>$id_guru,
		     "matapelajaran"=>$matapelajaran,
		     "ta"=>$ta,
		     "kelas"=>$kelas,
		     "ulangan1"=> $rowData[0][1]);
		     $where = array(
					'id_guru' => $id_guru,
					'id_matapelajaran' => $matapelajaran,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"ajar")->num_rows();
		     if($cek > 0){
		     		$where_nis = array( 'id_guru' => $id_guru,
										'matapelajaran' => $matapelajaran,
										'ta'=>$ta,
		     							'nis'=>$cn);
		     		$cek_nis = $this->m_data->edit_data($where_nis,"nilai_ulangan")->num_rows();
		     		if($cek_nis > 0){
		     			$where_uh = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'kelas'=>$kelas,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
		     			$data_uh = array("ulangan1"=> $rowData[0][1]);
		     			$this->m_data->proses_edit_data($where_uh,$data_uh,'nilai_ulangan');
		     			$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
		     		}
		     		else{
		     			$where_kelas1 = array('kelas1' => $kelas);
						$where_kelas2 = array('kelas2' => $kelas);
						$where_kelas3 = array('kelas3' => $kelas);
						$where_kelas4 = array('kelas4' => $kelas);
						$where_kelas5 = array('kelas5' => $kelas);
						$where_kelas6 = array('kelas6' => $kelas);
						$where_kelas7 = array('kelas7' => $kelas);
						$where_kelas8 = array('kelas8' => $kelas);
						$where_kelas9 = array('kelas9' => $kelas);
						$where_kelas10 = array('kelas10' => $kelas);
						$where_kelas11 = array('kelas11' => $kelas);
						$where_kelas12 = array('kelas12' => $kelas);
						$where_kelas13 = array('kelas13' => $kelas);
						$where_kelas14 = array('kelas14' => $kelas);
						$where_kelas15 = array('kelas15' => $kelas);
						$where_kelas16 = array('kelas16' => $kelas);
						$where_kelas17 = array('kelas17' => $kelas);
						$where_kelas18 = array('kelas18' => $kelas);
						$where_kelas19 = array('kelas19' => $kelas);
						$where_kelas20 = array('kelas20' => $kelas);
						$where_kelas21 = array('kelas21' => $kelas);
						$where_kelas22 = array('kelas22' => $kelas);
						$where_kelas23 = array('kelas23' => $kelas);
						$where_kelas24 = array('kelas24' => $kelas);
						$cek_kelas1 = $this->m_data->edit_data($where_kelas1,"ajar")->num_rows();
						$cek_kelas2 = $this->m_data->edit_data($where_kelas2,"ajar")->num_rows();
						$cek_kelas3 = $this->m_data->edit_data($where_kelas3,"ajar")->num_rows();
						$cek_kelas4 = $this->m_data->edit_data($where_kelas4,"ajar")->num_rows();
						$cek_kelas5 = $this->m_data->edit_data($where_kelas5,"ajar")->num_rows();
						$cek_kelas6 = $this->m_data->edit_data($where_kelas6,"ajar")->num_rows();
						$cek_kelas7 = $this->m_data->edit_data($where_kelas7,"ajar")->num_rows();
						$cek_kelas8 = $this->m_data->edit_data($where_kelas8,"ajar")->num_rows();
						$cek_kelas9 = $this->m_data->edit_data($where_kelas9,"ajar")->num_rows();
						$cek_kelas10 = $this->m_data->edit_data($where_kelas10,"ajar")->num_rows();
						$cek_kelas11 = $this->m_data->edit_data($where_kelas11,"ajar")->num_rows();
						$cek_kelas12 = $this->m_data->edit_data($where_kelas12,"ajar")->num_rows();
						$cek_kelas13 = $this->m_data->edit_data($where_kelas13,"ajar")->num_rows();
						$cek_kelas14 = $this->m_data->edit_data($where_kelas14,"ajar")->num_rows();
						$cek_kelas15 = $this->m_data->edit_data($where_kelas15,"ajar")->num_rows();
						$cek_kelas16 = $this->m_data->edit_data($where_kelas16,"ajar")->num_rows();
						$cek_kelas17 = $this->m_data->edit_data($where_kelas17,"ajar")->num_rows();
						$cek_kelas18 = $this->m_data->edit_data($where_kelas18,"ajar")->num_rows();
						$cek_kelas19 = $this->m_data->edit_data($where_kelas19,"ajar")->num_rows();
						$cek_kelas20 = $this->m_data->edit_data($where_kelas20,"ajar")->num_rows();
						$cek_kelas21 = $this->m_data->edit_data($where_kelas21,"ajar")->num_rows();
						$cek_kelas22 = $this->m_data->edit_data($where_kelas22,"ajar")->num_rows();
						$cek_kelas23 = $this->m_data->edit_data($where_kelas23,"ajar")->num_rows();
						$cek_kelas24 = $this->m_data->edit_data($where_kelas24,"ajar")->num_rows();
					if ($cek_kelas1>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}		 
					}
					elseif ($cek_kelas2>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas3>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas4>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas5>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas6>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas7>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas8>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas9>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas10>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas11>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas12>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas13>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas14>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas15>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas16>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas17>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas18>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas19>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas20>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas21>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas22>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas23>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas24>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ulangan",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					else{
						$this->session->set_flashdata('msg','Gagal upload ...!!'); 
					}
		     		}
				}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai');
	}
	}

	function tambah_nilai_remidi1($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/remidi1',$data1);
	}
	function proses_tambah_nilai_remidi1_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$remidi1 = $this->input->post('remidi1');
		$kkm = $this->input->post('kkm');

		if ($remidi1>=$kkm) {
			$nr=$kkm;
		}
		else{
			$nr=$remidi1;
		}
		$data = array(
			'ulangan1'=>$nr
			);
		$where = array(
					'nis'=>$nis,
					'id_guru' => $id_guru,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ulangan")->num_rows();
		     if($cek > 0){
				$table='nilai_ulangan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai');
	}
	function proses_tambah_nilai_remidi1(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kkm = $this->input->post('kkm');
		     $kelas = $this->input->post('kelas');
		     $cn=$rowData[0][0];
		     if ($rowData[0][1]>$kkm) {
		     	$nr=$kkm;
		     }
		     else{
		     	$nr=$rowData[0][1];
		     }
		     $data = array(
		     "ulangan1"=> $nr);
		     $where = array(
					'id_guru' => $id_guru,
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ulangan")->num_rows();
		     if($cek > 0){
				$table='nilai_ulangan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai');
	}
	}
	function tambah_nilai_uh2($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_nilai_uh2',$data1);
	}
	function proses_tambah_nilai_uh2_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$ulangan2 = $this->input->post('ulangan2');
		$cn=$nis;

		$data = array(
			'ulangan2'=>$ulangan2
			);
		$where = array(
					'nis'=>$cn,
					'id_guru' => $id_guru,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ulangan")->num_rows();
		     if($cek > 0){
				$table='nilai_ulangan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!');
				$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		}  
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai');
	}
	function proses_tambah_nilai_uh2(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     "ulangan2"=> $rowData[0][1]);
		     $where = array(
					'id_guru' => $id_guru,
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ulangan")->num_rows();
		     if($cek > 0){
				$table='nilai_ulangan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai');
	}
	}
	function tambah_nilai_remidi2($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/remidi2',$data1);
	}
	function proses_tambah_nilai_remidi2_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$remidi2 = $this->input->post('remidi2');
		$kkm = $this->input->post('kkm');

		if ($remidi1>=$kkm) {
			$nr=$kkm;
		}
		else{
			$nr=$remidi1;
		}

		$data = array(
			'ulangan2'=>$nr
			);
		$where = array(
					'nis'=>$nis,
					'id_guru' => $id_guru,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ulangan")->num_rows();
		     if($cek > 0){
				$table='nilai_ulangan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai');
	}
	function proses_tambah_nilai_remidi2(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kkm = $this->input->post('kkm');
		     $kelas = $this->input->post('kelas');
		     $cn=$rowData[0][0];
		     if ($rowData[0][1]>$kkm) {
		     	$nr=$kkm;
		     }
		     else{
		     	$nr=$rowData[0][1];
		     }
		     $data = array(
		     "ulangan2"=> $nr);
		     $where = array(
					'id_guru' => $id_guru,
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ulangan")->num_rows();
		     if($cek > 0){
				$table='nilai_ulangan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai');
	}
	}
	function tambah_nilai_uh3($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_nilai_uh3',$data1);
	}
		function proses_tambah_nilai_uh3(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     "ulangan3"=> $rowData[0][1]);
		     $where = array(
					'id_guru' => $id_guru,
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ulangan")->num_rows();
		     if($cek > 0){
				$table='nilai_ulangan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai');
	}
	}
	function proses_tambah_nilai_uh3_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$ulangan2 = $this->input->post('ulangan2');

		$data = array(
			'ulangan3'=>$ulangan3
			);
		$where = array(
					'nis'=>$nis,
					'id_guru' => $id_guru,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ulangan")->num_rows();
		     if($cek > 0){
				$table='nilai_ulangan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!');
				$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		}  
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai');
	}
	function tambah_nilai_remidi3($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/remidi3',$data1);
	}
	function proses_tambah_nilai_remidi3(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kkm = $this->input->post('kkm');
		     $kelas = $this->input->post('kelas');
		     $cn=$rowData[0][0];
		     if ($rowData[0][1]>$kkm) {
		     	$nr=$kkm;
		     }
		     else{
		     	$nr=$rowData[0][1];
		     }
		     $data = array(
		     "ulangan3"=> $nr);
		     $where = array(
					'id_guru' => $id_guru,
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ulangan")->num_rows();
		     if($cek > 0){
				$table='nilai_ulangan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai');
	}
	}
	function proses_tambah_nilai_remidi3_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$remidi3 = $this->input->post('remidi3');
		$kkm = $this->input->post('kkm');

		if ($remidi1>=$kkm) {
			$nr=$kkm;
		}
		else{
			$nr=$remidi1;
		}

		$data = array(
			'ulangan3'=>$nr
			);
		$where = array(
					'nis'=>$nis,
					'id_guru' => $id_guru,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ulangan")->num_rows();
		     if($cek > 0){
				$table='nilai_ulangan';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_ulangan=$this->m_data->nilai_ulangan($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ulangan as $nu){
						    		 $data_ulangan = array("nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $data_rerata = array("rerata"=> $nu->nilai_ulangan);
								     $data_ulangan_insert = array(
								     	'id_guru' => $nu->id_guru,
										'nis'=>$nu->nis,
										'kelas'=>$nu->kelas,
										'ta'=>$nu->ta,
										'matapelajaran' => $nu->matapelajaran,
								     	"nilai_ulangan"=> $nu->nilai_ulangan);
						    		 $where_ulangan = array(
											'id_guru' => $nu->id_guru,
											'nis'=>$nu->nis,
											'kelas'=>$nu->kelas,
											'ta'=>$nu->ta,
											'matapelajaran' => $nu->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
						    		 if ($cek_ulangan>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ulangan_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ulangan');
						    		 }
						    		} 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai');
	}
	function tambah_nilai_tugas1($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_nilai_tugas1',$data1);
	}
	function proses_tambah_nilai_tugas1(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     "nis"=> $cn,
		     "id_guru"=>$id_guru,
		     "matapelajaran"=>$matapelajaran,
		     "ta"=>$ta,
		     "kelas"=>$kelas,
		     "tugas1"=> $rowData[0][1]);
		     $where = array(
					'id_guru' => $id_guru,
					'id_matapelajaran' => $matapelajaran,
					"ta"=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"ajar")->num_rows();
		     if($cek > 0){
		     		$where_nis = array( 'id_guru' => $id_guru,
										'matapelajaran' => $matapelajaran,
										'ta'=>$ta,
		     							'nis'=>$cn);
		     		$cek_nis = $this->m_data->edit_data($where_nis,"nilai_tugas")->num_rows();
		     		if ($cek_nis>0) {
		     			$where_th = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'kelas'=>$kelas,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
		     			$data_th = array("tugas1"=> $rowData[0][1]);
		     			$this->m_data->proses_edit_data($where_th,$data_th,'nilai_tugas');
		     			$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
		     		}
		     		else{
		     			$where_kelas1 = array('kelas1' => $kelas);
						$where_kelas2 = array('kelas2' => $kelas);
						$where_kelas3 = array('kelas3' => $kelas);
						$where_kelas4 = array('kelas4' => $kelas);
						$where_kelas5 = array('kelas5' => $kelas);
						$where_kelas6 = array('kelas6' => $kelas);
						$where_kelas7 = array('kelas7' => $kelas);
						$where_kelas8 = array('kelas8' => $kelas);
						$where_kelas9 = array('kelas9' => $kelas);
						$where_kelas10 = array('kelas10' => $kelas);
						$where_kelas11 = array('kelas11' => $kelas);
						$where_kelas12 = array('kelas12' => $kelas);
						$where_kelas13 = array('kelas13' => $kelas);
						$where_kelas14 = array('kelas14' => $kelas);
						$where_kelas15 = array('kelas15' => $kelas);
						$where_kelas16 = array('kelas16' => $kelas);
						$where_kelas17 = array('kelas17' => $kelas);
						$where_kelas18 = array('kelas18' => $kelas);
						$where_kelas19 = array('kelas19' => $kelas);
						$where_kelas20 = array('kelas20' => $kelas);
						$where_kelas21 = array('kelas21' => $kelas);
						$where_kelas22 = array('kelas22' => $kelas);
						$where_kelas23 = array('kelas23' => $kelas);
						$where_kelas24 = array('kelas24' => $kelas);
						$cek_kelas1 = $this->m_data->edit_data($where_kelas1,"ajar")->num_rows();
						$cek_kelas2 = $this->m_data->edit_data($where_kelas2,"ajar")->num_rows();
						$cek_kelas3 = $this->m_data->edit_data($where_kelas3,"ajar")->num_rows();
						$cek_kelas4 = $this->m_data->edit_data($where_kelas4,"ajar")->num_rows();
						$cek_kelas5 = $this->m_data->edit_data($where_kelas5,"ajar")->num_rows();
						$cek_kelas6 = $this->m_data->edit_data($where_kelas6,"ajar")->num_rows();
						$cek_kelas7 = $this->m_data->edit_data($where_kelas7,"ajar")->num_rows();
						$cek_kelas8 = $this->m_data->edit_data($where_kelas8,"ajar")->num_rows();
						$cek_kelas9 = $this->m_data->edit_data($where_kelas9,"ajar")->num_rows();
						$cek_kelas10 = $this->m_data->edit_data($where_kelas10,"ajar")->num_rows();
						$cek_kelas11 = $this->m_data->edit_data($where_kelas11,"ajar")->num_rows();
						$cek_kelas12 = $this->m_data->edit_data($where_kelas12,"ajar")->num_rows();
						$cek_kelas13 = $this->m_data->edit_data($where_kelas13,"ajar")->num_rows();
						$cek_kelas14 = $this->m_data->edit_data($where_kelas14,"ajar")->num_rows();
						$cek_kelas15 = $this->m_data->edit_data($where_kelas15,"ajar")->num_rows();
						$cek_kelas16 = $this->m_data->edit_data($where_kelas16,"ajar")->num_rows();
						$cek_kelas17 = $this->m_data->edit_data($where_kelas17,"ajar")->num_rows();
						$cek_kelas18 = $this->m_data->edit_data($where_kelas18,"ajar")->num_rows();
						$cek_kelas19 = $this->m_data->edit_data($where_kelas19,"ajar")->num_rows();
						$cek_kelas20 = $this->m_data->edit_data($where_kelas20,"ajar")->num_rows();
						$cek_kelas21 = $this->m_data->edit_data($where_kelas21,"ajar")->num_rows();
						$cek_kelas22 = $this->m_data->edit_data($where_kelas22,"ajar")->num_rows();
						$cek_kelas23 = $this->m_data->edit_data($where_kelas23,"ajar")->num_rows();
						$cek_kelas24 = $this->m_data->edit_data($where_kelas24,"ajar")->num_rows();
						if ($cek_kelas1>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas2>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas3>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas4>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas5>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas6>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas7>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas8>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas9>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas10>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas11>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas12>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas13>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas14>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas15>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas16>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas17>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas18>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas19>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas20>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas21>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas22>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas23>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas24>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					else{
						$this->session->set_flashdata('msg','Gagal upload ...!!'); 
					}
		     		}
				}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai_tugas');
	}
	}
	function proses_tambah_nilai_tugas1_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$tugas1 = $this->input->post('tugas1');
		$cn=$nis;

		$data = array(
			'nis'=>$cn,
			'id_guru'=>$id_guru,
			'ta'=>$ta,
			'matapelajaran'=>$matapelajaran,
			'kelas'=>$kelas,
			'tugas1'=>$tugas1
			);
		$where = array(
					'id_guru' => $id_guru,
					'id_matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"ajar")->num_rows();
		     if($cek > 0){
		     		$where_nis = array( 'id_guru' => $id_guru,
										'matapelajaran' => $matapelajaran,
										'ta'=>$ta,
		     							'nis'=>$cn);
		     		$cek_nis = $this->m_data->edit_data($where_nis,"nilai_tugas")->num_rows();
		     		if ($cek_nis>0) {
		     			$this->session->set_flashdata('msg','Gagal upload ...!!');
		     		}
		     		else{
		     			$where_kelas1 = array('kelas1' => $kelas);
					$where_kelas2 = array('kelas2' => $kelas);
					$where_kelas3 = array('kelas3' => $kelas);
					$where_kelas4 = array('kelas4' => $kelas);
					$where_kelas5 = array('kelas5' => $kelas);
					$where_kelas6 = array('kelas6' => $kelas);
					$where_kelas7 = array('kelas7' => $kelas);
					$where_kelas8 = array('kelas8' => $kelas);
					$where_kelas9 = array('kelas9' => $kelas);
					$where_kelas10 = array('kelas10' => $kelas);
					$where_kelas11 = array('kelas11' => $kelas);
					$where_kelas12 = array('kelas12' => $kelas);
					$where_kelas13 = array('kelas13' => $kelas);
					$where_kelas14 = array('kelas14' => $kelas);
					$where_kelas15 = array('kelas15' => $kelas);
					$where_kelas16 = array('kelas16' => $kelas);
					$where_kelas17 = array('kelas17' => $kelas);
					$where_kelas18 = array('kelas18' => $kelas);
					$where_kelas19 = array('kelas19' => $kelas);
					$where_kelas20 = array('kelas20' => $kelas);
					$where_kelas21 = array('kelas21' => $kelas);
					$where_kelas22 = array('kelas22' => $kelas);
					$where_kelas23 = array('kelas23' => $kelas);
					$where_kelas24 = array('kelas24' => $kelas);
					$cek_kelas1 = $this->m_data->edit_data($where_kelas1,"ajar")->num_rows();
					$cek_kelas2 = $this->m_data->edit_data($where_kelas2,"ajar")->num_rows();
					$cek_kelas3 = $this->m_data->edit_data($where_kelas3,"ajar")->num_rows();
					$cek_kelas4 = $this->m_data->edit_data($where_kelas4,"ajar")->num_rows();
					$cek_kelas5 = $this->m_data->edit_data($where_kelas5,"ajar")->num_rows();
					$cek_kelas6 = $this->m_data->edit_data($where_kelas6,"ajar")->num_rows();
					$cek_kelas7 = $this->m_data->edit_data($where_kelas7,"ajar")->num_rows();
					$cek_kelas8 = $this->m_data->edit_data($where_kelas8,"ajar")->num_rows();
					$cek_kelas9 = $this->m_data->edit_data($where_kelas9,"ajar")->num_rows();
					$cek_kelas10 = $this->m_data->edit_data($where_kelas10,"ajar")->num_rows();
					$cek_kelas11 = $this->m_data->edit_data($where_kelas11,"ajar")->num_rows();
					$cek_kelas12 = $this->m_data->edit_data($where_kelas12,"ajar")->num_rows();
					$cek_kelas13 = $this->m_data->edit_data($where_kelas13,"ajar")->num_rows();
					$cek_kelas14 = $this->m_data->edit_data($where_kelas14,"ajar")->num_rows();
					$cek_kelas15 = $this->m_data->edit_data($where_kelas15,"ajar")->num_rows();
					$cek_kelas16 = $this->m_data->edit_data($where_kelas16,"ajar")->num_rows();
					$cek_kelas17 = $this->m_data->edit_data($where_kelas17,"ajar")->num_rows();
					$cek_kelas18 = $this->m_data->edit_data($where_kelas18,"ajar")->num_rows();
					$cek_kelas19 = $this->m_data->edit_data($where_kelas19,"ajar")->num_rows();
					$cek_kelas20 = $this->m_data->edit_data($where_kelas20,"ajar")->num_rows();
					$cek_kelas21 = $this->m_data->edit_data($where_kelas21,"ajar")->num_rows();
					$cek_kelas22 = $this->m_data->edit_data($where_kelas22,"ajar")->num_rows();
					$cek_kelas23 = $this->m_data->edit_data($where_kelas23,"ajar")->num_rows();
					$cek_kelas24 = $this->m_data->edit_data($where_kelas24,"ajar")->num_rows();
					if ($cek_kelas1>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas2>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas3>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas4>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas5>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas6>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas7>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas8>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas9>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas10>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas11>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas12>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas13>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas14>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas15>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas16>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas17>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas18>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas19>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas20>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas21>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas22>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas23>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas24>0) {
						$where_siswa=array('kelas'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_tugas",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					else{
						$this->session->set_flashdata('msg','Gagal upload ...!!'); 
					}
		     		}
				}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_tugas');
	}
	function tambah_nilai_tugas2($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_nilai_tugas2',$data1);
	}
	function proses_tambah_nilai_tugas2(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     "tugas2"=> $rowData[0][1]);
		     $where = array(
					'id_guru' => $id_guru,
					'nis'=>$cn,
					"ta"=>$ta,
					'kelas'=>$kelas,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_tugas")->num_rows();
		     if($cek > 0){
				$table='nilai_tugas';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai_tugas');
	}
	}
	function proses_tambah_nilai_tugas2_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$tugas2 = $this->input->post('tugas2');

		$data = array(
			'tugas2'=>$tugas2
			);
		$where = array(
					'nis'=>$nis,
					'id_guru' => $id_guru,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_tugas")->num_rows();
		     if($cek > 0){
				$table='nilai_tugas';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_tugas=$this->m_data->nilai_tugas($nis,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_tugas');
	}
	function tambah_nilai_tugas3($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_nilai_tugas3',$data1);
	}
	function proses_tambah_nilai_tugas3(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     "tugas3"=> $rowData[0][1]);
		     $where = array(
					'id_guru' => $id_guru,
					'nis'=>$cn,
					"ta"=>$ta,
					'kelas'=>$kelas,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_tugas")->num_rows();
		     if($cek > 0){
				$table='nilai_tugas';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_tugas=$this->m_data->nilai_tugas($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai_tugas');
	}
	}
	function proses_tambah_nilai_tugas3_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$tugas3 = $this->input->post('tugas3');

		$data = array(
			'tugas3'=>$tugas3
			);
		$where = array(
					'nis'=>$nis,
					'id_guru' => $id_guru,
					'ta'=>$ta,
					'kelas'=>$kelas,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_tugas")->num_rows();
		     if($cek > 0){
				$table='nilai_tugas';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_tugas=$this->m_data->nilai_tugas($nis,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_tugas as $nt){
						    		 $data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
						    		 $data_rerata = array("rerata"=> $nt->nilai_tugas);
								     $data_tugas_insert = array(
								     	'id_guru' => $nt->id_guru,
										'nis'=>$nt->nis,
										'kelas'=>$nt->kelas,
										'ta'=>$nt->ta,
										'matapelajaran' => $nt->matapelajaran,
								     	"nilai_tugas"=> $nt->nilai_tugas);
						    		 $where_tugas = array(
											'id_guru' => $nt->id_guru,
											'nis'=>$nt->nis,
											'kelas'=>$nt->kelas,
											'ta'=>$nt->ta,
											'matapelajaran' => $nt->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
						    		 if ($cek_tugas>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_tugas_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_tugas');
						    		 }
						    		}
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_tugas');
	}
	function tambah_nilai_uts($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_nilai_uts',$data1);
	}
	function proses_tambah_nilai_uts(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     "nis"=> $cn,
		     "id_guru"=>$id_guru,
		     "matapelajaran"=>$matapelajaran,
		     "ta"=>$ta,
		     "kelas"=>$kelas,
		     "uts"=> $rowData[0][1]);
		     $where = array(
					'id_guru' => $id_guru,
					'id_matapelajaran' => $matapelajaran,
					"ta"=>$ta,
					);
		     $cek = $this->m_data->edit_data($where,"ajar")->num_rows();
		     if($cek > 0){
		     		$where_nis = array( 'id_guru' => $id_guru,
										'matapelajaran' => $matapelajaran,
										'ta'=>$ta,
		     							'nis'=>$cn);
		     		$cek_nis = $this->m_data->edit_data($where_nis,"nilai_ujian")->num_rows();
		     		if($cek_nis > 0){
		     			$where_ujian = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'kelas'=>$kelas,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
		     			$data_ujian = array("uts"=> $rowData[0][1]);
		     			$this->m_data->proses_edit_data($where_ujian,$data_ujian,'nilai_ujian');
		     			$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->uts);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}
		     		}
		     		else{
		     			$where_kelas1 = array('kelas1' => $kelas);
						$where_kelas2 = array('kelas2' => $kelas);
						$where_kelas3 = array('kelas3' => $kelas);
						$where_kelas4 = array('kelas4' => $kelas);
						$where_kelas5 = array('kelas5' => $kelas);
						$where_kelas6 = array('kelas6' => $kelas);
						$where_kelas7 = array('kelas7' => $kelas);
						$where_kelas8 = array('kelas8' => $kelas);
						$where_kelas9 = array('kelas9' => $kelas);
						$where_kelas10 = array('kelas10' => $kelas);
						$where_kelas11 = array('kelas11' => $kelas);
						$where_kelas12 = array('kelas12' => $kelas);
						$where_kelas13 = array('kelas13' => $kelas);
						$where_kelas14 = array('kelas14' => $kelas);
						$where_kelas15 = array('kelas15' => $kelas);
						$where_kelas16 = array('kelas16' => $kelas);
						$where_kelas17 = array('kelas17' => $kelas);
						$where_kelas18 = array('kelas18' => $kelas);
						$where_kelas19 = array('kelas19' => $kelas);
						$where_kelas20 = array('kelas20' => $kelas);
						$where_kelas21 = array('kelas21' => $kelas);
						$where_kelas22 = array('kelas22' => $kelas);
						$where_kelas23 = array('kelas23' => $kelas);
						$where_kelas24 = array('kelas24' => $kelas);
						$cek_kelas1 = $this->m_data->edit_data($where_kelas1,"ajar")->num_rows();
						$cek_kelas2 = $this->m_data->edit_data($where_kelas2,"ajar")->num_rows();
						$cek_kelas3 = $this->m_data->edit_data($where_kelas3,"ajar")->num_rows();
						$cek_kelas4 = $this->m_data->edit_data($where_kelas4,"ajar")->num_rows();
						$cek_kelas5 = $this->m_data->edit_data($where_kelas5,"ajar")->num_rows();
						$cek_kelas6 = $this->m_data->edit_data($where_kelas6,"ajar")->num_rows();
						$cek_kelas7 = $this->m_data->edit_data($where_kelas7,"ajar")->num_rows();
						$cek_kelas8 = $this->m_data->edit_data($where_kelas8,"ajar")->num_rows();
						$cek_kelas9 = $this->m_data->edit_data($where_kelas9,"ajar")->num_rows();
						$cek_kelas10 = $this->m_data->edit_data($where_kelas10,"ajar")->num_rows();
						$cek_kelas11 = $this->m_data->edit_data($where_kelas11,"ajar")->num_rows();
						$cek_kelas12 = $this->m_data->edit_data($where_kelas12,"ajar")->num_rows();
						$cek_kelas13 = $this->m_data->edit_data($where_kelas13,"ajar")->num_rows();
						$cek_kelas14 = $this->m_data->edit_data($where_kelas14,"ajar")->num_rows();
						$cek_kelas15 = $this->m_data->edit_data($where_kelas15,"ajar")->num_rows();
						$cek_kelas16 = $this->m_data->edit_data($where_kelas16,"ajar")->num_rows();
						$cek_kelas17 = $this->m_data->edit_data($where_kelas17,"ajar")->num_rows();
						$cek_kelas18 = $this->m_data->edit_data($where_kelas18,"ajar")->num_rows();
						$cek_kelas19 = $this->m_data->edit_data($where_kelas19,"ajar")->num_rows();
						$cek_kelas20 = $this->m_data->edit_data($where_kelas20,"ajar")->num_rows();
						$cek_kelas21 = $this->m_data->edit_data($where_kelas21,"ajar")->num_rows();
						$cek_kelas22 = $this->m_data->edit_data($where_kelas22,"ajar")->num_rows();
						$cek_kelas23 = $this->m_data->edit_data($where_kelas23,"ajar")->num_rows();
						$cek_kelas24 = $this->m_data->edit_data($where_kelas24,"ajar")->num_rows();
					if ($cek_kelas1>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas2>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas3>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas4>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas5>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas6>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas7>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas8>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas9>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas10>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas11>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas12>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas13>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas14>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas15>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas16>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas17>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas18>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas19>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas20>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas21>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas22>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas23>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas24>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					else{
						$this->session->set_flashdata('msg','Gagal upload ...!!'); 
					}
		     		}
				}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai_ujian');
	}
	}
	function proses_tambah_nilai_uts_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('id_ta');
		$kelas = $this->input->post('kelas');
		$uts = $this->input->post('uts');
		$cn=$nis;

		$data = array(
			'nis'=>$cn,
			'id_guru'=>$id_guru,
			'matapelajaran'=>$matapelajaran,
			'ta'=>$ta,
			'kelas'=>$kelas,
			'uts'=>$uts
			);
		$where = array(
					'id_guru' => $id_guru,
					'id_matapelajaran' => $matapelajaran,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"ajar")->num_rows();
		     if($cek > 0){
		     		$where_nis = array('nis'=>$cn);
		     		$cek_nis = $this->m_data->edit_data($where_nis,"nilai_ujian")->num_rows();
		     		if ($cek_nis > 0) {
		     			$this->session->set_flashdata('msg','Gagal upload ...!!');
		     		}
		     		else{
		     			$where_kelas1 = array('kelas1' => $kelas);
					$where_kelas2 = array('kelas2' => $kelas);
					$where_kelas3 = array('kelas3' => $kelas);
					$where_kelas4 = array('kelas4' => $kelas);
					$where_kelas5 = array('kelas5' => $kelas);
					$where_kelas6 = array('kelas6' => $kelas);
					$where_kelas7 = array('kelas7' => $kelas);
					$where_kelas8 = array('kelas8' => $kelas);
					$where_kelas9 = array('kelas9' => $kelas);
					$where_kelas10 = array('kelas10' => $kelas);
					$where_kelas11 = array('kelas11' => $kelas);
					$where_kelas12 = array('kelas12' => $kelas);
					$where_kelas13 = array('kelas13' => $kelas);
					$where_kelas14 = array('kelas14' => $kelas);
					$where_kelas15 = array('kelas15' => $kelas);
					$where_kelas16 = array('kelas16' => $kelas);
					$where_kelas17 = array('kelas17' => $kelas);
					$where_kelas18 = array('kelas18' => $kelas);
					$where_kelas19 = array('kelas19' => $kelas);
					$where_kelas20 = array('kelas20' => $kelas);
					$where_kelas21 = array('kelas21' => $kelas);
					$where_kelas22 = array('kelas22' => $kelas);
					$where_kelas23 = array('kelas23' => $kelas);
					$where_kelas24 = array('kelas24' => $kelas);
					$cek_kelas1 = $this->m_data->edit_data($where_kelas1,"ajar")->num_rows();
					$cek_kelas2 = $this->m_data->edit_data($where_kelas2,"ajar")->num_rows();
					$cek_kelas3 = $this->m_data->edit_data($where_kelas3,"ajar")->num_rows();
					$cek_kelas4 = $this->m_data->edit_data($where_kelas4,"ajar")->num_rows();
					$cek_kelas5 = $this->m_data->edit_data($where_kelas5,"ajar")->num_rows();
					$cek_kelas6 = $this->m_data->edit_data($where_kelas6,"ajar")->num_rows();
					$cek_kelas7 = $this->m_data->edit_data($where_kelas7,"ajar")->num_rows();
					$cek_kelas8 = $this->m_data->edit_data($where_kelas8,"ajar")->num_rows();
					$cek_kelas9 = $this->m_data->edit_data($where_kelas9,"ajar")->num_rows();
					$cek_kelas10 = $this->m_data->edit_data($where_kelas10,"ajar")->num_rows();
					$cek_kelas11 = $this->m_data->edit_data($where_kelas11,"ajar")->num_rows();
					$cek_kelas12 = $this->m_data->edit_data($where_kelas12,"ajar")->num_rows();
					$cek_kelas13 = $this->m_data->edit_data($where_kelas13,"ajar")->num_rows();
					$cek_kelas14 = $this->m_data->edit_data($where_kelas14,"ajar")->num_rows();
					$cek_kelas15 = $this->m_data->edit_data($where_kelas15,"ajar")->num_rows();
					$cek_kelas16 = $this->m_data->edit_data($where_kelas16,"ajar")->num_rows();
					$cek_kelas17 = $this->m_data->edit_data($where_kelas17,"ajar")->num_rows();
					$cek_kelas18 = $this->m_data->edit_data($where_kelas18,"ajar")->num_rows();
					$cek_kelas19 = $this->m_data->edit_data($where_kelas19,"ajar")->num_rows();
					$cek_kelas20 = $this->m_data->edit_data($where_kelas20,"ajar")->num_rows();
					$cek_kelas21 = $this->m_data->edit_data($where_kelas21,"ajar")->num_rows();
					$cek_kelas22 = $this->m_data->edit_data($where_kelas22,"ajar")->num_rows();
					$cek_kelas23 = $this->m_data->edit_data($where_kelas23,"ajar")->num_rows();
					$cek_kelas24 = $this->m_data->edit_data($where_kelas24,"ajar")->num_rows();
					if ($cek_kelas1>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas2>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas3>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas4>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas5>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas6>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas7>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas8>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas9>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas10>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas11>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas12>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas13>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas14>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas15>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas16>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas17>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas18>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas19>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas20>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas21>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas22>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas23>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					elseif ($cek_kelas24>0) {
						$where_siswa=array('nis'=>$cn);
						$cek_siswa= $this->m_data->edit_data($where_siswa,"siswa")->num_rows();
							if ($cek_siswa>0) {
								$this->db->insert("nilai_ujian",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
								$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uts"=> $uts);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uts"=> $uts);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

							}
							else{
								$this->session->set_flashdata('msg','Gagal upload ...!!');
							}
							 
					}
					else{
						$this->session->set_flashdata('msg','Gagal upload ...!!'); 
					}
				}
   		} 
        redirect('guru/daftar_nilai_ujian');
	}
	function tambah_nilai_uas($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_nilai_uas',$data1);
	}
	function proses_tambah_nilai_uas(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     'uas'=> $rowData[0][1]);
		     $where = array(
					'id_guru' => $id_guru,
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ujian")->num_rows();
		     if($cek > 0){
				$table='nilai_ujian';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("uas"=> $rowData[0][1]);
						    		 $data_rerata = array("rerata"=> $nujian->uas);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	"uas"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai_ujian');
	}
	}
	function proses_tambah_nilai_uas_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$uas = $this->input->post('uas');
		$cn=$nis;

		$data = array(
			'uas'=>$uas
			);
		$where = array(
					'nis'=>$cn,
					'id_guru' => $id_guru,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ujian")->num_rows();
		     if($cek > 0){
				$table='nilai_ujian';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array('uas'=>$uas);
						    		 $data_rerata = array("rerata"=> $nujian->nilai_ujian);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' => $nujian->matapelajaran,
								     	'uas'=>$uas);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $where_rerata = array(
											'id_guru' => $id_guru,
											'nis'=>$cn,
											'ta'=>$ta,
											'matapelajaran' => $matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
										$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 	$this->m_data->proses_edit_data($where_rerata,$data_rerata,'nilai_ujian');
						    		 }
						    		}

					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_ujian');
	}
	function tambah_nilai_praktek($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_nilai_praktek',$data1);
	}
	function proses_tambah_nilai_praktek(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     'praktek'=> $rowData[0][1]);
		     $where = array(
					'id_guru' => $id_guru,
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ujian")->num_rows();
		     if($cek > 0){
				$table='nilai_ujian';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
						    		 foreach($query_ujian as $nujian){
						    		 $data_ujian = array("nilai_praktek"=> $rowData[0][1]);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' =>   $nujian->matapelajaran,
								     	"nilai_praktek"=> $rowData[0][1]);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 }
						    		}
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai_ujian');
	}
	}
	function proses_tambah_nilai_praktek_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$praktek = $this->input->post('praktek');
		$cn=$nis;

		$data = array(
			'praktek'=>$praktek
			);
		$where = array(
					'nis'=>$cn,
					'id_guru' => $id_guru,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_ujian")->num_rows();
		     if($cek > 0){
				$table='nilai_ujian';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
				$query_ujian=$this->m_data->nilai_ujian($cn,$matapelajaran,$ta,$id_guru)->result();
								foreach($query_ujian as $nujian){
						    		 $data_ujian = array("nilai_praktek"=> $praktek);
								     $data_ujian_insert = array(
								     	'id_guru' => $nujian->id_guru,
										'nis'=>$nujian->nis,
										'kelas'=>$nujian->kelas,
										'ta'=>$nujian->ta,
										'matapelajaran' =>   $nujian->matapelajaran,
								     	"nilai_praktek"=> $praktek);
						    		 $where_ujian = array(
											'id_guru' => $nujian->id_guru,
											'nis'=>$nujian->nis,
											'kelas'=>$nujian->kelas,
											'ta'=>$nujian->ta,
											'matapelajaran' => $nujian->matapelajaran
											);
						    		 $cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
						    		 if ($cek_ujian>0) {
										$table='nilai_akhir';
										$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
						    		 }
						    		 else{
						    		 	$this->db->insert("nilai_akhir",$data_ujian_insert);
						    		 }
						    		}

					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_ujian');
	}
	function tambah_komentar_k13($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_komentar_k13',$data1);
	}
	function proses_tambah_komentar_k13(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     'komentar_pengetahuan'=> $rowData[0][1],
		     'komentar_keterampilan'=> $rowData[0][2]);
		     $where = array(
					'id_guru' => $id_guru,
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_komentar_k13');
	}
	}
	function proses_tambah_komentar_form_k13(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$komentar_pengetahuan = $this->input->post('komentar_pengetahuan');
		$komentar_keterampilan = $this->input->post('komentar_keterampilan');
		$cn=$nis;

		$data = array(
			'komentar_pengetahuan'=>$komentar_pengetahuan,
			'komentar_keterampilan'=>$komentar_keterampilan
			);
		$where = array(
					'nis'=>$cn,
					'id_guru' => $id_guru,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_komentar');
	}
	function hapus_komentar_k13($id_nilai_akhir){
		$komentar='';

		$data=array(
			'komentar_pengetahuan'=>$komentar,
			'komentar_keterampilan'=>$komentar
			);

		$where=array('id_nilai_akhir'=>$id_nilai_akhir);
		$table='nilai_akhir';
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('guru/daftar_komentar_k13');
	}
	function tambah_komentar($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_komentar',$data1);
	}
	function proses_tambah_komentar(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $matapelajaran = $this->input->post('matapelajaran');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     'sikap'=> $rowData[0][1],
		     'komentar'=> $rowData[0][2]);
		     $where = array(
					'id_guru' => $id_guru,
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_komentar');
	}
	}
	function proses_tambah_komentar_form(){
		$nis = $this->input->post('nis');
		$id_guru = $this->input->post('id_guru');
		$matapelajaran = $this->input->post('matapelajaran');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$sikap = $this->input->post('sikap');
		$komentar = $this->input->post('komentar');
		$cn=$nis;

		$data = array(
			'sikap'=>$sikap,
			'komentar'=>$komentar
			);
		$where = array(
					'nis'=>$cn,
					'id_guru' => $id_guru,
					'kelas'=>$kelas,
					'ta'=>$ta,
					'matapelajaran' => $matapelajaran
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_komentar');
	}
	function edit_komentar_k13($id_nilai_akhir){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['nilai_akhir']=$this->m_data->edit_nilai($id_nilai_akhir,'nilai_akhir','id_nilai_akhir')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/edit_komentar_k13',$data1);
	}
	function proses_edit_komentar_k13(){
		$id = $this->input->post('id_nilai_akhir');
		$komentar_pengetahuan = $this->input->post('komentar_pengetahuan');
		$komentar_keterampilan = $this->input->post('komentar_keterampilan');
		$cn=$nis;

		$data = array(
			'komentar_pengetahuan'=>$komentar_pengetahuan,
			'komentar_keterampilan'=>$komentar_keterampilan
			);
		$where = array(
					'id_nilai_akhir'=>$id
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_komentar_k13');
	}
	function tambah_nilai_sikap_spiritual($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_sikap_spiritual',$data1);
	}
	function proses_tambah_nilai_sikap_spiritual(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     'sikap_spiritual'=> $rowData[0][1],
		     'deskripsi_spiritual'=> $rowData[0][2]);
		     $where = array(
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai_sikap_spiritual');
	}
	}
	function proses_tambah_niali_sikap_spiritual_form(){
		$nis = $this->input->post('nis');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$sikap = $this->input->post('sikap');
		$deskripsi = $this->input->post('deskripsi');
		$cn=$nis;

		$data = array(
		     'sikap_spiritual'=> $sikap,
		     'deskripsi_spiritual'=> $deskripsi
		     );
		$where = array(
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_sikap_spiritual');
	}
	function tambah_nilai_sikap_sosial($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_sikap_sosial',$data1);
	}
	function proses_tambah_nilai_sikap_sosial(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     'sikap_sosial'=> $rowData[0][1],
		     'deskripsi_sosial'=> $rowData[0][2]);
		     $where = array(
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai_sikap_sosial');
	}
	}
	function proses_tambah_niali_sikap_sosial_form(){
		$nis = $this->input->post('nis');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$sikap = $this->input->post('sikap');
		$deskripsi = $this->input->post('deskripsi');
		$cn=$nis;

		$data = array(
		     'sikap_sosial'=> $sikap,
		     'deskripsi_sosial'=> $deskripsi
		     );
		$where = array(
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_sikap_sosial');
	}
	function tambah_nilai_akhlaq_kepribadian($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_akhlaq_kepribadian',$data1);
	}
	function proses_tambah_nilai_akhlaq(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     'nilai_kelakuan'=> $rowData[0][1],
		     'komentar_kelakuan'=> $rowData[0][2],
		     'nilai_kerajinan'=> $rowData[0][3],
		     'komentar_kerajinan'=> $rowData[0][4],
		     'nilai_kerapihan'=> $rowData[0][5],
		     'komentar_kerapihan'=> $rowData[0][6],
		     'nilai_kebersihan'=> $rowData[0][7],
		     'komentar_kebersihan'=> $rowData[0][8],);
		     $where = array(
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai_akhlaq');
	}
	}
	function proses_tambah_niali_akhlaq_form(){
		$nis = $this->input->post('nis');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$nilai_kelakuan = $this->input->post('nilai_kelakuan');
		$komentar_kelakuan = $this->input->post('komentar_kelakuan');
		$nilai_kerajinan = $this->input->post('nilai_kerajinan');
		$komentar_kerajinan = $this->input->post('komentar_kerajinan');
		$nilai_kerapihan = $this->input->post('nilai_kerapihan');
		$komentar_kerapihan = $this->input->post('komentar_kerapihan');
		$nilai_kebersihan = $this->input->post('nilai_kebersihan');
		$komentar_kebersihan = $this->input->post('komentar_kebersihan');
		$cn=$nis;

		$data = array(
		     'nilai_kelakuan'=> $nilai_kelakuan,
		     'komentar_kelakuan'=> $komentar_kelakuan,
		     'nilai_kerajinan'=> $nilai_kerajinan,
		     'komentar_kerajinan'=> $komentar_kerajinan,
		     'nilai_kerapihan'=> $nilai_kerapihan,
		     'komentar_kerapihan'=> $komentar_kerapihan,
		     'nilai_kebersihan'=> $nilai_kebersihan,
		     'komentar_kebersihan'=> $komentar_kebersihan);
		$where = array(
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_akhlaq');
	}
		function hapus_nilai_akhlaq(){
		$nis = $this->input->post('nis');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$isi='';

		$data = array(
		     'nilai_kelakuan'=> $isi,
		     'komentar_kelakuan'=> $isi,
		     'nilai_kerajinan'=> $isi,
		     'komentar_kerajinan'=> $isi,
		     'nilai_kerapihan'=> $isi,
		     'komentar_kerapihan'=> $isi,
		     'nilai_kebersihan'=> $isi,
		     'komentar_kebersihan'=> $isi);
		$where = array(
					'nis'=>$nis,
					'kelas'=>$kelas,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_akhlaq');
	}
	function hapus_nilai_sikap_sosial(){
		$nis = $this->input->post('nis');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$isi='';

		$data = array(
		     'sikap_sosial'=> $isi,
		     'deskripsi_sosial'=> $isi);
		$where = array(
					'nis'=>$nis,
					'kelas'=>$kelas,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_sikap_sosial');
	}
	function hapus_nilai_sikap_spiritual(){
		$nis = $this->input->post('nis');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$isi='';

		$data = array(
		     'sikap_spiritual'=> $isi,
		     'deskripsi_spiritual'=> $isi);
		$where = array(
					'nis'=>$nis,
					'kelas'=>$kelas,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_sikap_spiritual');
	}
	function tambah_kehadiran_siswa($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_kehadiran_siswa',$data1);
	}
	function proses_tambah_kehadiran_siswa(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $ta = $this->input->post('ta');
		     $kelas = $this->input->post('kelas');
		     $data = array(
		     's'=> $rowData[0][1],
		     'i'=> $rowData[0][2],
		     'a'=> $rowData[0][3]
		     );
		     $where = array(
					'nis'=>$cn,
					'kelas'=>$kelas,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
	 		}
   		} 
        redirect('guru/daftar_nilai_akhlaq');
	}
	}
	function proses_tambah_kehadiran_siswa_form(){
		$nis = $this->input->post('nis');
		$ta = $this->input->post('ta');
		$kelas = $this->input->post('kelas');
		$s = $this->input->post('sakit');
		$i = $this->input->post('izin');
		$a = $this->input->post('tanpa_keterangan');

		$data = array(
		     's'=> $s,
		     'i'=> $i,
		     'a'=> $a
		     );
		$where = array(
					'nis'=>$nis,
					'kelas'=>$kelas,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"nilai_akhir")->num_rows();
		     if($cek > 0){
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!'); 
					}
	 		else{
	 		$this->session->set_flashdata('msg','Gagal upload ...!!'); 
   		} 
        redirect('guru/daftar_nilai_akhlaq');
	}
	function setting($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/setting',$data);
	}
	function setting_notif(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['alert'] = $this->m_data->tampil_data('alert')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/setting_notif',$data1,$data);
	}
	function ganti_password(){
		$id_guru=$this->input->post('id_guru');
		$password_lama=$this->input->post('password_lama');
		$password_lama_input=$this->input->post('password3');
		$password1=$this->input->post('password1');
		$password2=$this->input->post('password2');

		if($password_lama==$password_lama_input){
			if ($password1==$password2) {
				$data=array(
				'password_guru'=>$password1
				);
				$notif="Selamat Password Berhasil di ganti";
				$data_notif=array(
					'ganti_password'=>$notif
					);
				$where=array('id_guru'=>$id_guru);
				$where1=array('id'=>'1');
				$table='guru';
			    $this->m_data->proses_edit_data($where,$data,$table);
			    $this->m_data->proses_edit_data($where1,$data_notif,"alert");
			    redirect('guru/setting_notif');
			}
			else{
				$notif="Password baru dan ulangi password baru tidak cocok";
				$data_notif=array(
					'ganti_password'=>$notif
					);
				$where1=array('id'=>'1');
				$this->m_data->proses_edit_data($where1,$data_notif,"alert");
				 redirect('guru/setting_notif');
			}
		}
		else{
			$notif="password lama salah";
			$data_notif=array(
				'ganti_password'=>$notif
				);
			$where1=array('id'=>'1');
			$this->m_data->proses_edit_data($where1,$data_notif,"alert");
			 redirect('guru/setting_notif');
		}
	}
	function daftar_guru(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$where_cari_ta=array('id_guru'=>$id_guru);
    	$data['cari_ta']=$this->m_data->edit_data($where_cari_ta,'ajar')->result();
		foreach($data['cari_ta'] as $c)
        $cari_ta=$c->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data1['guru']=$this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_guru',$data1);	
	}
	function wali_kelas(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$where_cari_ta=array('id_guru'=>$id_guru);
    	$data['cari_ta']=$this->m_data->edit_data($where_cari_ta,'ajar')->result();
		foreach($data['cari_ta'] as $c)
        $cari_ta=$c->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data1['guru']=$this->m_data->daftar_wali_kelas()->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_wali_kelas',$data1);	
	}
	function catatan_wali_kelas($id_guru){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data1['guru']=$this->m_data->guru_wali_kelas($id_guru)->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/tambah_catatan_wali_kelas',$data1);
	}
	function proses_tambah_catatan_wali_kelas(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_guru = $this->input->post('id_guru');
		     $wali_kelas = $this->input->post('wali_kelas');
		     $ta = $this->input->post('ta');
		     $data = array(
			     "catatan"=> $rowData[0][1],
			     'wali_kelas' => $id_guru,
				 'nis'=>$cn,
				 'kelas'=>$wali_kelas,
				 'ta'=>$ta
			     );
		     $where = array(
			     'wali_kelas' => $id_guru,
				 'nis'=>$cn,
				 'kelas'=>$wali_kelas,
				 'ta'=>$ta );
		     $cek = $this->m_data->edit_data($where,"catatan_wali_kelas")->num_rows();
		     if($cek > 0){
				$table='catatan_wali_kelas';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!');
				}
			 else{
					$this->m_data->tambah_data($data,'catatan_wali_kelas');
				}
   		} 
   		redirect('guru/daftar_catatan_wali_kelas');
	}
	}
	function proses_tambah_catatan_wali_kelas_form(){
       		 $cn=$this->input->post('nis');
		     $id_guru = $this->input->post('id_guru');
		     $wali_kelas = $this->input->post('wali_kelas');
		     $ta = $this->input->post('ta');
		     $catatan = $this->input->post('catatan');
		     $data = array(
			     "catatan"=> $catatan,
			     'wali_kelas' => $id_guru,
				 'nis'=>$cn,
				 'kelas'=>$wali_kelas,
				 'ta'=>$ta
			     );
		     $where = array(
			     'wali_kelas' => $id_guru,
				 'nis'=>$cn,
				 'kelas'=>$wali_kelas,
				 'ta'=>$ta );
		     $cek = $this->m_data->edit_data($where,"catatan_wali_kelas")->num_rows();
		     if($cek > 0){
				$table='catatan_wali_kelas';
				$this->m_data->proses_edit_data($where,$data,$table);
				$this->session->set_flashdata('msg','Berhasil upload ...!!');
				}
			 else{
					$this->m_data->tambah_data($data,'catatan_wali_kelas');
				}
   		redirect('guru/daftar_catatan_wali_kelas');
	}
	function daftar_catatan_wali_kelas(){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$where_cari_ta=array('id_guru'=>$id_guru);
    	$data['cari_ta']=$this->m_data->edit_data($where_cari_ta,'ajar')->result();
		foreach($data['cari_ta'] as $c)
        $cari_ta=$c->ta;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$data1['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data1['catatan_wali_kelas']=$this->m_data->daftar_catatan_wali_kelas($id_guru,$cari_ta)->result();
		$data1['ajar'] = $this->m_data->mapel_ajar($id_guru);
		$data1['guru']=$this->m_data->guru_wali_kelas($id_guru)->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/list_guru/daftar_catatan_wali_kelas',$data1);	
	}
	function edit_catatan_wali_kelas($id_catatan_wali_kelas){
		$this->load->model('m_data');
		$nk=$this->session->userdata("nomor_induk");
		$where=array('nomor_induk'=>$nk);
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		foreach($data['guru'] as $g)
        $id_guru=$g->id_guru;
    	$data['bk']=$this->m_data->guru_bk($id_guru)->result();
		$data1['catatan_wali_kelas']=$this->m_data->edit_nilai($id_catatan_wali_kelas,'catatan_wali_kelas','id_catatan_wali_kelas')->result();
		$data1['guru']=$this->m_data->guru_wali_kelas($id_guru)->result();
		$this->load->view('main/v_guru_header',$data);
		$this->load->view('main/guru/form_guru/edit_catatan_wali_kelas',$data1);
	}
	function proses_edit_catatan_wali_kelas(){
		$id=$this->input->post('id_catatan_wali_kelas');
		$catatan=$this->input->post('catatan');

		$data=array('catatan'=>$catatan);
		$where=array('id_catatan_wali_kelas'=>$id);
		$table='catatan_wali_kelas';
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('guru/daftar_catatan_wali_kelas');
	}
	function hapus_catatan_wali_kelas($id_catatan_wali_kelas){
		$where = array('id_catatan_wali_kelas' => $id_catatan_wali_kelas);
		$table='catatan_wali_kelas';
		$this->m_data->hapus_data($where,$table);
		redirect('guru/daftar_catatan_wali_kelas');
	}
}