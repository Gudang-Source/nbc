<?php 

class Login extends CI_Controller{

	function __construct(){
		parent::__construct();		
		$this->load->model('m_login');
		$this->load->model('m_data');

	}

	function index(){
		$this->load->view('login/view_login');
	}
	function signup_notif(){
		$this->load->model('m_data');
		$data['alert'] = $this->m_data->tampil_data('alert')->result();
		$this->load->view('login/v_login_notif',$data);
	}
	function login_master(){
		$username = $this->input->post('username');
		$where_guru = array('nomor_induk' => $username);
		$where_akademik = array('username' => $username);
		$cekguru = $this->m_login->cek_login("guru",$where_guru)->num_rows();
		$cekakademik = $this->m_login->cek_login("biro_akademik",$where_akademik)->num_rows();
		$cekpembimbing = $this->m_login->cek_login("pembimbing_eskul",$where_akademik)->num_rows();
		if ($cekguru > 0) {
			$data_session = array(
				'nomor_induk' => $username,
				'status' => "login_guru"
				);

			$this->session->set_userdata($data_session);

			redirect("guru");
		}
		elseif ($cekakademik>0) {
			$data_session = array(
				'username' => $username,
				'status' => "login_guru"
				);

			$this->session->set_userdata($data_session);

			redirect("akademik");
		}
		elseif ($cekpembimbing>0) {
			$data_session = array(
				'username' => $username,
				'status' => "login_guru"
				);

			$this->session->set_userdata($data_session);

			redirect("pembimbing");
		}
	}
	function lupa_password(){
		$notif="Segera Hubungi admin Pak Yoga atau Pak Rasito";
		$data_notif=array(
		'signup_siswa'=>$notif
		);
		$where1=array('id'=>'1');
		$this->m_data->proses_edit_data($where1,$data_notif,"alert");
		redirect('login/signup_notif');
	}
	function signup_siswa(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$password2 = $this->input->post('password2');
		$nisn = $this->input->post('nisn');
		$email = $this->input->post('email');
		$where = array('nisn' => $nisn);
		$cek = $this->m_login->cek_login("siswa",$where)->num_rows();
		if ($password==$password2) {
			if ($cek > 0) {
				$data_cek['siswa']=$this->m_data->edit_data($where,'siswa')->result();
				foreach($data_cek['siswa'] as $a)
				if ($a->status=="Aktif") {
					if ($a->username==null) {
        			$data = array(
						'username' => $username,
						'password' => $password,
						'email'=>$email
						);
        			$notif="Selamat !!! akun anda telah aktif";
					$data_notif=array(
						'signup_siswa'=>$notif
						);
					$where1=array('id'=>'1');
					$this->m_data->proses_edit_data($where1,$data_notif,"alert");
					$this->m_data->proses_edit_data($where,$data,"siswa");
					 redirect('login/signup_notif');
	        		}
	        		else{
	        			$notif="NISN sudah di daftarkan sebelumnya,Jika anda tidak merasa mendafarkan segera hubungi Admin";
						$data_notif=array(
							'signup_siswa'=>$notif
							);
						$where1=array('id'=>'1');
						$this->m_data->proses_edit_data($where1,$data_notif,"alert");
						 redirect('login/signup_notif');
	        		}
				}
        		else{
        		$notif="anda sudah tidak aktif belajar di SMA N 1 Rembang";
				$data_notif=array(
					'signup_siswa'=>$notif
					);
				$where1=array('id'=>'1');
				$this->m_data->proses_edit_data($where1,$data_notif,"alert");
				 redirect('login/signup_notif');
        	}
        	}
        	else{
        		$notif="NISN tidak terdaftar";
				$data_notif=array(
					'signup_siswa'=>$notif
					);
				$where1=array('id'=>'1');
				$this->m_data->proses_edit_data($where1,$data_notif,"alert");
				 redirect('login/signup_notif');
        	}
		}
		else{
			$notif="Password dan ulangi password tidak cocok";
			$data_notif=array(
				'signup_siswa'=>$notif
				);
			$where1=array('id'=>'1');
			$this->m_data->proses_edit_data($where1,$data_notif,"alert");
			 redirect('login/signup_notif');
		}
	}
	function aksi_login(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$nomor_induk = $this->input->post('username');
		$password_guru = $this->input->post('password');
		$where = array(
			'username' => $username,
			'password' => $password
			);
		$where_guru = array(
			'nomor_induk' => $nomor_induk,
			'password_guru' => $password_guru
			);
		$where_pembimbing = array(
			'username' => $username,
			'password' => $password
			);
		$where_akademik = array(
			'username' => $username,
			'password' => $password
			);
		$where_siswa = array(
			'username' => $username,
			'password' => $password
			);
		$cek = $this->m_login->cek_login("admin",$where)->num_rows();
		$cekguru = $this->m_login->cek_login("guru",$where_guru)->num_rows();
		$cekpembimbing = $this->m_login->cek_login("pembimbing_eskul",$where_pembimbing)->num_rows();
		$cekakademik = $this->m_login->cek_login("biro_akademik",$where_akademik)->num_rows();
		$ceksiswa = $this->m_login->cek_login("siswa",$where_siswa)->num_rows();
		if($cek > 0){
			$data_session = array(
				'nama' => $username,
				'status' => "login_admin"
				);

			$this->session->set_userdata($data_session);

			redirect("admin");

		}
		elseif ($cekguru > 0) {
			$data_session = array(
				'nomor_induk' => $nomor_induk,
				'status' => "login_guru"
				);

			$this->session->set_userdata($data_session);

			redirect("guru");
		}
		elseif ($cekpembimbing > 0) {
			$data_session = array(
				'username' => $username,
				'status' => "login_guru"
				);

			$this->session->set_userdata($data_session);

			redirect("pembimbing");
		}
		elseif ($cekakademik>0) {
			$data_session = array(
				'username' => $username,
				'status' => "login_guru"
				);

			$this->session->set_userdata($data_session);

			redirect("akademik");
		}
		elseif ($ceksiswa>0) {
			$data_session = array(
				'username' => $username,
				'status' => "login_guru"
				);

			$this->session->set_userdata($data_session);

			redirect("siswa");
		}
		else{
			echo "Username dan password salah !";
			redirect("login");;
		}
	}

	function logout(){
		$this->session->sess_destroy();
		redirect("login");
	}
}