<?php 
class Siswa extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('m_data');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
		if($this->session->userdata('status') != "login_guru"){
			redirect("login");
		}
	}
	function index(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['siswa']=$this->m_data->edit_data($where,'siswa')->result();
		$this->load->view('main/v_siswa_header',$data);
		$this->load->view('main/v_siswa',$data);		
	}
	function cek_tampil(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['siswa']=$this->m_data->edit_data($where,'siswa')->result();
		foreach ($data['siswa'] as $s)
		$nis=$s->nis;
		$perjanjian="SAYA SETUJU";
		$status_administrasi="BERES"; 
		$data_edit=array(
			'perjanjian'=>$perjanjian
			);
		$table='pengumuman_ujian';
		$where1=array('nis'=>$nis);
		$data['pengumuman_ujian']=$this->m_data->lihat_pengumuman_un($nis);
		foreach ($data['pengumuman_ujian'] as $p)
		$this->m_data->proses_edit_data($where1,$data_edit,$table);
		$cek = $this->m_data->edit_data($where1,"pengumuman_ujian")->num_rows();
		if ($cek>0) {
			date_default_timezone_set('Asia/Jakarta');
			$jam=date("H:i");
			$tanggal=date('Y-m-d');
			if ($tanggal<$p->tanggal) {
				$this->load->view('main/v_siswa_header',$data);
				$this->load->view('main/siswa/pengumuman_un_belum_tampil',$data);
			}
			elseif ($tanggal==$p->tanggal) {
				if ($jam<$p->waktu) {
					$this->load->view('main/v_siswa_header',$data);
					$this->load->view('main/siswa/pengumuman_un_akan_tampil',$data);
				}
				elseif ($jam==$p->waktu){
					$this->load->view('main/v_siswa_header',$data);
					$this->load->view('main/siswa/perjanjian_pengumuman',$data);
				}
				elseif ($jam>$p->waktu){
					$this->load->view('main/v_siswa_header',$data);
					$this->load->view('main/siswa/perjanjian_pengumuman',$data);
				}
			}
			else{
				$this->load->view('main/v_siswa_header',$data);
				$this->load->view('main/siswa/perjanjian_pengumuman',$data);
			}
		}
		else{
			$this->load->view('main/v_siswa_header',$data);
			$this->load->view('main/siswa/tidak_ada_pengumuman',$data);
			}
	}
	function perjanjian_pengumuman_un(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['siswa']=$this->m_data->edit_data($where,'siswa')->result();
		$this->load->view('main/v_siswa_header',$data);
		$this->load->view('main/siswa/perjanjian_pengumuman',$data);		
	}
	function pengumuman_un(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['siswa']=$this->m_data->edit_data($where,'siswa')->result();
		foreach ($data['siswa'] as $s)
		$nis=$s->nis;
		$perjanjian="SAYA SETUJU"; 
		$data_edit=array(
			'perjanjian'=>$perjanjian
			);
		$table='pengumuman_ujian';
		$where1=array('nis'=>$nis);
		$data['pengumuman_ujian']=$this->m_data->lihat_pengumuman_un($nis);
		$this->m_data->proses_edit_data($where1,$data_edit,$table);
		$this->load->view('main/v_siswa_header',$data);
		foreach ($data['pengumuman_ujian'] as $p)
		if ($p->status_administrasi=="BERES") {
			$this->load->view('main/siswa/pengumuman_un',$data);
		}
		else{
			$this->load->view('main/siswa/status_administrasi',$data);
		}		
	}
	function setting($id_siswa){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['siswa']=$this->m_data->edit_data($where,'siswa')->result();
		$this->load->view('main/v_siswa_header',$data);
		$this->load->view('main/siswa/setting',$data);
	}
	function setting_notif(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['siswa']=$this->m_data->edit_data($where,'siswa')->result();
		$data1['alert'] = $this->m_data->tampil_data('alert')->result();
		$this->load->view('main/v_siswa_header',$data);
		$this->load->view('main/siswa/setting_notif',$data1,$data);
	}
	function ganti_password(){
		$nis=$this->input->post('nis');
		$password_lama=$this->input->post('password_lama');
		$password_lama_input=$this->input->post('password3');
		$password1=$this->input->post('password1');
		$password2=$this->input->post('password2');

		if($password_lama==$password_lama_input){
			if ($password1==$password2) {
				$data=array(
				'password'=>$password1
				);
				$notif="Selamat Password Berhasil di ganti";
				$data_notif=array(
					'ganti_password'=>$notif
					);
				$where=array('nis'=>$nis);
				$where1=array('id'=>'1');
				$table='siswa';
			    $this->m_data->proses_edit_data($where,$data,$table);
			    $this->m_data->proses_edit_data($where1,$data_notif,"alert");
			    redirect('siswa/setting_notif');
			}
			else{
				$notif="Password baru dan ulangi password baru tidak cocok";
				$data_notif=array(
					'ganti_password'=>$notif
					);
				$where1=array('id'=>'1');
				$this->m_data->proses_edit_data($where1,$data_notif,"alert");
				 redirect('siswa/setting_notif');
			}
		}
		else{
			$notif="password lama salah";
			$data_notif=array(
				'ganti_password'=>$notif
				);
			$where1=array('id'=>'1');
			$this->m_data->proses_edit_data($where1,$data_notif,"alert");
			 redirect('siswa/setting_notif');
		}
	}
	function ganti_username(){
		$nis=$this->input->post('nis');
		$password_lama=$this->input->post('password_lama');
		$username=$this->input->post('username');
		$password=$this->input->post('password');

		if($password_lama==$password){
				$data=array(
				'username'=>$username
				);
				$notif="Selamat Username Berhasil di ganti";
				$data_notif=array(
					'ganti_password'=>$notif
					);
				$where=array('nis'=>$nis);
				$where1=array('id'=>'1');
				$table='siswa';
			    $this->m_data->proses_edit_data($where,$data,$table);
			    $this->m_data->proses_edit_data($where1,$data_notif,"alert");
			    redirect('login/logout');
		}
		else{
			$notif="Password tidak benar";
			$data_notif=array(
				'ganti_password'=>$notif
				);
			$where1=array('id'=>'1');
			$this->m_data->proses_edit_data($where1,$data_notif,"alert");
			 redirect('siswa/setting_notif');
		}
	}
}