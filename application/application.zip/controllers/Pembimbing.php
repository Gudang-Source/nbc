<?php 
class pembimbing extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('m_data');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
		if($this->session->userdata('status') != "login_guru"){
			redirect("login");
		}
	}
	function index(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['pembimbing_eskul']=$this->m_data->edit_data($where,'pembimbing_eskul')->result();
		$data1['siswa']=$this->m_data->jumlah_data_siswa("jeniskelamin_siswa","siswa");
    	$data1['guru']=$this->m_data->jumlah_data_guru("jenis_kelamin","guru");
    	$data1['siswa_kelas_ipa']=$this->m_data->jumlah_kelas_jurusan("IPA");
    	$data1['siswa_kelas_ips']=$this->m_data->jumlah_kelas_jurusan("IPS");
    	$data1['siswa_kelas_x']=$this->m_data->jumlah_kelas("X ");
    	$data1['siswa_kelas_xi']=$this->m_data->jumlah_kelas("XI ");
    	$data1['siswa_kelas_xii']=$this->m_data->jumlah_kelas("XII ");
		$this->load->view('main/v_pembimbing_header',$data);
		$this->load->view('main/v_pembimbing',$data1);		
	}
	function tambah_peserta($id_pembimbing){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['pembimbing_eskul']=$this->m_data->edit_data($where,'pembimbing_eskul')->result();
		foreach($data['pembimbing_eskul'] as $p)
        $ta=$p->ta;
		$data1['pembimbing_eskul'] = $this->m_data->tambah_peserta_eskul($id_pembimbing,$ta);
		$this->load->view('main/v_pembimbing_header',$data);
		$this->load->view('main/pembimbing/form_pembimbing/tambah_peserta',$data1,$data);
	}
	function tambah_prestasi_siswa($id_pembimbing){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['pembimbing_eskul']=$this->m_data->edit_data($where,'pembimbing_eskul')->result();
		foreach($data['pembimbing_eskul'] as $p)
        $ta=$p->ta;
		$data1['pembimbing_eskul'] = $this->m_data->tambah_peserta_eskul($id_pembimbing,$ta);
		$this->load->view('main/v_pembimbing_header',$data);
		$this->load->view('main/pembimbing/form_pembimbing/tambah_prestasi_siswa',$data1,$data);
	}
	function daftar_peserta_eskul(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['pembimbing_eskul']=$this->m_data->edit_data($where,'pembimbing_eskul')->result();
		foreach($data['pembimbing_eskul'] as $p)
        $id_pembimbing=$p->id_pembimbing;
		$data1['siswa'] = $this->m_data->tampil_data('siswa')->result();
		$data1['peserta_eskul']=$this->m_data->daftar_peserta_eskul_pembimbing($id_pembimbing)->result();
		$this->load->view('main/v_pembimbing_header',$data);
		$this->load->view('main/pembimbing/list_pembimbing/daftar_peserta_eskul',$data1);	
	}
	function proses_tambah_peserta_form(){
		$cn=$this->input->post('nis');
		$id_pembimbing = $this->input->post('id_pembimbing');
		$eskul = $this->input->post('eskul');
		$ta = $this->input->post('ta');

		$data = array(
		     "nis"=>$cn,
		     "pembimbing1"=>$id_pembimbing,
		     "ta"=>$ta,
		     "eskul1"=>$eskul);
		     $data2 = array(
		     "pembimbing2"=>$id_pembimbing,
		     "eskul2"=>$eskul);
		     $data3 = array(
		     "nis"=>$cn,
		     "pembimbing2"=>$id_pembimbing,
		     "ta"=>$ta,
		     "eskul2"=>$eskul);
		     $data4 = array(
		     "pembimbing1"=>$id_pembimbing,
		     "eskul1"=>$eskul);
		     $where = array(
					'id_pembimbing' => $id_pembimbing,
					'eskul' => $eskul,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"pembimbing_eskul")->num_rows();
		     if($cek > 0)
		       {
		     		$where_nis = array('nis'=>$cn);
		     		$cek_nis = $this->m_data->edit_data($where_nis,"siswa")->num_rows();
		     		if ($cek_nis>0) {
		     			$this->load->database();
						$sql="SELECT * FROM siswa";
						$query = $this->db->query($sql);
						foreach ($query->result() as $rw)
							$c=$rw->kelas;
		     			if ($c<8) {
		     				$where1=array('nis'=>$cn);
		     				$cek1=$this->m_data->edit_data($where1,"peserta_eskul")->num_rows();
		     				if ($cek1>0) {
		     					if ($eskul==1) {
		     						$where1=array('nis'=>$cn);
		     						$table='peserta_eskul';
									$this->m_data->proses_edit_data($where1,$data2,$table);
									$this->session->set_flashdata('msg','Berhasil upload ...!!');
		     					}
		     					else{
		     						$where1=array('nis'=>$cn);
		     						$table='peserta_eskul';
									$this->m_data->proses_edit_data($where1,$data4,$table);
									$this->session->set_flashdata('msg','Berhasil upload ...!!');
		     					}
		     				}
		     				else{
		     					if ($eskul==1) {
		     						$this->db->insert("peserta_eskul",$data3);
									$this->session->set_flashdata('msg','Berhasil upload ...!!');
		     					}
		     					else{
		     						$this->db->insert("peserta_eskul",$data);
									$this->session->set_flashdata('msg','Berhasil upload ...!!');
		     					}
		     				}
		     			}
		     			else{
		     				$where1=array('nis'=>$cn);
		     				$cek1=$this->m_data->edit_data($where1,"peserta_eskul")->num_rows();
		     				if ($cek1>0) {
		     					$this->session->set_flashdata('msg','Gagal upload ...!!');
		     				}
		     				else{
		     					$this->db->insert("peserta_eskul",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
		     				}
		     		}
      				}
		     		else{
		     			$this->session->set_flashdata('msg','Gagal upload ...!!');
		     		}
		     	}
		     else{
		     	$this->session->set_flashdata('msg','Gagal upload ...!!');
		     }
		     redirect('pembimbing/daftar_peserta_eskul');
	}
	function proses_tambah_peserta(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('pembimbing/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
		     $id_pembimbing = $this->input->post('id_pembimbing');
		     $eskul = $this->input->post('eskul');
		     $ta = $this->input->post('ta');
		     $data = array(
		     "nis"=>$cn,
		     "pembimbing1"=>$id_pembimbing,
		     "ta"=>$ta,
		     "eskul1"=>$eskul);
		     $data2 = array(
		     "pembimbing2"=>$id_pembimbing,
		     "eskul2"=>$eskul);
		     $data3 = array(
		     "nis"=>$cn,
		     "pembimbing2"=>$id_pembimbing,
		     "ta"=>$ta,
		     "eskul2"=>$eskul);
		     $data4 = array(
		     "pembimbing1"=>$id_pembimbing,
		     "eskul1"=>$eskul);
		     $where = array(
					'id_pembimbing' => $id_pembimbing,
					'eskul' => $eskul,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"pembimbing_eskul")->num_rows();
		     if($cek > 0)
		       {
		     		$where_nis = array('nis'=>$cn);
		     		$cek_nis = $this->m_data->edit_data($where_nis,"siswa")->num_rows();
		     		if ($cek_nis>0) {
		     			$this->load->database();
						$sql="SELECT * FROM siswa";
						$query = $this->db->query($sql);
						foreach ($query->result() as $rw)
							$c=$rw->kelas;
		     			if ($c<8) {
		     				$where1=array('nis'=>$cn);
		     				$cek1=$this->m_data->edit_data($where1,"peserta_eskul")->num_rows();
		     				if ($cek1>0) {
		     					if ($eskul==1) {
		     						$where1=array('nis'=>$cn);
		     						$table='peserta_eskul';
									$this->m_data->proses_edit_data($where1,$data2,$table);
									$this->session->set_flashdata('msg','Berhasil upload ...!!');
		     					}
		     					else{
		     						$where1=array('nis'=>$cn);
		     						$table='peserta_eskul';
									$this->m_data->proses_edit_data($where1,$data4,$table);
									$this->session->set_flashdata('msg','Berhasil upload ...!!');
		     					}
		     				}
		     				else{
		     					if ($eskul==1) {
		     						$this->db->insert("peserta_eskul",$data3);
									$this->session->set_flashdata('msg','Berhasil upload ...!!');
		     					}
		     					else{
		     						$this->db->insert("peserta_eskul",$data);
									$this->session->set_flashdata('msg','Berhasil upload ...!!');
		     					}
		     				}
		     			}
		     			else{
		     				$where1=array('nis'=>$cn);
		     				$cek1=$this->m_data->edit_data($where1,"peserta_eskul")->num_rows();
		     				if ($cek1>0) {
		     					$this->session->set_flashdata('msg','Gagal upload ...!!');
		     				}
		     				else{
		     					$this->db->insert("peserta_eskul",$data);
								$this->session->set_flashdata('msg','Berhasil upload ...!!');
		     				}
		     		}
      				}
		     		else{
		     			$this->session->set_flashdata('msg','Gagal upload ...!!');
		     		}
		     	}
		     else{
		     	$this->session->set_flashdata('msg','Gagal upload ...!!');
		     }
		     }
		     redirect('pembimbing/daftar_peserta_eskul');
		 }
	}
	function hapus_data_peserta($id_peserta){
		$where = array('id_peserta' => $id_peserta);
		$table='peserta_eskul';
		$this->m_data->hapus_data($where,$table);
		redirect('pembimbing/daftar_peserta_eskul');
	}
	function tambah_nilai($id_pembimbing){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['pembimbing_eskul']=$this->m_data->edit_data($where,'pembimbing_eskul')->result();
		foreach($data['pembimbing_eskul'] as $p)
        $ta=$p->ta;
		$data1['pembimbing_eskul'] = $this->m_data->tambah_peserta_eskul($id_pembimbing,$ta);
		$data1['eskul']=$this->m_data->tampil_data('eskul')->result();
		$this->load->view('main/v_pembimbing_header',$data);
		$this->load->view('main/pembimbing/form_pembimbing/tambah_nilai',$data1,$data);
	}
	function daftar_nilai(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['pembimbing_eskul']=$this->m_data->edit_data($where,'pembimbing_eskul')->result();
		foreach($data['pembimbing_eskul'] as $p)
        $id_pembimbing=$p->id_pembimbing;
		$data1['siswa'] = $this->m_data->tampil_data('siswa')->result();
		$data1['nilai_eskul']=$this->m_data->daftar_nilai_peserta_eskul_pembimbing($id_pembimbing)->result();
		$this->load->view('main/v_pembimbing_header',$data);
		$this->load->view('main/pembimbing/list_pembimbing/daftar_nilai',$data1);	
	}
	function proses_tambah_nilai(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('pembimbing/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		 $cn=$rowData[0][0];
       		 $nilai=$rowData[0][1];
       		 $komentar=$rowData[0][2];
		     $id_pembimbing = $this->input->post('id_pembimbing');
		     $eskul = $this->input->post('eskul');
		     $ta = $this->input->post('ta');
		     $batas1 = $this->input->post('batas1');
		     $batas2 = $this->input->post('batas2');
		     $batas3 = $this->input->post('batas3');
		     $batas4 = $this->input->post('batas4');
		     $batas5 = $this->input->post('batas5');
		     $batas6 = $this->input->post('batas6');
		     if ($nilai>=$batas1) {
		     	$nilai_akhir="A";
		     }
		     elseif ($nilai>=$batas2 && $nilai<=$batas3) {
		     	$nilai_akhir="B";
		     }
		     elseif ($nilai>=$batas4 && $nilai<=$batas5) {
		     	$nilai_akhir="C";
		     }
		     elseif ($nilai<=$batas6) {
		     	$nilai_akhir="D";
		     }
		     $data = array(
		     "nis"=>$cn,
		     "pembimbing"=>$id_pembimbing,
		     "ta"=>$ta,
		     "eskul"=>$eskul,
		     "nilai"=>$nilai,
		     "komentar"=>$komentar,
		     "nilai_akhir"=>$nilai_akhir);
		     $where = array(
					'id_pembimbing' => $id_pembimbing,
					'eskul' => $eskul,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"pembimbing_eskul")->num_rows();
		     if($cek > 0)
		       {
		     		$where_nis = array('nis'=>$cn);
		     		$cek_nis = $this->m_data->edit_data($where_nis,"siswa")->num_rows();
		     		if ($cek_nis>0) {
		     			$where_nilai = array('nis'=>$cn,'ta'=>$ta,'eskul' => $eskul);
		     			$cek_nilai = $this->m_data->edit_data($where_nilai,"nilai_eskul")->num_rows();
		     			if ($cek_nilai>0) {
		     				$this->session->set_flashdata('msg','Gagal upload ...!!');
		     			}
		     			else{
		 					$this->db->insert("nilai_eskul",$data);
							$this->session->set_flashdata('msg','Berhasil upload ...!!');
						}
      				}
		     		else{
		     			$this->session->set_flashdata('msg','Gagal upload ...!!');
		     		}
		     	}
		     else{
		     	$this->session->set_flashdata('msg','Gagal upload ...!!');
		     }
		     }
		     redirect('pembimbing/daftar_nilai');
		 }
	}
	function proses_tambah_nilai_form(){
       		 $cn=$this->input->post('nis');
       		 $nilai=$this->input->post('nilai');
		     $id_pembimbing = $this->input->post('id_pembimbing');
		     $eskul = $this->input->post('eskul');
		     $komentar = $this->input->post('komentar');
		     $ta = $this->input->post('ta');
		     $batas1 = $this->input->post('batas1');
		     $batas2 = $this->input->post('batas2');
		     $batas3 = $this->input->post('batas3');
		     $batas4 = $this->input->post('batas4');
		     $batas5 = $this->input->post('batas5');
		     $batas6 = $this->input->post('batas6');
		     if ($nilai>=$batas1) {
		     	$nilai_akhir="A";
		     }
		     elseif ($nilai>=$batas2 && $nilai<=$batas3) {
		     	$nilai_akhir="B";
		     }
		     elseif ($nilai>=$batas4 && $nilai<=$batas5) {
		     	$nilai_akhir="C";
		     }
		     elseif ($nilai<=$batas6) {
		     	$nilai_akhir="D";
		     }
		     $data = array(
		     "nis"=>$cn,
		     "pembimbing"=>$id_pembimbing,
		     "ta"=>$ta,
		     "eskul"=>$eskul,
		     "nilai"=>$nilai,
		     "komentar"=>$komentar,
		     "nilai_akhir"=>$nilai_akhir);
		     $where = array(
					'id_pembimbing' => $id_pembimbing,
					'eskul' => $eskul,
					'ta'=>$ta
					);
		     $cek = $this->m_data->edit_data($where,"pembimbing_eskul")->num_rows();
		     if($cek > 0)
		       {
		     		$where_nis = array('nis'=>$cn);
		     		$cek_nis = $this->m_data->edit_data($where_nis,"siswa")->num_rows();
		     		if ($cek_nis>0) {
		     			$where_nilai = array('nis'=>$cn,'ta'=>$ta,'eskul' => $eskul);
		     			$cek_nilai = $this->m_data->edit_data($where_nilai,"nilai_eskul")->num_rows();
		     			if ($cek_nilai>0) {
		     				$this->session->set_flashdata('msg','Gagal upload ...!!');
		     			}
		     			else{
		 					$this->db->insert("nilai_eskul",$data);
							$this->session->set_flashdata('msg','Berhasil upload ...!!');
						}
      				}
		     		else{
		     			$this->session->set_flashdata('msg','Gagal upload ...!!');
		     		}
		     	}
		     else{
		     	$this->session->set_flashdata('msg','Gagal upload ...!!');
		     }
		     redirect('pembimbing/daftar_nilai');
		 }
	function hapus_data_nilai($id_nilai_eskul){
		$where = array('id_nilai_eskul' => $id_nilai_eskul);
		$table='nilai_eskul';
		$this->m_data->hapus_data($where,$table);
		redirect('pembimbing/daftar_peserta_eskul');
	}
	function edit_nilai($id_nilai_eskul){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['pembimbing_eskul']=$this->m_data->edit_data($where,'pembimbing_eskul')->result();
		foreach($data['pembimbing_eskul'] as $p)
        $id_pembimbing=$p->id_pembimbing;
		$where1 = array('id_nilai_eskul' => $id_nilai_eskul);
		$data1['eskul']=$this->m_data->tampil_data('eskul')->result();
		$data1['nilai_eskul']=$this->m_data->edit_data($where1,'nilai_eskul')->result();
		$data1['nilai_eskul']=$this->m_data->edit_nilai_eskul($id_nilai_eskul)->result();
		$this->load->view('main/v_pembimbing_header',$data);
		$this->load->view('main/pembimbing/form_pembimbing/edit_nilai',$data1);
	}
	function proses_edit_nilai(){
		$id_nilai_eskul=$this->input->post('id_nilai_eskul');
		$nilai=$this->input->post('nilai');
		$batas1 = $this->input->post('batas1');
		$batas2 = $this->input->post('batas2');
		$batas3 = $this->input->post('batas3');
		$batas4 = $this->input->post('batas4');
		$batas5 = $this->input->post('batas5');
		$batas6 = $this->input->post('batas6');
		if ($nilai>=$batas1) {
		     $nilai_akhir="A";
		}
		elseif ($nilai>=$batas2 && $nilai<=$batas3) {
		   	$nilai_akhir="B";
		}
		elseif ($nilai>=$batas4 && $nilai<=$batas5) {
		    $nilai_akhir="C";
		}
		elseif ($nilai<=$batas6) {
		     $nilai_akhir="D";
		}
		$data=array(
			'nilai'=>$nilai,
			'nilai_akhir'=>$nilai_akhir
			);
		$table='nilai_eskul';
		$where=array('id_nilai_eskul'=>$id_nilai_eskul);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('pembimbing/daftar_nilai');
	}
	function proses_tambah_prestasi_siswa(){
       		 $cn=$this->input->post('nis');
		     $pembimbing = $this->input->post('id_pembimbing');
		     $eskul = $this->input->post('eskul');
		     $nama_kegiatan = $this->input->post('nama_kegiatan');
		     $ta = $this->input->post('ta');
		     $keterangan = $this->input->post('keterangan');
		     
		     $data = array(
		     "nis"=>$cn,
		     "pembimbing"=>$pembimbing,
		     "ta"=>$ta,
		     "eskul"=>$eskul,
		     "keterangan"=>$keterangan,
		     "nama_kegiatan"=>$nama_kegiatan);
		     $where = array(
					'nis' => $cn,
					'eskul' => $eskul,
					'ta'=>$ta
					);
		     $cek = $this->m_data->peserta_eskul($cn,$ta,$pembimbing,$eskul)->num_rows();
		     if($cek > 0)
		       {
		     		$this->db->insert("prestasi_siswa",$data);
		     	}
		     else{
		     	$this->session->set_flashdata('msg','Gagal upload ...!!');
		     }
		     redirect('pembimbing/daftar_prestasi_siswa');
		 }
	function daftar_prestasi_siswa(){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['pembimbing_eskul']=$this->m_data->edit_data($where,'pembimbing_eskul')->result();
		foreach($data['pembimbing_eskul'] as $p)
        $id_pembimbing=$p->id_pembimbing;
		$data1['peserta_eskul']=$this->m_data->daftar_prestasi($id_pembimbing)->result();
		$this->load->view('main/v_pembimbing_header',$data);
		$this->load->view('main/pembimbing/list_pembimbing/daftar_prestasi',$data1);	
	}
	function edit_prestasi_siswa($id_prestasi_siswa){
		$this->load->model('m_data');
		$u=$this->session->userdata("username");
		$where=array('username'=>$u);
		$data['pembimbing_eskul']=$this->m_data->edit_data($where,'pembimbing_eskul')->result();
		$data1['eskul']=$this->m_data->tampil_data('eskul')->result();
		$data1['prestasi_siswa']=$this->m_data->edit_prestasi($id_prestasi_siswa)->result();
		$this->load->view('main/v_pembimbing_header',$data);
		$this->load->view('main/pembimbing/form_pembimbing/edit_prestasi_siswa',$data1);
	}
	function proses_edit_prestasi_siswa(){
		$id_prestasi_siswa=$this->input->post('id_prestasi_siswa');
		$nis=$this->input->post('nis');
		$nama_kegiatan=$this->input->post('nama_kegiatan');
		$keterangan=$this->input->post('keterangan');
		$data=array(
			'nis'=>$nis,
			'nama_kegiatan'=>$nama_kegiatan,
			'keterangan'=>$keterangan
			);
		$table='prestasi_siswa';
		$where=array('id_prestasi_siswa'=>$id_prestasi_siswa);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('pembimbing/daftar_prestasi_siswa');
	}
	function hapus_data_prestasi_siswa($id_prestasi_siswa){
		$where = array('id_prestasi_siswa' => $id_prestasi_siswa);
		$table='prestasi_siswa';
		$this->m_data->hapus_data($where,$table);
		redirect('pembimbing/daftar_prestasi_siswa');
	}
}
?>