<?php 
class Admin extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('m_data');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
		if($this->session->userdata('status') != "login_admin"){
			redirect("login");
		}
	}

	function index(){
		$this->load->model('m_data');
		$data1['siswa']=$this->m_data->jumlah_data_siswa("jeniskelamin_siswa","siswa");
    	$data1['guru']=$this->m_data->jumlah_data_guru("jenis_kelamin","guru");
    	$data1['siswa_kelas_ipa']=$this->m_data->jumlah_kelas_jurusan("IPA");
    	$data1['siswa_kelas_ips']=$this->m_data->jumlah_kelas_jurusan("IPS");
    	$data1['siswa_kelas_x']=$this->m_data->jumlah_kelas("X ");
    	$data1['siswa_kelas_xi']=$this->m_data->jumlah_kelas("XI ");
    	$data1['siswa_kelas_xii']=$this->m_data->jumlah_kelas("XII ");
    	$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/v_admin',$data1);
		
	}
	function tambah_biro_akademik(){
		$this->load->model('m_data');
		$data['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_biro_akademik',$data);
	}
	function tambah_admin(){
		$this->load->model('m_data');
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_admin');
	}
	function proses_tambah_admin(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$level="sub admin";

		$data = array(
			'username'=>$username,
			'password'=>$password,
			'level'=>$level
			);
		$this->m_data->tambah_data($data,'admin');
		redirect('admin/daftar_admin');		
	}
	function proses_edit_admin(){
		$id_admin = $this->input->post('id_admin');
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$level = $this->input->post('level');

		$data = array(
			'username'=>$username,
			'password'=>$password,
			'level'=>$level
			);
		$table='admin';
		$where=array('id_admin'=>$id_admin);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_admin');		
	}
	function daftar_admin(){
		$this->load->model('m_data');
		$u=$this->session->userdata("nama");
		$where=array('username'=>$u);
		$data['admincek']=$this->m_data->edit_data($where,'admin')->result();
		$data['admin'] = $this->m_data->daftar_admin()->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_admin',$data);
	}
	function edit_admin($id_admin){
		$where=array('id_admin'=>$id_admin);
		$data['admin']=$this->m_data->edit_data($where,'admin')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/edit_admin',$data);
	}
	function hapus_data_admin($id_admin){
		$where = array('id_admin' => $id_admin);
		$table='admin';
		$this->m_data->hapus_data($where,$table);
		redirect('admin/daftar_admin');
	}
	function hapus_data_ta($id_ta){
		$where = array('id_ta' => $id_ta);
		$table='tahun_ajaran';
		$this->m_data->hapus_data($where,$table);
		redirect('admin/daftar_ta');
	}
	function tambah_tugas_guru(){
		$this->load->model('m_data');
		$data['guru'] = $this->m_data->tampil_data('guru')->result();
		$data['matapelajaran'] = $this->m_data->tampil_data('matapelajaran')->result();
		$data['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_tugas_ajar_guru',$data);
	}
	function tambah_eskul(){
		$this->load->model('m_data');
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_eskul');
	}
	function tambah_range_eskul($id_eskul){
		$where=array('id_eskul'=>$id_eskul);
		$data['eskul']=$this->m_data->edit_data($where,'eskul')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_range_eskul',$data);
	}
	function proses_edit_range_eskul(){
		$id_eskul=$this->input->post('id_eskul');
		$batas1=$this->input->post('batas1');
		$batas2=$this->input->post('batas2');
		$batas3=$this->input->post('batas3');
		$batas4=$this->input->post('batas4');
		$batas5=$this->input->post('batas5');
		$batas6=$this->input->post('batas6');

		$data=array(
			'batas1'=>$batas1,
			'batas2'=>$batas2,
			'batas3'=>$batas3,
			'batas4'=>$batas4,
			'batas5'=>$batas5,
			'batas6'=>$batas6
			);
		$table='eskul';
		$where=array('id_eskul'>0);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_eskul');
	}
	function proses_edit_range_mapel(){
		$id_mapel=$this->input->post('id_mapel');
		$batas1=$this->input->post('batas1');
		$batas2=$this->input->post('batas2');
		$batas3=$this->input->post('batas3');
		$batas4=$this->input->post('batas4');
		$batas5=$this->input->post('batas5');
		$batas6=$this->input->post('batas6');

		$data=array(
			'batas1'=>$batas1,
			'batas2'=>$batas2,
			'batas3'=>$batas3,
			'batas4'=>$batas4,
			'batas5'=>$batas5,
			'batas6'=>$batas6
			);
		$table='matapelajaran';
		$where=array('id_matapelajaran'>0);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_mapel');
	}
	function tambah_range_mapel($id_mapel){
		$where=array('id_matapelajaran'=>$id_mapel);
		$data['matapelajaran']=$this->m_data->edit_data($where,'matapelajaran')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_range_mapel',$data);
	}
	function proses_tambah_eskul(){
		$nama_eskul = $this->input->post('nama_eskul');

		$data = array(
			'nama_eskul'=>$nama_eskul
			);
		$this->m_data->tambah_data($data,'eskul');
		redirect('admin/daftar_eskul');		
	}
	function edit_eskul($id_eskul){
		$where=array('id_eskul'=>$id_eskul);
		$data['eskul']=$this->m_data->edit_data($where,'eskul')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/edit_eskul',$data);
	}
	function proses_edit_eskul(){
		$id_eskul=$this->input->post('id_eskul');
		$nama_eskul=$this->input->post('nama_eskul');

		$data=array(
			'nama_eskul'=>$nama_eskul
			);
		$table='eskul';
		$where=array('id_eskul'=>$id_eskul);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_eskul');
	}
	function hapus_data_eskul($id_eskul){
		$where = array('id_eskul' => $id_eskul);
		$table='eskul';
		$this->m_data->hapus_data($where,$table);
		redirect('admin/daftar_eskul');
	}
	function daftar_eskul(){
		$this->load->model('m_data');
		$data['eskul'] = $this->m_data->tampil_data('eskul')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_eskul',$data);
	}
	function tambah_pembimbing_eskul(){
		$this->load->model('m_data');
		$data['eskul'] = $this->m_data->tampil_data('eskul')->result();
		$data['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_pembimbing_eskul',$data);
	}
	function edit_pembimbing_eskul($id_pembimbing){
		$data['eskul'] = $this->m_data->tampil_data('eskul')->result();
		$data['pembimbing_eskul'] = $this->m_data->tampil_data('pembimbing_eskul')->result();
		$data['pembimbing_eskul']=$this->m_data->edit_pembimbing_eskul($id_pembimbing);
		$data['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/edit_pembimbing_eskul',$data);
	}
	function proses_edit_pembimbing_eskul(){
		$id_pembimbing=$this->input->post('id_pembimbing');
		$nama_pembimbing = $this->input->post('nama_pembimbing');
		$eskul = $this->input->post('eskul');
		$ta = $this->input->post('ta');
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$data=array(
			'nama_pembimbing'=>$nama_pembimbing,
			'eskul'=>$eskul,
			'ta'=>$ta,
			'username'=>$username,
			'password'=>$password
			);
		$table='pembimbing_eskul';
		$where=array('id_pembimbing'=>$id_pembimbing);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_pembimbing_eskul');
	}
	function proses_tambah_pembimbing_eskul(){
		$nama_pembimbing = $this->input->post('nama_pembimbing');
		$eskul = $this->input->post('eskul');
		$ta = $this->input->post('ta');
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$data = array(
			'nama_pembimbing'=>$nama_pembimbing,
			'eskul'=>$eskul,
			'ta'=>$ta,
			'username'=>$username,
			'password'=>$password
			);
		$this->m_data->tambah_data($data,'pembimbing_eskul');
		redirect('admin/daftar_pembimbing_eskul');		
	}
	function hapus_data_pembimbing_eskul($id_pembimbing){
		$where = array('id_pembimbing' => $id_pembimbing);
		$table='pembimbing_eskul';
		$this->m_data->hapus_data($where,$table);
		redirect('admin/daftar_pembimbing_eskul');
	}
	function daftar_pembimbing_eskul(){
		$this->load->model('m_data');
		$data['pembimbing_eskul'] = $this->m_data->daftar_pembimbing_eskul();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_pembimbing_eskul',$data);
	}
	function tambah_guru(){
		$this->load->model('m_data');
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_guru');
	}
	function proses_tambah_tugas_guru(){
		$id_guru = $this->input->post('id_guru');
		$id_matapelajaran = $this->input->post('id_matapelajaran');
		$id_ta = $this->input->post('id_ta');
		$kelas1 = $this->input->post('kelas1');
		$kelas2 = $this->input->post('kelas2');
		$kelas3 = $this->input->post('kelas3');
		$kelas4 = $this->input->post('kelas4');
		$kelas5 = $this->input->post('kelas5');
		$kelas6 = $this->input->post('kelas6');
		$kelas7 = $this->input->post('kelas7');
		$kelas8 = $this->input->post('kelas8');
		$kelas9 = $this->input->post('kelas9');
		$kelas10 = $this->input->post('kelas10');
		$kelas11 = $this->input->post('kelas11');
		$kelas12 = $this->input->post('kelas12');
		$kelas13 = $this->input->post('kelas13');
		$kelas14 = $this->input->post('kelas14');
		$kelas15 = $this->input->post('kelas15');
		$kelas16 = $this->input->post('kelas16');
		$kelas17 = $this->input->post('kelas17');
		$kelas18 = $this->input->post('kelas18');
		$kelas19 = $this->input->post('kelas19');
		$kelas20 = $this->input->post('kelas20');
		$kelas21 = $this->input->post('kelas21');
		$kelas22 = $this->input->post('kelas22');
		$kelas23 = $this->input->post('kelas23');
		$kelas24 = $this->input->post('kelas24');

		$data = array(
			'id_guru'=>$id_guru,
			'id_matapelajaran'=>$id_matapelajaran,
			'ta'=>$id_ta,
			'kelas1'=>$kelas1,
			'kelas2'=>$kelas2,
			'kelas3'=>$kelas3,
			'kelas4'=>$kelas4,
			'kelas5'=>$kelas5,
			'kelas6'=>$kelas6,
			'kelas7'=>$kelas7,
			'kelas8'=>$kelas8,
			'kelas9'=>$kelas9,
			'kelas10'=>$kelas10,
			'kelas11'=>$kelas11,
			'kelas12'=>$kelas12,
			'kelas13'=>$kelas13,
			'kelas14'=>$kelas14,
			'kelas15'=>$kelas15,
			'kelas16'=>$kelas16,
			'kelas17'=>$kelas17,
			'kelas18'=>$kelas18,
			'kelas19'=>$kelas19,
			'kelas20'=>$kelas20,
			'kelas21'=>$kelas21,
			'kelas22'=>$kelas22,
			'kelas23'=>$kelas23,
			'kelas24'=>$kelas24
			);
		$this->m_data->tambah_data($data,'ajar');
		redirect('admin/daftar_ajar');		
	}
	function proses_tambah_biro_akademik(){
		$guru=$this->input->post('id_guru');
		$username=$this->input->post('username');
		$password=$this->input->post('password');

		$data=array(
			'guru'=>$guru,
			'username'=>$username,
			'password'=>$password
			);
		$this->m_data->tambah_data($data,'biro_akademik');
		redirect('admin/daftar_biro_akademik');		
	}
	function edit_biro_akademik($id_biro_akademik){
		$where=array('id_biro_akademik'=>$id_biro_akademik);
		$data['guru'] = $this->m_data->tampil_data('guru')->result();
		$query=$this->m_data->edit_biro_akademik($id_biro_akademik);
		$data['biro_akademik']=$query;
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/edit_biro_akademik',$data);
	}
	function hapus_data_biro_akademik($id_biro_akademik){
		$where = array('id_biro_akademik' => $id_biro_akademik);
		$table='biro_akademik';
		$this->m_data->hapus_data($where,$table);
		redirect('admin/daftar_biro_akademik');
	}
	function daftar_biro_akademik(){
		$this->load->model('m_data');
		$query=$this->m_data->daftar_biro_akademik();
		$data['biro_akademik']=$query;
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_biro_akademik',$data);
	}
	function proses_tambah_guru(){
		$nomor_induk=$this->input->post('nomor_induk');
		$nama_guru=$this->input->post('nama_guru');
		$jenis_kelamin=$this->input->post('jenis_kelamin');
		$golongan=$this->input->post('golongan');
		$jabatan=$this->input->post('jabatan');
		$status=$this->input->post('status');
		$password_guru=$this->input->post('password_guru');

		$data=array(
			'nomor_induk'=>$nomor_induk,
			'nama_guru'=>$nama_guru,
			'jenis_kelamin'=>$jenis_kelamin,
			'golongan'=>$golongan,
			'jabatan'=>$jabatan,
			'status'=>$status,
			'password_guru'=>$password_guru
			);
		$this->m_data->tambah_data($data,'guru');
		redirect('admin/daftar_guru');		
	}
	function proses_edit_biro_akademik(){
		$id_biro_akademik=$this->input->post('id_biro_akademik');
		$id_guru=$this->input->post('id_guru');
		$username=$this->input->post('username');
		$password=$this->input->post('password');

		$data=array(
			'guru'=>$id_guru,
			'username'=>$username,
			'password'=>$password,
			);
		$table='biro_akademik';
		$where=array('id_biro_akademik'=>$id_biro_akademik);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_biro_akademik');
	}
	function proses_tambah_guru_excel(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		if($rowData[0][1]=="L"){
       			$jk="Laki - Laki";
       		}
       		elseif($rowData[0][1]=="P"){
       			$jk="Perempuan";
       		}
		     $data = array(
		     "nomor_induk"=> $rowData[0][2],
		     "nama_guru"=> $rowData[0][0],
		     "jenis_kelamin"=> $jk,
		     "golongan"=> $rowData[0][3],
		     "jabatan"=> $rowData[0][4],
		     "status"=> $rowData[0][5],
		     "password_guru"=> $rowData[0][6],
		     );
		     $this->db->insert("guru",$data);
   		} 
        redirect('admin/daftar_guru');
	}
	}
	function edit_guru($id_guru){
		$where=array('id_guru'=>$id_guru);
		$data['matapelajaran'] = $this->m_data->tampil_data('matapelajaran')->result();
		$data['guru']=$this->m_data->edit_data($where,'guru')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/edit_guru',$data);
	}
	function proses_edit_guru(){
		$id_guru=$this->input->post('id_guru');
		$nomor_induk=$this->input->post('nomor_induk');
		$nama_guru=$this->input->post('nama_guru');
		$jenis_kelamin=$this->input->post('jenis_kelamin');
		$golongan=$this->input->post('golongan');
		$jabatan=$this->input->post('jabatan');
		$status=$this->input->post('status');
		$password_guru=$this->input->post('password_guru');

		$data=array(
			'nomor_induk'=>$nomor_induk,
			'nama_guru'=>$nama_guru,
			'jenis_kelamin'=>$jenis_kelamin,
			'golongan'=>$golongan,
			'jabatan'=>$jabatan,
			'status'=>$status,
			'password_guru'=>$password_guru
			);

		$where=array('id_guru'=>$id_guru);
		$table='guru';
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_guru');

	}
	function daftar_guru(){
		$this->load->model('m_data');
		$data['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_guru',$data);
	}
	function hapus_data_guru($id_guru){
		$where = array('id_guru' => $id_guru);
		$table='guru';
		$this->m_data->hapus_data($where,$table);
		redirect('admin/daftar_guru');
	}
		function daftar_mapel(){
		$this->load->model('m_data');
		$data['matapelajaran'] = $this->m_data->tampil_data('matapelajaran')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_mapel',$data);
	}
	function tambah_mapel(){
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_mapel');
	}
	function proses_tambah_mapel(){
		$kode_matapelajaran = $this->input->post('kode_matapelajaran');
		$nama_matapelajaran = $this->input->post('nama_matapelajaran');
		$kategori = $this->input->post('kategori');

		$data = array(
			'kode_matapelajaran'=>$kode_matapelajaran,
			'nama_matapelajaran'=>$nama_matapelajaran,
			'kategori'=>$kategori
			);
		$this->m_data->tambah_data($data,'matapelajaran');
		redirect('admin/daftar_mapel');		
	}
	function proses_edit_mapel(){
		$id_matapelajaran=$this->input->post('id_matapelajaran');
		$kode_matapelajaran=$this->input->post('kode_matapelajaran');
		$nama_matapelajaran=$this->input->post('nama_matapelajaran');
		$kkm=$this->input->post('kkm');
		$kategori=$this->input->post('kategori');

		$data=array(
			'kode_matapelajaran'=>$kode_matapelajaran,
			'nama_matapelajaran'=>$nama_matapelajaran,
			'kkm'=>$kkm,
			'kategori'=>$kategori
			);
		$table='matapelajaran';
		$where=array('id_matapelajaran'=>$id_matapelajaran);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_mapel');

	}
	function edit_mapel($id_matapelajaran){
		$where=array('id_matapelajaran'=>$id_matapelajaran);
		$data['matapelajaran']=$this->m_data->edit_data($where,'matapelajaran')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/edit_mapel',$data);
	}
	function hapus_data_mapel($id_matapelajaran){
		$where = array('id_matapelajaran' => $id_matapelajaran);
		$table='matapelajaran';
		$this->m_data->hapus_data($where,$table);
		redirect('admin/daftar_mapel');
	}
	function daftar_siswa(){
		$this->load->model('m_data');
		$query=$this->m_data->daftarsiswa();
		$query1=$this->m_data->daftarsiswa_tidakaktif();
		$data['siswa']=$query;
		$data['siswa_tidak_aktif']=$query1;
		$data['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_siswa',$data);
	}
	function daftar_siswa_kelas(){
		$this->load->model('m_data');
		$kelas=$this->input->post('kelas');
		$query=$this->m_data->daftarsiswa_kelas($kelas);
		$query1=$this->m_data->daftarsiswa_tidakaktif();
		$data['siswa']=$query;
		$data['siswa_tidak_aktif']=$query1;
		$data['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_siswa',$data);
	}
	function daftar_orangtua_siswa($nis){
		$this->load->model('m_data');
		$where=array('nis'=>$nis);
		$data['siswa']=$this->m_data->edit_data($where,'siswa')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_orangtua_siswa',$data);
	}
	function daftar_alamat_siswa($nis){
		$this->load->model('m_data');
		$where=array('nis'=>$nis);
		$data['siswa']=$this->m_data->edit_data($where,'siswa')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_alamat_siswa',$data);
	}
	function daftar_akun_siswa($nis){
		$this->load->model('m_data');
		$where=array('nis'=>$nis);
		$data['siswa']=$this->m_data->edit_data($where,'siswa')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_akun_siswa',$data);
	}
	function tambah_siswa(){
		$this->load->model('m_data');
		$data['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_siswa',$data);
	}
	function proses_tambah_siswa(){
		$nis=$this->input->post('nis');
		$nisn=$this->input->post('nisn');
		$nama_siswa=$this->input->post('nama_siswa');
		$jeniskelamin_siswa=$this->input->post('jeniskelamin_siswa');
		$alamat_siswa=$this->input->post('alamat_siswa');
		$tempatlahir_siswa=$this->input->post('tempatlahir_siswa');
		$tanggallahir_siswa=$this->input->post('tanggallahir_siswa');
		$nama_ayah=$this->input->post('nama_ayah');
		$nama_ibu=$this->input->post('nama_ibu');
		$pekerjaan_ayah=$this->input->post('pekerjaan_ayah');
		$pekerjaan_ibu=$this->input->post('pekerjaan_ibu');
		$desa=$this->input->post('desa');
		$rt=$this->input->post('rt');
		$rw=$this->input->post('rw');
		$kecamatan=$this->input->post('kecamatan');
		$kabupaten=$this->input->post('kabupaten');
		$kelas=$this->input->post('kelas');
		$status=$this->input->post('status');

		$data=array(
			'nis'=>$nis,
			'nisn'=>$nisn,
			'nama_siswa'=>$nama_siswa,
			'jeniskelamin_siswa'=>$jeniskelamin_siswa,
			'tempatlahir_siswa'=>$tempatlahir_siswa,
			'tanggallahir_siswa'=>$tanggallahir_siswa,
			'nama_ayah'=>$nama_ayah,
			'nama_ibu'=>$nama_ibu,
			'pekerjaan_ayah'=>$pekerjaan_ayah,
			'pekerjaan_ibu'=>$pekerjaan_ibu,
			'desa'=>$desa,
			'rt'=>$rt,
			'rw'=>$rw,
			'kecamatan'=>$kecamatan,
			'kabupaten'=>$kabupaten,
			'kelas'=>$kelas,
			'status'=>$status
			);
		$this->m_data->tambah_data($data,'siswa');
		redirect('admin/daftar_siswa');		
	}
	function proses_tambah_siswa_excel(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		if($rowData[0][3]=="L"){
       			$jk="Laki - Laki";
       		}
       		elseif($rowData[0][3]=="P"){
       			$jk="Perempuan";
       		}
		     $data = array(
		     "nis"=> $rowData[0][0],
		     "nisn"=> $rowData[0][1],
		     "nama_siswa"=> $rowData[0][2],
		     "jeniskelamin_siswa"=> $jk,
		     "tempatlahir_siswa"=> $rowData[0][4],
		     "tanggallahir_siswa"=> $rowData[0][5],
		     "nama_ayah"=> $rowData[0][6],
		     "nama_ibu"=> $rowData[0][7],
		     "pekerjaan_ayah"=> $rowData[0][8],
		     "pekerjaan_ibu"=> $rowData[0][9],
		     "desa"=> $rowData[0][10],
		     "rt"=> $rowData[0][11],
		     "rw"=> $rowData[0][12],
		     "kecamatan"=> $rowData[0][13],
		     "kabupaten"=> $rowData[0][14],
		     "kelas"=> $rowData[0][15],
		     "status"=> $rowData[0][16]
		     );
		     $this->db->insert("siswa",$data);
   		} 
        redirect('admin/daftar_siswa');
	}
	}
	function edit_siswa_tidak_aktif($nis){
		$data['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$where=array('nis'=>$nis);
		$data['siswa']=$this->m_data->edit_data($where,'siswa')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/edit_siswa_tidak_aktif',$data);
	}
	function edit_siswa($nis){
		$data['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data['siswa']=$this->m_data->edit_siswa($nis)->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/edit_siswa',$data);
	}
	function proses_edit_siswa(){
		$nis=$this->input->post('nis');
		$nisn=$this->input->post('nisn');
		$nama_siswa=$this->input->post('nama_siswa');
		$jeniskelamin_siswa=$this->input->post('jeniskelamin_siswa');
		$alamat_siswa=$this->input->post('alamat_siswa');
		$tempatlahir_siswa=$this->input->post('tempatlahir_siswa');
		$tanggallahir_siswa=$this->input->post('tanggallahir_siswa');
		$nama_ayah=$this->input->post('nama_ayah');
		$nama_ibu=$this->input->post('nama_ibu');
		$pekerjaan_ayah=$this->input->post('pekerjaan_ayah');
		$pekerjaan_ibu=$this->input->post('pekerjaan_ibu');
		$desa=$this->input->post('desa');
		$rt=$this->input->post('rt');
		$rw=$this->input->post('rw');
		$kecamatan=$this->input->post('kecamatan');
		$kabupaten=$this->input->post('kabupaten');
		$kelas=$this->input->post('kelas');
		$status=$this->input->post('status');
		$email=$this->input->post('email');
		$username=$this->input->post('username');
		$password=$this->input->post('password');

		if ($status=='Aktif') {
			$data=array(
				'nisn'=>$nisn,
				'nama_siswa'=>$nama_siswa,
				'jeniskelamin_siswa'=>$jeniskelamin_siswa,
				'tempatlahir_siswa'=>$tempatlahir_siswa,
				'tanggallahir_siswa'=>$tanggallahir_siswa,
				'nama_ayah'=>$nama_ayah,
				'nama_ibu'=>$nama_ibu,
				'pekerjaan_ayah'=>$pekerjaan_ayah,
				'pekerjaan_ibu'=>$pekerjaan_ibu,
				'desa'=>$desa,
				'rt'=>$rt,
				'rw'=>$rw,
				'kecamatan'=>$kecamatan,
				'kabupaten'=>$kabupaten,
				'kelas'=>$kelas,
				'status'=>$status,
				'email'=>$email,
				'username'=>$username,
				'password'=>$password
				);
			$table='siswa';
			$where=array('nis'=>$nis);
			$this->m_data->proses_edit_data($where,$data,$table);
		}
		else{
			$data=array(
				'nisn'=>$nisn,
				'nama_siswa'=>$nama_siswa,
				'jeniskelamin_siswa'=>$jeniskelamin_siswa,
				'tempatlahir_siswa'=>$tempatlahir_siswa,
				'tanggallahir_siswa'=>$tanggallahir_siswa,
				'nama_ayah'=>$nama_ayah,
				'nama_ibu'=>$nama_ibu,
				'pekerjaan_ayah'=>$pekerjaan_ayah,
				'pekerjaan_ibu'=>$pekerjaan_ibu,
				'desa'=>$desa,
				'rt'=>$rt,
				'rw'=>$rw,
				'kecamatan'=>$kecamatan,
				'kabupaten'=>$kabupaten,
				'kelas'=>0,
				'status'=>$status,
				'email'=>null,
				'username'=>null,
				'password'=>null
				);
			$table='siswa';
			$where=array('nis'=>$nis);
			$this->m_data->proses_edit_data($where,$data,$table);
		}

		redirect('admin/daftar_siswa');
	}
	function hapus_data_siswa($nis){
		$where = array('nis' => $nis);
		$table='siswa';
		$this->m_data->hapus_data($where,$table);
		redirect('admin/daftar_siswa');
	}
	function daftar_kelas(){
		$this->load->model('m_data');
		$data['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_kelas',$data);
	}
	function tambah_kelas(){
		$this->load->model('m_data');
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_kelas');
	}
	function proses_tambah_kelas(){
		$nama_kelas = $this->input->post('nama_kelas');

		$data = array(
			'nama_kelas'=>$nama_kelas
			);
		$this->m_data->tambah_data($data,'kelas');
		redirect('admin/daftar_kelas');		
	}
	function edit_kelas($id_kelas){
		$where=array('id_kelas'=>$id_kelas);
		$data['kelas']=$this->m_data->edit_data($where,'kelas')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/edit_kelas',$data);
	}
	function proses_edit_kelas(){
		$id_kelas=$this->input->post('id_kelas');
		$nama_kelas=$this->input->post('nama_kelas');

		$data=array(
			'id_kelas'=>$id_kelas,
			'nama_kelas'=>$nama_kelas
			);
		$table='kelas';
		$where=array('id_kelas'=>$id_kelas);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_kelas');
	}
	function hapus_data_kelas($id_kelas){
		$where = array('id_kelas' => $id_kelas);
		$table='kelas';
		$this->m_data->hapus_data($where,$table);
		redirect('admin/daftar_kelas');
	}
	function daftar_ajar(){
		$this->load->model('m_data');
		$query=$this->m_data->daftarajar();
		$data['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data['ajar']=$query;
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_ajar',$data);
	}
	function edit_ajar($id_ajar){
		$this->load->model('m_data');
		$data['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$data['matapelajaran'] = $this->m_data->tampil_data('matapelajaran')->result();
		$data['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$data['ajar']=$this->m_data->edit_ajar($id_ajar);
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/edit_tugas_ajar_guru',$data);
	}
	function hapus_data_ajar($id_ajar){
		$where = array('id_ajar' => $id_ajar);
		$table='ajar';
		$this->m_data->hapus_data($where,$table);
		redirect('admin/daftar_ajar');
	}
	function lihat_tugas_guru($id_guru){
		$this->load->model('m_data');
		$data['ajar']=$this->m_data->lihat_tugas_guru($id_guru);
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_ajar_guru',$data);
	}
	function proses_edit_tugas_guru(){
		$id_ajar=$this->input->post('id_ajar');
		$id_guru = $this->input->post('id_guru');
		$id_matapelajaran = $this->input->post('id_matapelajaran');
		$id_ta = $this->input->post('id_ta');
		$kelas1 = $this->input->post('kelas1');
		$kelas2 = $this->input->post('kelas2');
		$kelas3 = $this->input->post('kelas3');
		$kelas4 = $this->input->post('kelas4');
		$kelas5 = $this->input->post('kelas5');
		$kelas6 = $this->input->post('kelas6');
		$kelas7 = $this->input->post('kelas7');
		$kelas8 = $this->input->post('kelas8');
		$kelas9 = $this->input->post('kelas9');
		$kelas10 = $this->input->post('kelas10');
		$kelas11 = $this->input->post('kelas11');
		$kelas12 = $this->input->post('kelas12');
		$kelas13 = $this->input->post('kelas13');
		$kelas14 = $this->input->post('kelas14');
		$kelas15 = $this->input->post('kelas15');
		$kelas16 = $this->input->post('kelas16');
		$kelas17 = $this->input->post('kelas17');
		$kelas18 = $this->input->post('kelas18');
		$kelas19 = $this->input->post('kelas19');
		$kelas20 = $this->input->post('kelas20');
		$kelas21 = $this->input->post('kelas21');
		$kelas22 = $this->input->post('kelas22');
		$kelas23 = $this->input->post('kelas23');
		$kelas24 = $this->input->post('kelas24');

		$data = array(
			'id_guru'=>$id_guru,
			'id_matapelajaran'=>$id_matapelajaran,
			'ta'=>$id_ta,
			'kelas1'=>$kelas1,
			'kelas2'=>$kelas2,
			'kelas3'=>$kelas3,
			'kelas4'=>$kelas4,
			'kelas5'=>$kelas5,
			'kelas6'=>$kelas6,
			'kelas7'=>$kelas7,
			'kelas8'=>$kelas8,
			'kelas9'=>$kelas9,
			'kelas10'=>$kelas10,
			'kelas11'=>$kelas11,
			'kelas12'=>$kelas12,
			'kelas13'=>$kelas13,
			'kelas14'=>$kelas14,
			'kelas15'=>$kelas15,
			'kelas16'=>$kelas16,
			'kelas17'=>$kelas17,
			'kelas18'=>$kelas18,
			'kelas19'=>$kelas19,
			'kelas20'=>$kelas20,
			'kelas21'=>$kelas21,
			'kelas22'=>$kelas22,
			'kelas23'=>$kelas23,
			'kelas24'=>$kelas24
			);
		$where=array('id_ajar'=>$id_ajar);
		$table='ajar';
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_ajar');
	}
	function lihat_siswa_kelas($id_kelas){
		$this->load->model('m_data');
		$query=$this->m_data->daftarsiswa_kelas($id_kelas);
		$data['siswa']=$query;
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_siswa_kelas',$data);
	}
	function tambah_ta(){
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_tahun_ajaran');
	}
	function proses_tambah_ta(){
		$nama_ta = $this->input->post('nama_ta');

		$data = array(
			'nama_ta'=>$nama_ta
			);
		$this->m_data->tambah_data($data,'tahun_ajaran');
		redirect('admin/daftar_ta');		
	}
	function daftar_ta(){
		$this->load->model('m_data');
		$data['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_ta',$data);
	}
	function edit_ta($id_ta){
		$this->load->model('m_data');
		$where=array('id_ta'=>$id_ta);
		$data['tahun_ajaran']=$this->m_data->edit_data($where,'tahun_ajaran')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/edit_tahun_ajaran',$data);
	}
	function proses_edit_ta(){
		$id_ta=$this->input->post('id_ta');
		$nama_ta=$this->input->post('nama_ta');

		$data=array(
			'nama_ta'=>$nama_ta
			);
		$table='tahun_ajaran';
		$where=array('id_ta'=>$id_ta);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_ta');
	}
	function setting(){
		$this->load->model('m_data');
		$u=$this->session->userdata("nama");
		$where=array('username'=>$u);
		$data_cek['admin']=$this->m_data->edit_data($where,'admin')->result();
		foreach($data_cek['admin'] as $a)
        $id_admin=$a->id_admin;
    	$where1=array('id_admin'=>$id_admin);
    	$data['admin']=$this->m_data->edit_data($where1,'admin')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/setting',$data);
	}
	function setting_notif(){
		$this->load->model('m_data');
		$u=$this->session->userdata("nama");
		$where=array('username'=>$u);
		$data_cek['admin']=$this->m_data->edit_data($where,'admin')->result();
		foreach($data_cek['admin'] as $a)
		$id_admin=$a->id_admin;
    	$where1=array('id_admin'=>$id_admin);
    	$data['admin']=$this->m_data->edit_data($where1,'admin')->result();
		$data['alert'] = $this->m_data->tampil_data('alert')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/setting_notif',$data);
	}
	function ganti_password(){
		$id_admin=$this->input->post('id_admin');
		$password_lama=$this->input->post('password_lama');
		$password_lama_input=$this->input->post('password3');
		$password1=$this->input->post('password1');
		$password2=$this->input->post('password2');

		if($password_lama==$password_lama_input){
			if ($password1==$password2) {
				$data=array(
				'password'=>$password1
				);
				$notif="Selamat Password Berhasil di ganti";
				$data_notif=array(
					'ganti_password'=>$notif
					);
				$where=array('id_admin'=>$id_admin);
				$where1=array('id'=>'1');
				$table='admin';
			    $this->m_data->proses_edit_data($where,$data,$table);
			    $this->m_data->proses_edit_data($where1,$data_notif,"alert");
			    redirect('admin/setting_notif');
			}
			else{
				$notif="Password baru dan ulangi password baru tidak cocok";
				$data_notif=array(
					'ganti_password'=>$notif
					);
				$where1=array('id'=>'1');
				$this->m_data->proses_edit_data($where1,$data_notif,"alert");
				 redirect('admin/setting_notif');
			}
		}
		else{
			$notif="Password lama dan baru tidak cocok atau password lama salah";
			$data_notif=array(
				'ganti_password'=>$notif
				);
			$where1=array('id'=>'1');
			$this->m_data->proses_edit_data($where1,$data_notif,"alert");
			 redirect('admin/setting_notif');
		}
	}
	function ganti_username(){
		$id_admin=$this->input->post('id_admin');
		$password_lama=$this->input->post('password_lama');
		$username=$this->input->post('username');
		$password=$this->input->post('password');

		if($password_lama==$password){
				$data=array(
				'username'=>$username
				);
				$notif="Selamat Username Berhasil di ganti";
				$data_notif=array(
					'ganti_password'=>$notif
					);
				$where=array('id_admin'=>$id_admin);
				$where1=array('id'=>'1');
				$table='admin';
			    $this->m_data->proses_edit_data($where,$data,$table);
			    $this->m_data->proses_edit_data($where1,$data_notif,"alert");
			    redirect('admin/daftar_admin');
		}
		else{
			$notif="Password tidak benar";
			$data_notif=array(
				'ganti_password'=>$notif
				);
			$where1=array('id'=>'1');
			$this->m_data->proses_edit_data($where1,$data_notif,"alert");
			 redirect('admin/setting_notif');
		}
	}
	function tambah_wali_kelas(){
		$this->load->model('m_data');
		$data['guru'] = $this->m_data->tampil_data('guru')->result();
		$data['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_wali_kelas',$data);
	}
	function edit_wali_kelas($id_guru){
		$this->load->model('m_data');
		$data['guru1']=$this->m_data->edit_wali_kelas($id_guru)->result();
		$data['guru'] = $this->m_data->tampil_data('guru')->result();
		$data['kelas'] = $this->m_data->tampil_data('kelas')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/edit_wali_kelas',$data);
	}
	function proses_tambah_wali_kelas(){
		$id_guru=$this->input->post('id_guru');
		$kelas=$this->input->post('kelas');

		$data=array(
			'wali_kelas'=>$kelas
			);
		$table='guru';
		$where=array('id_guru'=>$id_guru);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_wali_kelas');
	}
	function hapus_wali_kelas($id_guru){
		$kelas=0;
		$data=array(
			'wali_kelas'=>$kelas
			);
		$table='guru';
		$where=array('id_guru'=>$id_guru);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_wali_kelas');
	}
	function daftar_wali_kelas(){
		$this->load->model('m_data');
		$data['guru'] = $this->m_data->daftar_wali_kelas()->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_wali_kelas',$data);
	}
	function login_akun_guru(){
		$this->load->model('m_data');
		$data['guru'] = $this->m_data->tampil_data('guru')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/login_akun_guru',$data);
	}
	function login_akun_akademik(){
		$this->load->model('m_data');
		$data['akademik'] = $this->m_data->tampil_data('biro_akademik')->result();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/login_akun_akademik',$data);
	}
	function login_akun_eskul(){
		$this->load->model('m_data');
		$data['pembimbing'] = $this->m_data->daftar_pembimbing_eskul();
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/login_akun_eskul',$data);
	}
	function input_pengumuman_un(){
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/tambah_pengumuman_un');
	}
	function proses_tambah_pengumuman_un_form(){
		$nisn=$this->input->post('nisn');
		$us=$this->input->post('us');
		$un=$this->input->post('un');
		$tanggal=$this->input->post('tanggal');
		$waktu=$this->input->post('waktu');
		$status=$this->input->post('status');
		$upper=strtoupper($status);

		$where=array('nisn'=>$nisn);
		$data_cek['siswa']=$this->m_data->edit_data($where,'siswa')->result();
		foreach($data_cek['siswa'] as $s)
        $nis=$s->nis;

		$data=array(
			'nis'=>$nis,
			'us'=>$us,
			'un'=>$un,
			'tanggal'=>$tanggal,
			'waktu'=>$waktu,
			'status_administrasi'=>$upper
			);
		$this->m_data->tambah_data($data,'pengumuman_ujian');
		redirect('admin/daftar_pengumuman_un');		
	}
	function daftar_pengumuman_un(){
		$this->load->model('m_data');
		$query=$this->m_data->daftar_pengumuman_un();
		$data['pengumuman']=$query;
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/list_admin/daftar_pengumuman_un',$data);
	}
	function edit_pengumuman_un($id_pengumuman){
		$data['pengumuman_ujian']=$this->m_data->edit_pengumuman_un($id_pengumuman);
		$this->load->view('main/v_admin_header');
		$this->load->view('main/admin/form_admin/edit_pengumuman_un',$data);
	}
	function proses_edit_pengumuman_un(){
		$id_pengumuman=$this->input->post('id_pengumuman');
		$us=$this->input->post('us');
		$un=$this->input->post('un');
		$tanggal=$this->input->post('tanggal');
		$waktu=$this->input->post('waktu');
		$status=$this->input->post('status');
		$upper=strtoupper($status);

		$data=array(
			'us'=>$us,
			'un'=>$un,
			'tanggal'=>$tanggal,
			'waktu'=>$waktu,
			'status_administrasi'=>$upper
			);
		$table='pengumuman_ujian';
		$where=array('id_pengumuman'=>$id_pengumuman);
		$this->m_data->proses_edit_data($where,$data,$table);
		redirect('admin/daftar_pengumuman_un');
	}
	function hapus_data_pengumuman_un($id_pengumuman){
		$where = array('id_pengumuman' => $id_pengumuman);
		$table='pengumuman_ujian';
		$this->m_data->hapus_data($where,$table);
		redirect('admin/daftar_pengumuman_un');
	}
	function proses_tambah_pengumuman(){
		$fileName = $this->input->post('file', TRUE);

  		$config['upload_path'] = './assets/file/'; 
  		$config['file_name'] = $fileName;
  		$config['allowed_types'] = 'xls|xlsx|csv|ods|ots';
  		$config['max_size'] = 10000;

  		$this->load->library('upload', $config);
  		$this->upload->initialize($config); 
  
  		if (!$this->upload->do_upload('file')) {
   			$error = array('error' => $this->upload->display_errors());
   			$this->session->set_flashdata('msg','Ada kesalah dalam upload'); 
   			redirect('guru/index'); 
  		} else {
   			$media = $this->upload->data();
   			$inputFileName = 'assets/file/'.$media['file_name'];
   
   			try {
    			$inputFileType = IOFactory::identify($inputFileName);
    			$objReader = IOFactory::createReader($inputFileType);
    			$objPHPExcel = $objReader->load($inputFileName);
   				} catch(Exception $e) {
    			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
   				}

   			$sheet = $objPHPExcel->getSheet(0);
   			$highestRow = $sheet->getHighestRow();
   			$highestColumn = $sheet->getHighestColumn();

   			for ($row = 2; $row <= $highestRow; $row++){  
     		$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
       		NULL,
       		TRUE,
       		FALSE);
       		if($rowData[0][1]=="L"){
       			$us="LULUS";
       		}
       		elseif($rowData[0][1]=="T"){
       			$us="TIDAK LULUS";
       		}
       		if($rowData[0][2]=="L"){
       			$un="LULUS";
       		}
       		elseif($rowData[0][2]=="T"){
       			$un="TIDAK LULUS";
       		}
       		$where=array('nisn'=>$rowData[0][0]);
			$data_cek['siswa']=$this->m_data->edit_data($where,'siswa')->result();
			foreach($data_cek['siswa'] as $s)
        	$nis=$s->nis;
        	$tanggal=$this->input->post('tanggal');
			$waktu=$this->input->post('waktu');
			$upper=strtoupper($rowData[0][3]);
		     $data = array(
		     "nis"=> $nis,
		     "us"=>$us,
		     "un"=>$un,
		     "tanggal"=>$tanggal,
		     "waktu"=>$waktu,
		     "status_administrasi"=>$upper
		     );
		     $where1=array('nis'=>$nis);
		     $cek = $this->m_data->edit_data($where1,"pengumuman_ujian")->num_rows();
		     if($cek>0){
		     	$this->m_data->proses_edit_data($where1,$data,"pengumuman_ujian");
		     }
		     else{
		     	$this->db->insert("pengumuman_ujian",$data);
		     }
   		} 
        redirect('admin/daftar_pengumuman_un');
	}
	}
	function update_database(){
		$this->load->model('m_data');
    	$data1['siswa']=$this->m_data->jumlah_data_siswa("jeniskelamin_siswa","siswa");
    	$data1['guru']=$this->m_data->jumlah_data_guru("jenis_kelamin","guru");
    	$data1['siswa_kelas_ipa']=$this->m_data->jumlah_kelas_jurusan("IPA");
    	$data1['siswa_kelas_ips']=$this->m_data->jumlah_kelas_jurusan("IPS");
    	$data1['siswa_kelas_x']=$this->m_data->jumlah_kelas("X ");
    	$data1['siswa_kelas_xi']=$this->m_data->jumlah_kelas("XI ");
    	$data1['siswa_kelas_xii']=$this->m_data->jumlah_kelas("XII ");
    	$data1['tahun_ajaran'] = $this->m_data->tampil_data('tahun_ajaran')->result();
    	$ta = $this->input->post('ta');
		$query_tugas=$this->m_data->nilai_tugas_update()->result();
		foreach($query_tugas as $nt){
			$data_tugas = array("nilai_tugas"=> $nt->nilai_tugas);
			$where_tugas = array(
			'id_guru' => $nt->id_guru,
			'nis'=>$nt->nis,
			'kelas'=>$nt->kelas,
			'ta'=>$ta,
			'matapelajaran' => $nt->matapelajaran
			);
			$cek_tugas = $this->m_data->edit_data($where_tugas,"nilai_akhir")->num_rows();
			if ($cek_tugas>0) {
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where_tugas,$data_tugas,$table);
			}
			else{
				$this->session->set_flashdata('msg','Gagal upload ...!!');
			}
		}
		$query_ulangan=$this->m_data->nilai_ulangan_update()->result();
		foreach($query_ulangan as $nt){
			$data_ulangan = array("nilai_ulangan"=> $nt->nilai_ulangan);
			$where_ulangan = array(
			'id_guru' => $nt->id_guru,
			'nis'=>$nt->nis,
			'kelas'=>$nt->kelas,
			'ta'=>$ta,
			'matapelajaran' => $nt->matapelajaran
			);
			$cek_ulangan = $this->m_data->edit_data($where_ulangan,"nilai_akhir")->num_rows();
			if ($cek_ulangan>0) {
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where_ulangan,$data_ulangan,$table);
			}
			else{
				$this->session->set_flashdata('msg','Gagal upload ...!!');
			}
		}
		$query_ujian=$this->m_data->nilai_ujian_update()->result();
		foreach($query_ujian as $nt){
			$data_ujian = array("uts"=> $nt->uts,"uas"=> $nt->uas,);
			$where_ujian = array(
			'id_guru' => $nt->id_guru,
			'nis'=>$nt->nis,
			'kelas'=>$nt->kelas,
			'ta'=>$ta,
			'matapelajaran' => $nt->matapelajaran
			);
			$cek_ujian = $this->m_data->edit_data($where_ujian,"nilai_akhir")->num_rows();
			if ($cek_ujian>0) {
				$table='nilai_akhir';
				$this->m_data->proses_edit_data($where_ujian,$data_ujian,$table);
			}
			else{
				$this->session->set_flashdata('msg','Gagal upload ...!!');
			}
		}
		$this->load->view('main/v_admin_header');
		$this->load->view('main/v_admin_update',$data1);
	}
}
?>