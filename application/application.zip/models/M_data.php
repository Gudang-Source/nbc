<?php 

class M_data extends CI_Model{
	function tampil_data($data){
		return $this->db->get($data);
	}
	function rapot($nis,$ta){
		return $this->db->query("SELECT *, (nilai_ulangan + nilai_tugas + uts + uas) /4 as nilai_akhir FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis and n.nis={$nis} INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta and n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru ORDER BY n.ta DESC,n.nis");

	}
	function rapotpk($nis,$kategori,$ta){
		return $this->db->query("SELECT *, (nilai_ulangan + nilai_tugas + uts + uas) /4 as nilai_akhir FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis and n.nis={$nis} INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta and n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru where m.kategori='{$kategori}' ORDER BY n.ta DESC,n.nis");
	}
	function rapotpk_peminatan($nis,$jurusan,$ta){
		return $this->db->query("SELECT *, (nilai_ulangan + nilai_tugas + uts + uas) /4 as nilai_akhir FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis and n.nis={$nis} INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta and n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru where m.kategori='{$jurusan}'");
	}
	function nilai_ulangan($cn,$matapelajaran,$ta,$id_guru){
		return $this->db->query("SELECT *, (ulangan1 + ulangan2 + ulangan3) /3 as nilai_ulangan from nilai_ulangan n INNER JOIN siswa s ON n.nis=s.nis AND n.nis={$cn} INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran AND n.matapelajaran={$matapelajaran} INNER JOIN guru g ON n.id_guru=g.id_guru AND n.id_guru={$id_guru} ORDER BY n.ta DESC,n.nis");
	}
	function nilai_ketrampilan($cn,$matapelajaran,$ta,$id_guru){
		return $this->db->query("SELECT *, (ketrampilan1 + ketrampilan2 + ketrampilan3) /3 as nilai_ketrampilan from nilai_ketrampilan n INNER JOIN siswa s ON n.nis=s.nis AND n.nis={$cn} INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran AND n.matapelajaran={$matapelajaran} INNER JOIN guru g ON n.id_guru=g.id_guru AND n.id_guru={$id_guru} ORDER BY n.ta DESC,n.nis");
	}
	function nilai_ulangan_update(){
		return $this->db->query("SELECT *, (ulangan1 + ulangan2 + ulangan3) /3 as nilai_ulangan from nilai_ulangan ");
	}
	function nilai_tugas($cn,$matapelajaran,$ta,$id_guru){
		return $this->db->query("SELECT *, (tugas1 + tugas2 + tugas3) /3 as nilai_tugas from nilai_tugas n INNER JOIN siswa s ON n.nis=s.nis AND n.nis={$cn} INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran AND n.matapelajaran={$matapelajaran} INNER JOIN guru g ON n.id_guru=g.id_guru AND n.id_guru={$id_guru} ORDER BY n.ta DESC,n.nis");
	}
	function nilai_tugas_update(){
		return $this->db->query("SELECT *, (tugas1 + tugas2 + tugas3) /3 as nilai_tugas from nilai_tugas");
	}
	function nilai_ujian($cn,$matapelajaran,$ta,$id_guru){
		return $this->db->query("SELECT * from nilai_ujian n INNER JOIN siswa s ON n.nis=s.nis AND n.nis={$cn} INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran AND n.matapelajaran={$matapelajaran} INNER JOIN guru g ON n.id_guru=g.id_guru AND n.id_guru={$id_guru} ORDER BY n.ta DESC,n.nis");
	}
	function nilai_ujian_update(){
		return $this->db->query("SELECT * from nilai_ujian");
	}
	function daftar_mapel($kondisi){
		return $this->db->query("SELECT * FROM matapelajaran where kategori='{$kondisi}' or kategori='Semua'");
	}
	function daftar_kelas($kondisi){
		return $this->db->query("SELECT * FROM kelas where nama_kelas like '{$kondisi}%'");
	}
	function daftar_admin(){
		return $this->db->query("SELECT * FROM admin where level!=''");
	}
	function jumlah_data_guru($kolom,$table){
		return $this->db->query("SELECT *,COUNT({$kolom}) as jumlhjk FROM {$table} GROUP BY {$kolom} ORDER BY {$kolom} ASC")->result();
	}
	function jumlah_data_siswa($kolom,$table){
		return $this->db->query("SELECT *,COUNT({$kolom}) as jumlhjk FROM {$table} WHERE status='Aktif' GROUP BY {$kolom} ORDER BY {$kolom} ASC")->result();
	}
	function daftar_wali_kelas(){
		return $this->db->query("SELECT * FROM guru g INNER JOIN kelas k ON g.wali_kelas = k.id_kelas ORDER BY wali_kelas ASC");
	}
	function edit_wali_kelas($id_guru){
		return $this->db->query("SELECT * FROM guru g INNER JOIN kelas k ON g.wali_kelas = k.id_kelas WHERE g.id_guru={$id_guru}");
	}
	function edit_siswa($nis){
		return $this->db->query("SELECT * FROM siswa s INNER JOIN kelas k ON s.kelas = k.id_kelas WHERE s.nis={$nis}");
	}
	function jumlah_kelas_jurusan($jurusan){
		return $this->db->query("SELECT *,COUNT(kelas) as jumlhkls FROM siswa s INNER JOIN kelas k on s.kelas=k.id_kelas WHERE k.nama_kelas like '%{$jurusan}%'  GROUP BY kelas ORDER BY kelas ASC")->result();
	}
	function jumlah_kelas($kelas){
		return $this->db->query("SELECT *,COUNT(kelas) as jumlhkls FROM siswa s INNER JOIN kelas k on s.kelas=k.id_kelas WHERE k.nama_kelas like '{$kelas}%'  GROUP BY kelas ORDER BY kelas ASC")->result();
	}
	function daftar_peserta_eskul_pembimbing($id_pembimbing){
		return $this->db->query("SELECT * FROM peserta_eskul pe INNER JOIN tahun_ajaran t ON pe.ta = t.id_ta  INNER JOIN eskul e ON pe.eskul1=e.id_eskul INNER JOIN siswa s ON pe.nis=s.nis INNER JOIN kelas k ON s.kelas=k.id_kelas INNER JOIN pembimbing_eskul p ON pe.pembimbing1=p.id_pembimbing where pe.pembimbing1={$id_pembimbing} or pe.pembimbing2={$id_pembimbing}  ORDER BY pe.ta DESC,pe.nis");
	}
	function daftar_nilai_peserta_eskul_pembimbing($id_pembimbing){
		return $this->db->query("SELECT * FROM nilai_eskul n INNER JOIN tahun_ajaran t ON n.ta = t.id_ta  INNER JOIN eskul e ON n.eskul=e.id_eskul INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON s.kelas=k.id_kelas INNER JOIN pembimbing_eskul p ON n.pembimbing=p.id_pembimbing where n.pembimbing={$id_pembimbing}  ORDER BY n.ta DESC,n.nis");
	}
	function peserta_eskul($nis,$ta,$pembimbing,$eskul){
		return $this->db->query("SELECT * FROM peserta_eskul WHERE nis={$nis} and ta={$ta} and (pembimbing1 ={$pembimbing} or pembimbing2 = {$pembimbing}) and (eskul1 = {$eskul} or eskul2 = {$eskul} )");
	}
	function daftar_nilai_peserta_eskul($nis,$ta){
		return $this->db->query("SELECT * FROM nilai_eskul n INNER JOIN eskul e ON n.eskul=e.id_eskul WHERE n.nis={$nis} and n.ta={$ta}");
	}
	function edit_nilai_eskul($id_nilai_eskul){
		return $this->db->query("SELECT * FROM nilai_eskul n INNER JOIN tahun_ajaran t ON n.ta = t.id_ta  INNER JOIN eskul e ON n.eskul=e.id_eskul INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON s.kelas=k.id_kelas INNER JOIN pembimbing_eskul p ON n.pembimbing=p.id_pembimbing where n.id_nilai_eskul={$id_nilai_eskul}  ORDER BY n.ta DESC,n.nis");
	}
	function daftarsiswa(){
		return $this->db->query("SELECT * FROM kelas k INNER JOIN siswa s ON s.kelas=k.id_kelas where s.status='Aktif'")->result();
	}
	function daftarsiswa_tidakaktif(){
		return $this->db->query("SELECT * FROM siswa s where s.status='Tidak Aktif' or s.kelas=0")->result();
	}
	function daftar_biro_akademik(){
		return $this->db->query('SELECT * FROM biro_akademik b INNER JOIN guru g ON g.id_guru=b.guru')->result();
	}
	function daftar_pengumuman_un(){
		return $this->db->query('SELECT * FROM pengumuman_ujian p INNER JOIN siswa s ON s.nis=p.nis INNER JOIN kelas k ON s.kelas=k.id_kelas ORDER BY p.nis')->result();
	}
	function lihat_pengumuman_un($id){
		return $this->db->query("SELECT * FROM pengumuman_ujian p INNER JOIN siswa s ON s.nis=p.nis INNER JOIN kelas k ON s.kelas=k.id_kelas WHERE p.nis={$id}")->result();
	}
	function edit_biro_akademik($id_biro_akademik){
		return $this->db->query("SELECT * FROM biro_akademik b INNER JOIN guru g ON g.id_guru=b.guru WHERE b.id_biro_akademik={$id_biro_akademik}")->result();
	}
	function edit_pengumuman_un($id){
		return $this->db->query("SELECT * FROM pengumuman_ujian p INNER JOIN siswa s ON s.nis=p.nis WHERE p.id_pengumuman={$id}")->result();
	}
	function daftarsiswa_kelas($id_kelas){
		return $this->db->query("SELECT * FROM kelas k INNER JOIN siswa s ON s.kelas=k.id_kelas AND s.kelas={$id_kelas}")->result();
	}
	function mapel_ajar($id_guru){
		return $this->db->query("SELECT * FROM ajar a INNER JOIN kelas k ON a.kelas1=k.id_kelas  INNER JOIN matapelajaran m ON a.id_matapelajaran=m.id_matapelajaran AND a.id_guru={$id_guru}")->result();
	}
	function daftar_pembimbing_eskul(){
		return $this->db->query("SELECT * FROM pembimbing_eskul p INNER JOIN tahun_ajaran t ON p.ta = t.id_ta INNER JOIN eskul e ON p.eskul=e.id_eskul")->result();
	}
	function edit_pembimbing_eskul($id_pembimbing){
		return $this->db->query("SELECT * FROM pembimbing_eskul p INNER JOIN tahun_ajaran t ON p.ta = t.id_ta INNER JOIN eskul e ON p.eskul=e.id_eskul AND p.id_pembimbing={$id_pembimbing}")->result();
	}
	function tambah_peserta_eskul($id_pembimbing,$ta){
		return $this->db->query("SELECT * FROM pembimbing_eskul p INNER JOIN tahun_ajaran t ON p.ta = t.id_ta INNER JOIN eskul e ON p.eskul=e.id_eskul AND p.id_pembimbing={$id_pembimbing} AND p.ta={$ta}")->result();
	}
	function daftarajar(){
		return $this->db->query('SELECT * FROM ajar a INNER JOIN guru g ON a.id_guru = g.id_guru INNER JOIN tahun_ajaran t ON a.ta = t.id_ta INNER JOIN matapelajaran m ON a.id_matapelajaran = m.id_matapelajaran INNER JOIN kelas k ON a.kelas1 = k.id_kelas')->result();
	}
	function daftar_prestasi($pembimbing){
		return $this->db->query("SELECT * FROM prestasi_siswa p INNER JOIN siswa s ON p.nis=s.nis INNER JOIN pembimbing_eskul pe ON p.pembimbing= pe.id_pembimbing AND p.pembimbing={$pembimbing} INNER JOIN kelas k ON s.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON p.ta=t.id_ta ORDER BY p.ta DESC");
	}
	function edit_prestasi($id){
		return $this->db->query("SELECT * FROM prestasi_siswa p INNER JOIN siswa s ON p.nis=s.nis INNER JOIN pembimbing_eskul pe ON p.pembimbing= pe.id_pembimbing  INNER JOIN kelas k ON s.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON p.ta=t.id_ta WHERE p.id_prestasi_siswa={$id} ORDER BY p.ta DESC");
	}
	function lihat_tugas_guru($id_guru){
		return $this->db->query("SELECT * FROM ajar a INNER JOIN matapelajaran m ON a.id_matapelajaran = m.id_matapelajaran INNER JOIN kelas k ON a.kelas1 = k.id_kelas INNER JOIN tahun_ajaran t ON a.ta = t.id_ta INNER JOIN guru g ON a.id_guru = g.id_guru AND a.id_guru={$id_guru}")->result();
	}
	function edit_ajar($id_ajar){
		return $this->db->query("SELECT * FROM ajar a INNER JOIN tahun_ajaran t ON a.ta = t.id_ta INNER JOIN matapelajaran m ON a.id_matapelajaran = m.id_matapelajaran INNER JOIN kelas k ON a.kelas1 = k.id_kelas INNER JOIN guru g ON a.id_guru = g.id_guru AND a.id_ajar={$id_ajar}")->result();
	}
	function daftar_kehadiran($ta){
		return $this->db->query("SELECT DISTINCT n.nis,s.nama_siswa,t.nama_ta,k.nama_kelas,n.s,n.i,n.a,n.ta,n.kelas FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru ORDER BY n.ta DESC,n.nis ");
	}
	function daftar_nilai_akhlaq($ta){
		return $this->db->query("SELECT DISTINCT n.nis,s.nama_siswa,t.nama_ta,k.nama_kelas,n.nilai_kelakuan,n.komentar_kelakuan,n.nilai_kerajinan,n.komentar_kerajinan,n.nilai_kerapihan,n.komentar_kerapihan,n.nilai_kebersihan,n.komentar_kebersihan,n.ta,n.kelas FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru where n.nilai_kelakuan !='' ORDER BY n.ta DESC,n.nis ");
	}
	function daftar_komentar_k13($id_guru,$ta){
		return $this->db->query("SELECT * FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru AND n.id_guru={$id_guru} where n.komentar_pengetahuan !='' ORDER BY n.ta DESC,n.nis ");
	}
	function daftar_nilai_sikap_sosial_k13($ta){
		return $this->db->query("SELECT DISTINCT n.nis,s.nama_siswa,t.nama_ta,k.nama_kelas,n.sikap_spiritual,n.deskripsi_spiritual,n.sikap_sosial,n.deskripsi_sosial,n.ta,n.kelas FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru where n.sikap_sosial !='' and n.deskripsi_sosial !='' ORDER BY n.ta DESC,n.nis ");
	}
	function daftar_nilai_sikap_sosial_k13_kelas($kelas,$ta){
		return $this->db->query("SELECT DISTINCT n.nis,s.nama_siswa,t.nama_ta,k.nama_kelas,n.sikap_spiritual,n.deskripsi_spiritual,n.sikap_sosial,n.deskripsi_sosial,n.ta,n.kelas FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas AND n.kelas={$kelas} INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru where n.sikap_sosial !='' and n.deskripsi_sosial !='' ORDER BY n.ta DESC,n.nis ");
	}
	function daftar_nilai_sikap_spiritual_k13($ta){
		return $this->db->query("SELECT DISTINCT n.nis,s.nama_siswa,t.nama_ta,k.nama_kelas,n.sikap_spiritual,n.deskripsi_spiritual,n.sikap_sosial,n.deskripsi_sosial,n.ta,n.kelas FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru where n.sikap_spiritual !='' and n.deskripsi_spiritual !='' ORDER BY n.ta DESC,n.nis ");
	}
	function daftar_nilai_sikap_spiritual_k13_kelas($kelas,$ta){
		return $this->db->query("SELECT DISTINCT n.nis,s.nama_siswa,t.nama_ta,k.nama_kelas,n.sikap_spiritual,n.deskripsi_spiritual,n.sikap_sosial,n.deskripsi_sosial,n.ta,n.kelas FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas AND n.kelas={$kelas} INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru where n.sikap_spiritual !='' and n.deskripsi_spiritual !='' ORDER BY n.ta DESC,n.nis ");
	}
	function daftar_nilai_akhlaq_kelas($kelas,$ta){
		return $this->db->query("SELECT DISTINCT n.nis,s.nama_siswa,t.nama_ta,k.nama_kelas,n.nilai_kelakuan,n.komentar_kelakuan,n.nilai_kerajinan,n.komentar_kerajinan,n.nilai_kerapihan,n.komentar_kerapihan,n.nilai_kebersihan,n.komentar_kebersihan,n.ta,n.kelas FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas AND n.kelas={$kelas} INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru ORDER BY n.ta DESC,n.nis ");
	}
	function edit_nilai_akhlaq($nis,$ta,$kelas){
		return $this->db->query("SELECT DISTINCT n.nis,s.nama_siswa,t.nama_ta,k.nama_kelas,n.nilai_kelakuan,n.komentar_kelakuan,n.nilai_kerajinan,n.komentar_kerajinan,n.nilai_kerapihan,n.komentar_kerapihan,n.nilai_kebersihan,n.komentar_kebersihan,n.ta,n.kelas FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru WHERE n.nis={$nis} And n.ta={$ta} And n.kelas={$kelas} ORDER BY n.ta DESC,n.nis ");
	}
	function edit_nilai_sikap_k13($nis,$ta,$kelas){
		return $this->db->query("SELECT DISTINCT n.nis,s.nama_siswa,t.nama_ta,k.nama_kelas,n.sikap_spiritual,n.deskripsi_spiritual,n.sikap_sosial,n.deskripsi_sosial,n.ta,n.kelas FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru WHERE n.nis={$nis} And n.ta={$ta} And n.kelas={$kelas} ORDER BY n.ta DESC,n.nis ");
	}
	function daftar_nilai($id_guru,$table,$ta){
		return $this->db->query("SELECT * FROM {$table} n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru AND n.id_guru={$id_guru} ORDER BY n.ta DESC,n.nis");
	}
	function daftar_catatan_wali_kelas($id_guru,$ta){
		return $this->db->query("SELECT * FROM catatan_wali_kelas n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN guru g ON n.wali_kelas=g.id_guru AND n.wali_kelas={$id_guru} ORDER BY n.ta DESC,n.nis");
	}
	function daftar_nilai_akademik($table,$kelas){
		return $this->db->query("SELECT * FROM {$table} n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas AND k.nama_kelas like '{$kelas}%' INNER JOIN tahun_ajaran t ON n.ta = t.id_ta INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru ORDER BY n.ta DESC,n.nis");
	}
	function daftar_nilai_akademik_jurusan($table,$jurusan){
		return $this->db->query("SELECT * FROM {$table} n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas and k.nama_kelas like '{$jurusan}%' INNER JOIN tahun_ajaran t ON n.ta = t.id_ta INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru ORDER BY n.ta DESC,n.nis");
	}
	function daftar_nilai_akademik_kelas($kelas){
		return $this->db->query("SELECT * FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas and n.kelas={$kelas} INNER JOIN tahun_ajaran t ON n.ta = t.id_ta INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran and n.matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru ORDER BY n.ta DESC,n.nis");
	}
	function daftar_nilai_akademik_mapel($matapelajaran){
		return $this->db->query("SELECT * FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran and n.matapelajaran={$matapelajaran} INNER JOIN guru g ON n.id_guru=g.id_guru ORDER BY n.ta DESC,n.nis");
	}
	function daftar_nilai_akademik_mapel_kelas($matapelajaran,$kelas){
		return $this->db->query("SELECT * FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas and n.kelas={$kelas} INNER JOIN tahun_ajaran t ON n.ta = t.id_ta INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran and n.matapelajaran={$matapelajaran} INNER JOIN guru g ON n.id_guru=g.id_guru ORDER BY n.ta DESC,n.nis");
	}
	function edit_nilai($id_nilai,$table,$field){
		return $this->db->query("SELECT * FROM {$table} n INNER JOIN siswa s ON n.nis=s.nis AND n.{$field}={$id_nilai}");
	}
	function edit_kehadiran_siswa($nis,$ta,$kelas){
		return $this->db->query("SELECT DISTINCT n.nis,s.nama_siswa,t.nama_ta,k.nama_kelas,n.s,n.i,n.a,n.ta,n.kelas FROM nilai_akhir n INNER JOIN siswa s ON n.nis=s.nis And n.nis={$nis} INNER JOIN kelas k ON n.kelas=k.id_kelas AND n.kelas={$kelas} INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran INNER JOIN guru g ON n.id_guru=g.id_guru ORDER BY n.ta DESC,n.nis ");
	}
	function daftar_nilai_mapel($id_guru,$id_matapelajaran,$table,$ta){
		return $this->db->query("SELECT * FROM {$table} n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta = {$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran AND n.matapelajaran={$id_matapelajaran} INNER JOIN guru g ON n.id_guru=g.id_guru AND n.id_guru={$id_guru} ORDER BY n.ta DESC,n.nis");
	}
	function daftar_nilai_kelas($id_guru,$matapelajaran,$kelas,$table,$ta){
		return $this->db->query("SELECT * FROM {$table} n INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON n.kelas=k.id_kelas INNER JOIN tahun_ajaran t ON n.ta = t.id_ta AND n.ta={$ta} INNER JOIN matapelajaran m ON n.matapelajaran=m.id_matapelajaran AND n.matapelajaran={$matapelajaran} INNER JOIN guru g ON n.id_guru=g.id_guru AND n.id_guru={$id_guru} AND n.kelas={$kelas} ORDER BY n.ta DESC,n.nis");
	}
	function tambah_data($data,$table){
			$this->db->insert($table,$data);	
	}
	function tambah_nilai($dataarray,$table){
			for ($i = 0; $i < count($dataarray); $i++) {
            $data = array(
                'nis' => $dataarray[$i]['nis'],
                'id_guru'=>$id_guru,
                'matapelajaran'=>$matapelajaran,
                'kelas'=>$kelas,
                'ulangan1' => $dataarray[$i]['ulangan1']
            );
			$this->db->insert($table,$data);
			}	
	}
	function guru_bk($id_guru){
		return $this->db->query("SELECT * FROM ajar a INNER JOIN matapelajaran m ON a.id_matapelajaran=m.id_matapelajaran WHERE a.id_guru={$id_guru}");
	}
	function guru_wali_kelas($id_guru){
		return $this->db->query("SELECT * FROM guru g INNER JOIN kelas k ON g.wali_kelas=k.id_kelas WHERE g.id_guru={$id_guru}");
	}
	function edit_data($where,$table){	
	return $this->db->get_where($table,$where);	
	}
	function proses_edit_data($where,$data,$table){	
		$this->db->where($where);
		$this->db->update($table,$data);	
	}
	function wali_kelas($where){	
		return $this->db->query("SELECT * FROM guru WHERE wali_kelas={$where}");	
	}
	function catatan_wali_kelas($nis,$ta,$kelas){	
		return $this->db->query("SELECT * FROM catatan_wali_kelas WHERE nis={$nis} AND ta={$ta} AND kelas={$kelas}");	
	}
	function hapus_data($where,$table){
	$this->db->where($where);
	$this->db->delete($table);
	}
	function daftar_nilai_eskul_semua(){
		return $this->db->query("SELECT * FROM nilai_eskul n INNER JOIN tahun_ajaran t ON n.ta = t.id_ta  INNER JOIN eskul e ON n.eskul=e.id_eskul INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON s.kelas=k.id_kelas INNER JOIN pembimbing_eskul p ON n.pembimbing=p.id_pembimbing  ORDER BY n.ta DESC,n.nis");
	}
	function daftar_nilai_eskul($id){
		return $this->db->query("SELECT * FROM nilai_eskul n INNER JOIN tahun_ajaran t ON n.ta = t.id_ta  INNER JOIN eskul e ON n.eskul=e.id_eskul AND eskul={$id} INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON s.kelas=k.id_kelas INNER JOIN pembimbing_eskul p ON n.pembimbing=p.id_pembimbing  ORDER BY n.ta DESC,n.nis");
	}
	function daftar_nilai_eskul_kelas($eskul,$kelas){
		return $this->db->query("SELECT * FROM nilai_eskul n INNER JOIN tahun_ajaran t ON n.ta = t.id_ta  INNER JOIN eskul e ON n.eskul=e.id_eskul AND n.eskul={$eskul} INNER JOIN siswa s ON n.nis=s.nis INNER JOIN kelas k ON s.kelas=k.id_kelas AND s.kelas = {$kelas} INNER JOIN pembimbing_eskul p ON n.pembimbing=p.id_pembimbing  ORDER BY n.ta DESC,n.nis");
	}
} 
?>